# Análisis arquitectónico de certificados · versión 1.0.0

Fecha de incorporación: 12/11/2026. Ampliación independiente del ranking y CRREM. No incorpora un asistente IA ni modifica los pesos o indicadores de los módulos anteriores.

## Preguntas

1. ¿Qué diferencias presentan los certificados según época, normativa, tamaño e instalaciones?
2. ¿Cómo se separa un caso de otros con características parcialmente comparables?
3. ¿Qué relaciones se observan entre características arquitectónicas y comportamiento energético calculado?
4. ¿Dónde coinciden EPNR elevada y renta territorial baja dentro del conjunto disponible?
5. ¿Qué prioridades se mantienen en las combinaciones de pesos ensayadas?

## Fuentes y significado

Se utiliza el CSV/ZIP del importador habitual, con sus enlaces sociales aplicados. No se añaden datos inventados. Los campos adicionales se han contrastado con el diccionario oficial de la Comunidad de Madrid, recurso CEEE 2026, consultado el 12/11/2026:

https://datos.comunidad.madrid/dataset/registro_certificados_eficiencia_energetica/resource/4e42b49c-bb6b-485a-a7b7-8f760f356855

El caso conserva los registros originales de 2025; consultar el diccionario de 2026 no cambia su año ni acredita la exactitud de cada campo.

- `edif_año`: año de construcción declarado. No garantiza fecha comprobada ni ausencia de reformas.
- `edif_norma`: normativa declarada de construcción o rehabilitación. Se describe por separado del año; no se infiere cumplimiento.
- `edif_compac`: volumen habitable / superficie de envolvente no adiabática, m³/m².
- `elec_demcalef`, `elec_demrefrig`: demandas calculadas de calefacción y refrigeración, kWh/m²·año. El prefijo del campo no convierte la demanda en consumo eléctrico.
- `calefac_tipo`, `calefac_vector`, `acs_tipo`: categorías declaradas de equipos y suministros.
- `calefac_rendim` y `calefac_modo`: rendimiento declarado y forma de selección. Se auditan; el rendimiento queda fuera del modelo por códigos de relleno y diferencias de codificación.
- `final_calef`, `final_refrig`, `final_acs`, `final_ilu`: energía final calculada por servicio, kWh/m²·año.

Se admiten los alias explícitos del código. Un archivo simplificado sin campos adicionales conserva sus filas y muestra las limitaciones.

## Preparación y auditoría

Se conserva una columna original y un estado por campo adicional. Se admiten coma y punto decimal con la convención española ya utilizada por el importador. No se imputan demandas, años, renta ni características.

Reglas: números finitos; demandas y servicios no negativos; superficie, compacidad y rendimiento positivos; año entero entre 1800 y el año de control. Números ≥10⁷ se consideran rellenos o extremos no interpretables y se apartan del análisis ampliado, conservando motivo y original. Este umbral es una decisión analítica documentada, no una regla oficial de validez.

Demandas >1.000 kWh/m²·año y compacidad >100 m³/m² se señalan como extremos exploratorios: permanecen en la descripción y se excluyen del modelo ajustado. Un año terminado en cero genera una señal de posible aproximación, sin exclusión automática. La cobertura tras controles no equivale a exactitud física.

Para porcentajes por servicio se necesitan los cuatro servicios y un total positivo. La suma debe diferir del total como máximo en max(0,2 kWh/m²·año; 0,005 × total). Si falla, los porcentajes quedan ausentes. Se conserva el cero declarado, sin interpretarlo como ausencia real de necesidad. Las medianas de porcentajes independientes no deben sumarse como si fueran un reparto agregado.

## Grupos semejantes

Se exige coincidencia en tipología, zona climática, época y tramo de superficie. Periodos: hasta 1979, 1980–2006, 2007–2013 y desde 2014. Son cortes analíticos, no atribuciones normativas. Tramos: hasta 500 m², más de 500 a 1.500 m² y más de 1.500 m².

La referencia utiliza exclusivamente otros casos del grupo con el indicador válido: mediana y P75 dejando fuera el certificado consultado. El mínimo por defecto es 20 otros casos, ajustable a 10, 30 o 50. No se relajan automáticamente los grupos. Se exportan tamaño, mediana, P75, diferencia absoluta, diferencia porcentual y percentil frente a otros casos. El porcentaje queda ausente si la mediana es cero.

Percentil comparativo = 100 × (otros valores menores + 0,5 × empates) / otros casos. No coincide necesariamente con la puntuación del ranking original, que conserva su fórmula.

Estos grupos no igualan conservación, orientación, ocupación, reformas ni todas las condiciones de cálculo. No constituyen contrafactuales de una intervención.

## Diferencias y asociaciones

Por cada categoría se presentan filas, casos con indicador, mediana y P25/P75. Los grupos pequeños mantienen su advertencia. Spearman se calcula con pares completos y al menos 20 casos, si ambas variables varían. Se muestra n por relación. No se presentan pruebas de significación ni interpretación causal. La repetición de secciones censales exige cautela adicional.

## Modelo estadístico opcional

Regresión por mínimos cuadrados de log(1 + indicador). Considera año, log(superficie), log(compacidad), zona climática y tipología. Las variables numéricas se estandarizan con el conjunto de aprendizaje. Categorías con menos de 20 observaciones de aprendizaje se reúnen en «Otros»; se registra la categoría de referencia. Se excluyen filas con campos necesarios ausentes o extremos exploratorios. Mínimo: 200 casos y 10 grupos para validación.

La validación utiliza cinco particiones. Secciones compartidas y parcelas conocidas se unen en componentes conectados que permanecen juntos. La parcela se aproxima mediante los primeros 14 caracteres de la referencia; esto no acredita identidad física. Asignación reproducible con semilla 20261112. Casos sin identificadores compartidos conocidos se tratan como grupos propios: la separación no garantiza independencia espacial ni identifica duplicados ocultos.

Cada partición prepara categorías y escalas exclusivamente en aprendizaje. El modelo se contrasta en las unidades originales mediante error absoluto medio (MAE) frente a dos referencias: mediana de aprendizaje y mediana de grupos semejantes del aprendizaje con al menos 20 casos, usando la global cuando el grupo es insuficiente. La transformación inversa se interpreta como estimación puntual del modelo, sin atribuirle una media insesgada. Se guardan todas las predicciones fuera de grupo y errores por partición. No se seleccionan hiperparámetros ni modelos mediante esas mismas pruebas.

El ajuste final permite describir coeficientes, sin intervalos, p-valores ni interpretaciones causales. Los coeficientes se expresan en log(1 + indicador), por desviación típica en variables numéricas y respecto a la categoría indicada en las categóricas. No representan ahorro, prioridad de obra ni importancia causal. Si el diseño es redundante, el modelo se abstiene. Los errores son internos al registro; no validan consumos medidos, otros territorios o intervenciones.

## Perfiles y cruce social

- Demanda de calefacción alta entre semejantes: valor estrictamente superior al P75 de los otros casos, con comparación suficiente.
- Coincidencia energética-social: EPNR estrictamente superior al P75 y renta estrictamente inferior al P25 del conjunto con ambas variables utilizables; mínimo 20 casos. No se calcula cada umbral por grupo ni se atribuyen ingresos individuales.
- Servicio mayoritario: servicio con más del 50 % del total final, solo con reparto coherente. Si ninguno lo supera, se indica.

Los perfiles se solapan. Ausencia de información no se codifica como ausencia de necesidad. La renta se resume por certificado, no por sección única; las secciones repetidas tienen más presencia. Cada cruce por época, municipio o sistema informa de cobertura y denominador.

## Estabilidad

Se comparan 100/0/0, 60/40/0, 50/30/20, 48/32/20, 40/20/40 y 30/20/50 sobre exactamente los mismos casos completos en EPNR, emisiones y renta; en anual se exige superficie positiva. Los percentiles se recalculan sobre ese grupo. Se toma techo(0,10 × n), con empates del corte resueltos por orden de entrada. Las posiciones mínima y máxima utilizan puestos medios para empates.

La frecuencia muestra apariciones en el primer decil de estas seis configuraciones. No es una probabilidad ni una medida de incertidumbre estadística. Puede cambiar al modificar conjunto, reglas o configuraciones.

## Exportación y reproducción

El ZIP del módulo incluye todas las filas preparadas, originales de campos adicionales, auditoría, comparaciones por grupo, relaciones, perfiles, estabilidad, conclusiones y, si se ejecutó, validación del modelo. Se registran fuente, versión, SHA-256 del archivo, huella de datos aplicados, filtros, magnitud y mínimo de comparables. El PDF general incorpora el resumen del módulo cuando se exporta desde él.

Reproducción independiente, sin cambiar el archivo guardado de la aplicación:

    python reproducir_analisis_arquitectonico.py --entrada RUTA_CSV_O_ZIP --salida CARPETA_NUEVA --modelo

La reproducción utiliza las columnas sociales del archivo, sin consultar INE ni aplicar por su cuenta las revisiones locales. Para conservar revisiones hay que utilizar un archivo exportado que las incluya y comprobar sus estados. La interfaz aplica su importador y controles sociales habituales.

## Alcance de la actualización

No se reescriben las fuentes, el ranking, los cálculos CRREM ni los resultados históricos del caso de octubre. El nuevo análisis necesita evaluación física y metodológica adicional. Su utilidad se presenta con cobertura, comparaciones y errores observados, incluyendo cuando el modelo no supera las referencias sencillas.

Apoyo de IA: ChatGPT/Codex, 12/11/2026, programación del módulo, consulta del diccionario oficial, documentación y preparación de pruebas. La revisión académica final corresponde al autor. Los datos artificiales de pruebas existen solo en memoria y no se cargan en la aplicación.
