"""Pantalla independiente: utiliza el mismo importador y conserva los módulos previos."""
import hashlib
import json
from datetime import date
import numpy as np
import pandas as pd
import streamlit as st
from analisis_arquitectonico import (preparar,comparar_similares,describir_grupos,relaciones,
    modelo_ajustado,perfiles,estabilidad,resumen_social,exportar,ETIQUETAS,FUENTE,VERSION)
from apariencia import grafica


@st.cache_data(show_spinner=False)
def calcular(raw, objetivo, minimo, modo, ajustar, anio_control):
    d,audit=preparar(raw,anio_control)
    peers=comparar_similares(d,objetivo,minimo)
    heat=peers if objetivo=='demanda_calefaccion' else comparar_similares(d,'demanda_calefaccion',minimo)
    profiles=perfiles(d,heat)
    stable,weights=estabilidad(d,modo)
    model=modelo_ajustado(d,objetivo) if ajustar else {'estado':'Pendiente de ejecutar','n':0}
    return d,audit,peers,profiles,stable,weights,model


def mostrar_analisis(raw,nombre,huella):
    import altair as alt
    st.write('Estudia las características de los certificados, compara casos semejantes y comprueba qué conclusiones permiten los datos.')
    with st.expander('Elegir el conjunto y las reglas del análisis',expanded=False):
        st.caption('Estos filtros se aplican a este módulo. El ranking y CRREM conservan sus controles.')
        municipios=sorted(raw.get('edif_muni',raw.get('municipio',pd.Series(dtype=str))).dropna().astype(str).unique())
        selected=st.multiselect('Municipios del análisis arquitectónico',municipios,key='arq_municipios')
        only_blocks=st.checkbox('Analizar solo bloques completos existentes',value=True,
            disabled=not {'edif_tipo','edif_tiporeg'}.issubset(raw.columns),key='arq_bloques')
        objetivo=st.selectbox('Indicador que queremos entender',['demanda_calefaccion','demanda_refrigeracion','epnren','emisiones'],
                             format_func=ETIQUETAS.get,key='arq_objetivo')
        minimo=st.select_slider('Mínimo de otros certificados para comparar',options=[10,20,30,50],value=20,key='arq_minimo')
        modo=st.radio('Magnitud para comprobar la estabilidad',['superficie','anual'],
                      format_func=lambda v:'Por m²' if v=='superficie' else 'Total anual calculado',horizontal=True,key='arq_modo')
        ajustar=st.checkbox('Calcular también el modelo estadístico ajustado',value=False,key='arq_ajustar',
            help='Regresión descriptiva con validación en cinco particiones separadas por grupos. No entrena un asistente IA.')
    working=raw.copy()
    mcol='edif_muni' if 'edif_muni' in working else 'municipio'
    if selected and mcol in working:working=working[working[mcol].isin(selected)]
    if only_blocks and {'edif_tipo','edif_tiporeg'}.issubset(working.columns):
        working=working[working.edif_tipo.eq('BloqueDeViviendaCompleto') & working.edif_tiporeg.eq('Edificio Existente')]
    st.caption(f'Incluidos {len(working):,} de {len(raw):,} certificados · versión de análisis {VERSION}'.replace(',','.'))
    if working.empty:
        st.warning('No hay certificados con los filtros actuales. Amplía la selección.');return
    if not {'edif_tipo','edif_tiporeg'}.issubset(working.columns):
        st.info('El archivo no permite comprobar la selección de bloques completos existentes. Se conserva su tipología declarada cuando existe.')
    with st.spinner('Revisando variables y comparando certificados…'):
        d,audit,peers,profiles,stable,weights,model=calcular(working,objetivo,minimo,modo,ajustar,date.today().year)
    n_peer=int(peers.mediana_comparables.notna().sum())
    c1,c2,c3,c4=st.columns(4)
    c1.metric('Certificados analizados',f'{len(d):,}'.replace(',','.'))
    c2.metric('Con indicador seleccionado',f'{d[objetivo].notna().sum():,}'.replace(',','.'))
    c3.metric('Con comparables',f'{n_peer:,}'.replace(',','.'))
    c4.metric('Servicios coherentes',f'{d.servicios_coherentes.sum():,}'.replace(',','.'))
    tabs=st.tabs(['Variables y calidad','Edificios semejantes','Relaciones y diferencias','Perfiles y contexto social','Estabilidad y descarga'])
    with tabs[0]:
        st.subheader('Qué información se puede utilizar')
        st.dataframe(audit.rename(columns={'variable':'Variable','columna_fuente':'Columna de origen','filas':'Filas','utilizables':'Utilizables','ausentes':'Ausentes','no_utilizables':'No utilizables'}),hide_index=True,width='stretch')
        st.caption('La cobertura mide disponibilidad tras controles, no exactitud física. El original se conserva en la descarga. Los valores ≥10⁷ se apartan del análisis ampliado y mantienen su motivo; las reglas no cambian el ranking anterior.')
        st.write(f'Alertas exploratorias: {int(d.alerta_demanda_extrema.sum())} con demanda >1.000 kWh/m²·año; {int(d.alerta_compacidad_extrema.sum())} con compacidad >100 m³/m². Se conservan en la descripción y se apartan del modelo ajustado.')
        st.caption(f'{int(d.alerta_anio_redondeado.sum())} años terminan en cero. Puede haber años aproximados; esta señal no demuestra error ni justifica eliminarlos.')
        st.link_button('Consultar significado oficial de los campos',FUENTE)
        with st.expander('Definiciones y reglas'):
            st.write('Compacidad = volumen habitable / superficie de envolvente no adiabática (m³/m²). Las demandas son calculadas bajo condiciones del CEE. Los periodos hasta 1979, 1980–2006, 2007–2013 y desde 2014 son tramos analíticos: no acreditan cumplimiento normativo.')
            st.write('El año utilizable es entero entre 1800 y el año actual. Compacidad y rendimiento deben ser positivos; demandas y servicios admiten cero. Un rendimiento numérico no acredita un equipo medido o real. Los campos de rendimiento se auditan y quedan fuera del modelo por su calidad y diferencias de codificación.')
    with tabs[1]:
        st.subheader('Comparar con casos de características semejantes')
        st.write(f'Se exige la misma tipología, zona climática, época y tramo de superficie, con al menos {minimo} otros certificados válidos. Cada caso queda fuera del cálculo de su referencia.')
        st.caption('Superficie: hasta 500 m², más de 500 a 1.500 m² y más de 1.500 m². No se igualan orientación, reformas, ocupación o estado de conservación. Son comparables parciales.')
        if not n_peer:st.info('No hay grupos suficientes con el indicador y las reglas elegidos. No se sustituye la referencia por una cifra inventada.')
        else:
            available=peers[peers.mediana_comparables.notna()]
            st.dataframe(available.sort_values('diferencia_mediana',ascending=False).head(1000),hide_index=True,width='stretch')
            idx=st.selectbox('Consultar un certificado',list(available.index),format_func=lambda i:str(available.loc[i,'id_visual']),key='arq_certificado')
            row=available.loc[idx];unit='kg CO₂e/m²·año' if objetivo=='emisiones' else 'kWh/m²·año'
            st.write(f"Su valor es {row[objetivo]:.2f} {unit}; la mediana de los otros {int(row.comparables)} casos es {row.mediana_comparables:.2f}. La diferencia es {row.diferencia_mediana:+.2f} {unit}.")
            st.caption('La diferencia describe el certificado y su grupo. No calcula ahorro alcanzable ni identifica una patología constructiva.')
    with tabs[2]:
        st.subheader('Qué diferencias aparecen entre características')
        grupo=st.selectbox('Comparar por',['epoca','normativa','sistema_calefaccion','vector_calefaccion','zona_climatica','tramo_superficie','tipo_certificado'],key='arq_grupo')
        grouped=describir_grupos(d,grupo,objetivo,minimo)
        st.dataframe(grouped,hide_index=True,width='stretch')
        plot=grouped[(grouped.n>=minimo)&grouped.grupo.ne('Sin dato')]
        if len(plot):
            chart=alt.Chart(plot).mark_bar(color='#176B57').encode(x=alt.X('mediana:Q',title=ETIQUETAS[objetivo]),y=alt.Y('grupo:N',sort='-x',title=None),tooltip=['grupo','n','mediana','p25','p75'])
            st.altair_chart(grafica(chart),width='stretch')
        corr=relaciones(d,objetivo)
        st.write('Relaciones de orden entre variables')
        st.dataframe(corr,hide_index=True,width='stretch')
        st.caption('Spearman describe asociación. Cada fila indica sus pares completos; grupos, secciones y certificados pueden no ser independientes. No se presentan pruebas de significación ni conclusiones causales.')
        with st.expander('Análisis conjunto de varias características',expanded=ajustar):
            st.write('El modelo considera año, logaritmo de superficie y compacidad, zona climática y tipología. Describe log(1 + indicador). Su error se comprueba fuera de grupo y se compara con la mediana del conjunto de aprendizaje.')
            st.write('Estado: '+model['estado'])
            if model['estado']=='Calculado':
                c1,c2,c3=st.columns(3);c1.metric('Error absoluto medio del modelo',f"{model['MAE_modelo']:.2f}");c2.metric('Error de usar la mediana',f"{model['MAE_referencia']:.2f}");c3.metric('Error de la mediana de comparables',f"{model['MAE_grupo_comparable']:.2f}")
                st.caption(f"Errores en las unidades originales del indicador, sobre {model['n']} casos y {model['grupos_validacion']} grupos. Se apartaron {model['excluidos']} filas del ajuste. Un error menor supone mejor estimación en estas pruebas, no validación sobre consumos medidos.")
                st.dataframe(model['validacion'],hide_index=True,width='stretch')
                st.dataframe(model['coeficientes'],hide_index=True,width='stretch')
                st.caption('Coeficientes en log(1+y); variables numéricas estandarizadas. Las categorías se comparan con: '+json.dumps(model['referencias_categorias'],ensure_ascii=False)+'. No son porcentajes de causalidad ni importancias de rehabilitación.')
                st.caption('La referencia por comparables utiliza solo el aprendizaje, con al menos 20 casos por grupo; si faltan, usa su mediana global. El modelo debe compararse también con esta alternativa sencilla.')
            st.caption('Activa el cálculo en las reglas del análisis. Se necesitan al menos 200 casos completos y 10 grupos conocidos. Parcelas y secciones compartidas se mantienen juntas; los campos ausentes no se rellenan. El ajuste excluye los extremos exploratorios indicados.')
    with tabs[3]:
        st.subheader('Perfiles para orientar una revisión')
        st.write('Los perfiles pueden coincidir. «Demanda alta entre similares» significa superar el P75 de otros casos comparables. La coincidencia social usa EPNR >P75 y renta <P25, calculados sobre el mismo grupo con ambas variables.')
        st.caption('Son umbrales relativos exploratorios. No diagnostican vulnerabilidad de hogares, patologías ni una solución de obra. Los valores desconocidos permanecen sin clasificar.')
        summary=[]
        for col,label in [('demanda_alta_entre_similares','Demanda de calefacción alta entre similares'),('coincidencia_energetica_social','EPNR elevada y renta territorial baja')]:
            s=profiles[col];summary.append({'perfil':label,'con_informacion':int(s.notna().sum()),'cumplen':int(s.fillna(False).sum()),'sin_informacion':int(s.isna().sum())})
        st.dataframe(pd.DataFrame(summary),hide_index=True,width='stretch')
        st.dataframe(profiles.head(1000),hide_index=True,width='stretch')
        social_group=st.selectbox('Cruzar el contexto social por',['epoca','sistema_calefaccion','municipio'],key='arq_social_grupo')
        social=resumen_social(d,social_group)
        st.dataframe(social,hide_index=True,width='stretch')
        st.caption('La cobertura puede variar entre grupos. La renta se resume por certificado: las secciones repetidas participan varias veces. Los umbrales sociales se calculan en el conjunto con información utilizable, no en cada grupo por separado.')
        shares=[c for c in d if c.startswith('porcentaje_final_')]
        service=d.loc[d.servicios_coherentes,shares].median().dropna()
        if len(service):
            st.write('Mediana del porcentaje de energía final por servicio, solo en repartos coherentes')
            st.dataframe(service.rename('mediana_porcentaje').rename_axis('servicio').reset_index(),hide_index=True,width='stretch')
            st.caption('Las medianas independientes no tienen por qué sumar 100 %. La suma de servicios se contrasta con el total del certificado, con tolerancia máxima de 0,2 kWh/m²·año o 0,5 % del total.')
    with tabs[4]:
        st.subheader('Qué prioridades se mantienen')
        if weights.empty:st.info('Se necesitan al menos 20 certificados con EPNR, emisiones y renta utilizables para comparar las mismas filas en todas las configuraciones.')
        else:
            st.dataframe(weights,hide_index=True,width='stretch')
            st.dataframe(stable.sort_values('frecuencia_porcentaje',ascending=False,kind='stable').head(1000),hide_index=True,width='stretch')
            st.caption('La frecuencia se refiere exclusivamente a las seis combinaciones ensayadas y al primer 10 % redondeado hacia arriba. No es una probabilidad de necesitar rehabilitación. Percentiles recalculados sobre los mismos casos completos; empates del corte por orden de entrada.')
        st.subheader('Conclusiones verificables del análisis')
        conclusions=[f'Se analizan {len(d)} certificados del archivo importado; {int(d[objetivo].notna().sum())} tienen el indicador seleccionado utilizable.',
                     f'La comparación por {objetivo} dispone de referencia suficiente para {n_peer} certificados, exigiendo {minimo} otros casos por grupo.',
                     f'El reparto por servicios supera los controles en {int(d.servicios_coherentes.sum())} certificados. Las restantes filas no reciben porcentajes de reparto.',
                     f'La coincidencia energética y social se puede clasificar en {int(profiles.coincidencia_energetica_social.notna().sum())} certificados; {int(profiles.coincidencia_energetica_social.fillna(False).sum())} superan simultáneamente los umbrales definidos.']
        epoch=describir_grupos(d,'epoca',objetivo,minimo)
        qualified=epoch[epoch.n.ge(minimo) & epoch.grupo.ne('Sin dato') & epoch.mediana.notna()]
        if len(qualified)>=2:
            high=qualified.loc[qualified.mediana.idxmax()];low=qualified.loc[qualified.mediana.idxmin()]
            unit='kg CO₂e/m²·año' if objetivo=='emisiones' else 'kWh/m²·año'
            conclusions.append(f"Entre las épocas con al menos {minimo} casos válidos, la mediana mayor corresponde a {high.grupo}: {high.mediana:.2f} {unit} (n={int(high.n)}); la menor, a {low.grupo}: {low.mediana:.2f} (n={int(low.n)}). Es una comparación descriptiva sin ajustar por las demás características.")
        associations=relaciones(d,objetivo).dropna(subset=['spearman'])
        if len(associations):
            strongest=associations.loc[associations.spearman.abs().idxmax()]
            conclusions.append(f"Entre las relaciones numéricas examinadas por pares, la mayor asociación absoluta con el indicador corresponde a {strongest.variable}: Spearman {strongest.spearman:.3f}, con {int(strongest.n_pares)} pares completos. No establece causalidad.")
        if model['estado']=='Calculado':
            better=model['MAE_modelo']<model['MAE_referencia']
            conclusions.append(f"En validación por grupos, el modelo obtiene MAE {model['MAE_modelo']:.2f} frente a {model['MAE_referencia']:.2f} de la mediana de aprendizaje. {'Mejora' if better else 'No mejora'} esa referencia en estas pruebas.")
            better_peer=model['MAE_modelo']<model['MAE_grupo_comparable']
            conclusions.append(f"Frente a la mediana de comparables, con MAE {model['MAE_grupo_comparable']:.2f}, el modelo {'mejora' if better_peer else 'no mejora'} esa alternativa sencilla.")
        for sentence in conclusions:st.write('• '+sentence)
        st.caption('Estas conclusiones describen el archivo y la configuración actuales. Las relaciones no prueban causas y los CEE no se convierten en consumos medidos.')
        tables={'variables_preparadas':d,'auditoria_variables':audit,'comparacion_similares':peers,
                'relaciones_spearman':relaciones(d,objetivo),'perfiles':profiles,'estabilidad':stable,'combinaciones_pesos':weights,
                'cruce_social_epoca':resumen_social(d,'epoca'),'conclusiones':pd.DataFrame({'texto':conclusions})}
        for group in ['epoca','normativa','sistema_calefaccion','vector_calefaccion','zona_climatica','tramo_superficie','tipo_certificado']:
            tables['comparacion_'+group]=describir_grupos(d,group,objetivo,minimo)
        if model['estado']=='Calculado':
            for key in ['coeficientes','validacion','predicciones']:tables['modelo_'+key]=model[key]
        metadata={'archivo':nombre,'sha256_archivo':huella,'sha256_datos_aplicados':hashlib.sha256(working.to_json().encode()).hexdigest(),
                  'anio_control':date.today().year,
                  'filas_importadas':len(raw),'filas_incluidas':len(d),'municipios':selected,'solo_bloques_existentes':only_blocks and {'edif_tipo','edif_tiporeg'}.issubset(working.columns),
                  'objetivo':objetivo,'minimo_otros_comparables':minimo,'magnitud_estabilidad':modo,
                  'modelo':{k:v for k,v in model.items() if not isinstance(v,pd.DataFrame)},
                  'reglas':'Ver ANALISIS_ARQUITECTONICO.md; CEE calculado, asociaciones exploratorias, sin IA ni ahorros de obra'}
        st.download_button('Descargar análisis completo (ZIP)',exportar(tables,metadata),
            'Analisis_arquitectonico_CEE.zip','application/zip',width='stretch',key='arq_descarga')
        st.caption('Todas las filas en la descarga; tablas de pantalla limitadas a 1.000. Incluye auditoría, resultados, conclusiones, parámetros y huellas del conjunto.')
    return {'indices':list(working.index),'metadatos':metadata,'conclusiones':conclusions,
            'auditoria':audit,'grupos_epoca':describir_grupos(d,'epoca',objetivo,minimo),
            'perfiles':pd.DataFrame(summary),'modelo':model['estado']}
