"""Reproduce el análisis desde CSV/ZIP sin tocar el conjunto activo ni sus revisiones."""
import argparse
from datetime import date
import hashlib
import json
from pathlib import Path
import time
import pandas as pd
from motor import cargar_archivo
from analisis_arquitectonico import *


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--entrada',type=Path,required=True)
    parser.add_argument('--salida',type=Path,required=True)
    parser.add_argument('--modelo',action='store_true')
    parser.add_argument('--minimo',type=int,default=20)
    parser.add_argument('--anio-control',type=int,default=date.today().year)
    args=parser.parse_args()
    if args.minimo<2:parser.error('El mínimo debe ser al menos 2.')
    if args.salida.exists() and any(args.salida.iterdir()):parser.error('Utiliza una carpeta de salida nueva o vacía para conservar resultados anteriores.')
    start=time.time();blob=args.entrada.read_bytes();raw=cargar_archivo(args.entrada.name,blob)
    d,audit=preparar(raw,args.anio_control)
    peers=comparar_similares(d,minimo=args.minimo);profile=perfiles(d,peers)
    stable,weights=estabilidad(d)
    tables={'variables_preparadas':d,'auditoria':audit,'comparacion_similares':peers,'perfiles':profile,
            'estabilidad':stable,'pesos':weights,'relaciones':relaciones(d,'demanda_calefaccion'),
            'cruce_social_epoca':resumen_social(d,'epoca')}
    for group in ('epoca','sistema_calefaccion','vector_calefaccion','normativa'):
        tables['demanda_por_'+group]=describir_grupos(d,group,'demanda_calefaccion',args.minimo)
    model=modelo_ajustado(d) if args.modelo else {'estado':'No solicitado'}
    for key in ('coeficientes','validacion','predicciones'):
        if key in model:tables['modelo_'+key]=model[key]
    meta={'archivo':args.entrada.name,'sha256_archivo':hashlib.sha256(blob).hexdigest(),
          'sha256_datos_aplicados':hashlib.sha256(raw.to_json().encode()).hexdigest(),
          'filas':len(d),'anio_control':args.anio_control,'minimo_otros_comparables':args.minimo,
          'objetivo':'demanda_calefaccion','modo_estabilidad':'superficie','filtros':'Todas las filas del archivo de entrada',
          'comparables_suficientes':int(peers.mediana_comparables.notna().sum()),
          'servicios_coherentes':int(d.servicios_coherentes.sum()),
          'demanda_alta_entre_similares':int(profile.demanda_alta_entre_similares.fillna(False).sum()),
          'coincidencia_energetica_social':int(profile.coincidencia_energetica_social.fillna(False).sum()),
          'modelo':{k:v for k,v in model.items() if not isinstance(v,pd.DataFrame)},'segundos':time.time()-start}
    args.salida.mkdir(parents=True,exist_ok=True)
    for name,frame in tables.items():frame.to_csv(args.salida/(name+'.csv'),index=False,sep=';',decimal=',',encoding='utf-8-sig')
    (args.salida/'analisis_completo.zip').write_bytes(exportar(tables,meta))
    (args.salida/'resumen.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps(meta,ensure_ascii=False,indent=2))


if __name__=='__main__':main()
