"""Análisis descriptivo de CEE. No modifica el motor de prioridades ni usa IA.

Las reglas, unidades y restricciones se documentan en ANALISIS_ARQUITECTONICO.md.
"""
from datetime import date
import hashlib
import io
import json
from zipfile import ZipFile, ZIP_DEFLATED
import numpy as np
import pandas as pd
from motor import normalizar, _a_numero, porcentaje_relativo

VERSION = '1.0.0'
FUENTE = 'https://datos.comunidad.madrid/dataset/registro_certificados_eficiencia_energetica/resource/4e42b49c-bb6b-485a-a7b7-8f760f356855'
NUMEROS = {
    'anio_construccion': ('edif_año', 'anio_construccion'),
    'compacidad': ('edif_compac', 'compacidad_m3_m2'),
    'demanda_calefaccion': ('elec_demcalef', 'demanda_calefaccion_kwh_m2_anio'),
    'demanda_refrigeracion': ('elec_demrefrig', 'demanda_refrigeracion_kwh_m2_anio'),
    'final_calefaccion': ('final_calef', 'cee_calef_kwh_m2_anio'),
    'final_refrigeracion': ('final_refrig', 'cee_refrig_kwh_m2_anio'),
    'final_acs': ('final_acs', 'cee_acs_kwh_m2_anio'),
    'final_iluminacion': ('final_ilu', 'cee_ilu_kwh_m2_anio'),
    'rendimiento_calefaccion': ('calefac_rendim',),
}
TEXTOS = {
    'normativa': ('edif_norma', 'normativa'),
    'zona_climatica': ('edif_zonaclim', 'zona_climatica'),
    'sistema_calefaccion': ('calefac_tipo', 'sistema_calefaccion'),
    'vector_calefaccion': ('calefac_vector', 'vector_calefaccion'),
    'sistema_acs': ('acs_tipo', 'sistema_acs'),
    'modo_calefaccion': ('calefac_modo',),
}
ETIQUETAS = {
    'epnren': 'EPNR (kWh/m²·año)', 'emisiones': 'Emisiones CEE (kg CO₂e/m²·año)',
    'energia_final': 'Energía final CEE (kWh/m²·año)',
    'demanda_calefaccion': 'Demanda de calefacción (kWh/m²·año)',
    'demanda_refrigeracion': 'Demanda de refrigeración (kWh/m²·año)',
    'anio_construccion': 'Año declarado', 'compacidad': 'Compacidad (m³/m²)',
    'superficie_m2': 'Superficie CEE (m²)', 'renta_territorial': 'Renta (€/persona·año)',
}


def preparar(raw, anio_max=None):
    """Conserva filas e índice; separa valor original, preparado y motivo de ausencia."""
    if not raw.index.is_unique:
        raise ValueError('El índice de filas debe ser único para mantener la trazabilidad.')
    d, _ = normalizar(raw)
    audit = []
    headers = {str(c).strip().lower(): c for c in raw}
    for dest, aliases in {**NUMEROS, **TEXTOS}.items():
        col = next((headers[a.lower()] for a in aliases if a.lower() in headers), None)
        original = raw[col].astype('string').str.strip() if col else pd.Series(pd.NA, index=raw.index, dtype='string')
        d[dest+'_original'] = original
        absent = original.isna() | original.fillna('').isin(['', 'nan', 'None', 'null'])
        if dest in NUMEROS:
            value = _a_numero(original)
            reason = pd.Series('', index=d.index, dtype='string')
            reason.loc[absent] = 'Ausente'
            reason.loc[~absent & value.isna()] = 'No numérico o no finito'
            sentinel = value.ge(1e7)
            reason.loc[sentinel] = 'Valor de relleno o extremo no interpretable (≥10⁷)'
            invalid = value.lt(0)
            if dest == 'anio_construccion':
                invalid = value.lt(1800) | value.gt(anio_max or date.today().year) | value.mod(1).ne(0)
            if dest in ('compacidad', 'rendimiento_calefaccion'):
                invalid |= value.le(0)
            reason.loc[invalid & ~absent & ~sentinel & value.notna()] = 'Fuera del dominio analítico'
            value = value.mask(reason.ne(''))
            d[dest] = value
            d[dest+'_estado'] = reason.replace('', 'Utilizable para descripción')
        else:
            value = original.mask(absent)
            d[dest] = value
            d[dest+'_estado'] = pd.Series(np.where(value.notna(), 'Categoría declarada', 'Ausente'), index=d.index)
        audit.append({'variable': dest, 'columna_fuente': str(col) if col else 'No disponible',
                      'filas': len(d), 'utilizables': int(value.notna().sum()),
                      'ausentes': int(absent.sum()), 'no_utilizables': int((~absent & value.isna()).sum())})
    for col in ('epnren', 'emisiones', 'energia_final', 'superficie_m2', 'renta_territorial'):
        d[col] = d[col].mask(d[col].lt(0) | d[col].ge(1e7))
    d['superficie_m2'] = d.superficie_m2.where(d.superficie_m2.gt(0))
    d['renta_territorial'] = d.renta_territorial.where(d.renta_territorial.gt(0))
    d['epoca'] = pd.cut(d.anio_construccion, [1799, 1979, 2006, 2013, anio_max or date.today().year],
                         labels=['Hasta 1979', '1980–2006', '2007–2013', 'Desde 2014']).astype('string')
    d['tramo_superficie'] = pd.cut(d.superficie_m2, [0, 500, 1500, np.inf],
                                  labels=['Hasta 500 m²', 'Más de 500 a 1.500 m²', 'Más de 1.500 m²']).astype('string')
    d['alerta_demanda_extrema'] = d.demanda_calefaccion.gt(1000) | d.demanda_refrigeracion.gt(1000)
    d['alerta_compacidad_extrema'] = d.compacidad.gt(100)
    d['alerta_anio_redondeado'] = d.anio_construccion.mod(10).eq(0)
    services = ['final_calefaccion', 'final_refrigeracion', 'final_acs', 'final_iluminacion']
    total = d[services].sum(axis=1, min_count=4)
    tolerance = np.maximum(.2, .005*d.energia_final)
    coherent = total.notna() & d.energia_final.gt(0) & (total-d.energia_final).abs().le(tolerance)
    d['servicios_coherentes'] = coherent
    for name in services:
        d['porcentaje_'+name] = (100*d[name]/d.energia_final).where(coherent)
    return d, pd.DataFrame(audit)


def comparar_similares(d, objetivo='demanda_calefaccion', minimo=20):
    """Referencia leave-one-out: el caso nunca participa en su propia mediana."""
    keys = ['tipo_certificado', 'zona_climatica', 'epoca', 'tramo_superficie']
    out = d[['id_visual', *keys, objetivo]].copy()
    out['comparables'] = 0
    for c in ('mediana_comparables', 'p75_comparables', 'percentil_comparables', 'diferencia_mediana', 'diferencia_porcentaje'):
        out[c] = np.nan
    valid = d.dropna(subset=keys+[objetivo])
    for _, group in valid.groupby(keys, sort=True):
        values = group[objetivo].to_numpy(float)
        out.loc[group.index, 'comparables'] = len(group)-1
        if len(group)-1 < minimo:
            continue
        for pos, idx in enumerate(group.index):
            others = np.delete(values, pos)
            med = float(np.median(others)); value = values[pos]
            out.loc[idx, ['mediana_comparables','p75_comparables','percentil_comparables','diferencia_mediana','diferencia_porcentaje']] = [
                med, np.quantile(others,.75), 100*(np.sum(others<value)+.5*np.sum(others==value))/len(others),
                value-med, 100*(value-med)/med if med>0 else np.nan]
    out['estado_comparacion'] = np.where(out.mediana_comparables.notna(), 'Comparación disponible', 'Datos o comparables insuficientes')
    return out


def describir_grupos(d, grupo, objetivo, minimo=20):
    rows = []
    for label, group in d.groupby(grupo, dropna=False, sort=True):
        values = group[objetivo].dropna()
        rows.append({'grupo': 'Sin dato' if pd.isna(label) else str(label), 'filas': len(group), 'n': len(values),
                     'mediana': values.median() if len(values) else np.nan,
                     'p25': values.quantile(.25) if len(values) else np.nan,
                     'p75': values.quantile(.75) if len(values) else np.nan,
                     'estado': 'Descriptivo' if len(values)>=minimo else 'Grupo pequeño; lectura limitada'})
    return pd.DataFrame(rows, columns=['grupo','filas','n','mediana','p25','p75','estado'])


def relaciones(d, objetivo):
    rows=[]
    for col in ['anio_construccion','compacidad','superficie_m2','renta_territorial']:
        pair=d[[col,objetivo]].dropna()
        rho=pair[col].rank().corr(pair[objetivo].rank()) if len(pair)>=20 and pair[col].nunique()>1 and pair[objetivo].nunique()>1 else np.nan
        rows.append({'variable':col,'n_pares':len(pair),'spearman':rho})
    return pd.DataFrame(rows)


def modelo_ajustado(d, objetivo='demanda_calefaccion'):
    """Regresión descriptiva log(1+y), sin inferencia causal ni etiquetas de prioridad.

    Validación fuera de grupo: cada sección o parcela conocida se mantiene junta.
    Preprocesado y categorías se estiman solo con la partición de aprendizaje.
    """
    cols=['anio_construccion','superficie_m2','compacidad','zona_climatica','tipo_certificado']
    base=d.dropna(subset=cols+[objetivo]).copy()
    base=base[base.superficie_m2.gt(0) & base.compacidad.le(100) & base[objetivo].le(1000)]
    result={'estado':'Datos insuficientes','n':len(base),'excluidos':len(d)-len(base),'objetivo':objetivo,
            'coeficientes':pd.DataFrame(),'validacion':pd.DataFrame(),'predicciones':pd.DataFrame()}
    if len(base)<200:return result
    # Componentes conectados: unir parcelas repetidas y secciones compartidas.
    parent={i:i for i in base.index}
    def find(i):
        while parent[i]!=i:parent[i]=parent[parent[i]];i=parent[i]
        return i
    for col in ('referencia','seccion_censal'):
        keys=base[col].astype('string').str.strip()
        if col=='referencia':keys=keys.str.upper().str.replace(' ','',regex=False).str[:14]
        known={}
        for i,key in keys.items():
            if pd.isna(key) or not key or key in ('nan','None'):continue
            if key in known:parent[find(i)]=find(known[key])
            else:known[key]=i
    roots=pd.Series({i:find(i) for i in base.index})
    labels={k:n for n,k in enumerate(sorted(roots.unique(),key=str))}
    groups=roots.map(labels)
    result['grupos_validacion']=groups.nunique()
    if groups.nunique()<10:
        result['estado']='Menos de 10 grupos independientes conocidos para validar';return result
    rng=np.random.default_rng(20261112)
    assignment={g:i%5 for i,g in enumerate(rng.permutation(groups.unique()))}
    folds=groups.map(assignment)
    def design(train,test):
        def nums(frame):
            return pd.DataFrame({'Año / 10':frame.anio_construccion/10,
                                 'Log superficie':np.log(frame.superficie_m2),
                                 'Log compacidad':np.log(frame.compacidad)},index=frame.index)
        x=nums(train);xt=nums(test);mean=x.mean();std=x.std(ddof=0)
        usable=std.index[std.gt(1e-10)]
        x=(x[usable]-mean[usable])/std[usable];xt=(xt[usable]-mean[usable])/std[usable]
        x.insert(0,'Constante',1.);xt.insert(0,'Constante',1.)
        references={}
        for col in ('zona_climatica','tipo_certificado'):
            counts=train[col].value_counts();levels=counts[counts.ge(20)].index.tolist()
            tr=train[col].where(train[col].isin(levels),'Otros');te=test[col].where(test[col].isin(levels),'Otros')
            actual=sorted(tr.unique());references[col]=actual[0]
            for level in actual[1:]:
                name=col+' = '+str(level);x[name]=tr.eq(level).astype(float);xt[name]=te.eq(level).astype(float)
        return x,xt,references
    predictions=pd.Series(np.nan,index=base.index);baseline=predictions.copy();peer_baseline=predictions.copy();fold_rows=[]
    for fold in range(5):
        train=base.loc[folds.ne(fold)];test=base.loc[folds.eq(fold)]
        if len(train)<100 or len(test)<10:
            result['estado']='Particiones demasiado pequeñas o desequilibradas';return result
        x,xt,_=design(train,test)
        if np.linalg.matrix_rank(x.to_numpy(dtype=float))<x.shape[1]:
            result['estado']='Variables redundantes; modelo no identificable';return result
        coef=np.linalg.lstsq(x.to_numpy(dtype=float),np.log1p(train[objetivo].to_numpy(dtype=float)),rcond=None)[0]
        pred=np.maximum(0,np.expm1(np.clip(xt.to_numpy(dtype=float)@coef,0,20)))
        predictions.loc[test.index]=pred
        median=train[objetivo].median();baseline.loc[test.index]=median
        keys=['epoca','zona_climatica','tipo_certificado','tramo_superficie']
        lookup=train.groupby(keys)[objetivo].agg(['median','count'])
        lookup=lookup[lookup['count'].ge(20)]['median']
        reference=[]
        for _,row in test.iterrows():
            key=tuple(row[k] for k in keys)
            reference.append(float(lookup.get(key,median)))
        peer_baseline.loc[test.index]=reference
        fold_rows.append({'particion':fold+1,'aprendizaje':len(train),'prueba':len(test),
                          'grupos_aprendizaje':groups.loc[train.index].nunique(),'grupos_prueba':groups.loc[test.index].nunique(),
                          'MAE_modelo':float(np.mean(np.abs(test[objetivo]-pred))),
                          'MAE_mediana_aprendizaje':float(np.mean(np.abs(test[objetivo]-median))),
                          'MAE_grupo_comparable':float(np.mean(np.abs(test[objetivo]-np.array(reference))))})
    x,_,refs=design(base,base)
    if np.linalg.matrix_rank(x.to_numpy(dtype=float))<x.shape[1]:
        result['estado']='Variables redundantes en el ajuste final';return result
    coef=np.linalg.lstsq(x.to_numpy(dtype=float),np.log1p(base[objetivo].to_numpy(dtype=float)),rcond=None)[0]
    observed=base[objetivo]
    result.update(estado='Calculado',MAE_modelo=float((observed-predictions).abs().mean()),
                  MAE_referencia=float((observed-baseline).abs().mean()),
                  MAE_grupo_comparable=float((observed-peer_baseline).abs().mean()),
                  referencias_categorias=refs,
                  coeficientes=pd.DataFrame({'termino':x.columns,'coeficiente_log1p':coef}),
                  validacion=pd.DataFrame(fold_rows),
                  predicciones=pd.DataFrame({'id_visual':base.id_visual,'observado':observed,'estimado_fuera_grupo':predictions,
                                             'referencia_mediana':baseline,'referencia_grupo_comparable':peer_baseline,'particion':folds+1,'grupo_validacion':groups,
                                             'diferencia_observado_estimado':observed-predictions}))
    return result


def perfiles(d, comparacion):
    out=pd.DataFrame(index=d.index);out['id_visual']=d.id_visual
    available=comparacion.mediana_comparables.notna()
    out['demanda_alta_entre_similares']=pd.Series(pd.NA,index=d.index,dtype='boolean')
    out.loc[available,'demanda_alta_entre_similares']=comparacion.loc[available,'demanda_calefaccion'].gt(comparacion.loc[available,'p75_comparables'])
    valid=d[['epnren','renta_territorial']].dropna()
    social=pd.Series(pd.NA,index=d.index,dtype='boolean')
    if len(valid)>=20:
        social.loc[valid.index]=valid.epnren.gt(valid.epnren.quantile(.75)) & valid.renta_territorial.lt(valid.renta_territorial.quantile(.25))
    out['coincidencia_energetica_social']=social
    shares=[c for c in d if c.startswith('porcentaje_final_')]
    out['servicio_mayoritario']='Sin reparto coherente'
    for col in shares:out.loc[d[col].gt(50),'servicio_mayoritario']=col.removeprefix('porcentaje_final_')
    out.loc[d.servicios_coherentes & d[shares].max(axis=1).le(50),'servicio_mayoritario']='Sin servicio >50 %'
    out['revision_orientativa']=np.where(out.demanda_alta_entre_similares.fillna(False),
        'Revisar demanda, envolvente y condiciones del CEE; estudiar medidas después de comprobar el inmueble',
        'Consultar comparación y calidad; este perfil no diagnostica una intervención')
    return out


def estabilidad(d, modo='superficie'):
    """Mismos casos completos y percentiles para todas las combinaciones."""
    from motor import calcular_escenarios, calidad
    common=d.dropna(subset=['epnren','emisiones','renta_territorial']).copy()
    if modo=='anual':common=common[common.superficie_m2.gt(0)]
    weights=[(1,0,0),(.6,.4,0),(.5,.3,.2),(.48,.32,.2),(.4,.2,.4),(.3,.2,.5)]
    out=pd.DataFrame({'id_visual':common.id_visual},index=common.index)
    if len(common)<20:return out,pd.DataFrame()
    k=int(np.ceil(.1*len(common)));count=pd.Series(0,index=common.index)
    positions=[];meta=[]
    for w in weights:
        r=calcular_escenarios(calidad(common),w,modo);score=r.escenario_3_con_contexto_social
        chosen=score.sort_values(ascending=False,kind='stable').index[:k];count.loc[chosen]+=1
        pos=score.rank(ascending=False,method='average');positions.append(pos)
        meta.append({'energia':w[0],'emisiones':w[1],'social':w[2],'n':len(common),'primer_decil':k})
    ranks=pd.concat(positions,axis=1)
    out['veces_primer_decil']=count;out['configuraciones']=len(weights)
    out['frecuencia_porcentaje']=100*count/len(weights)
    out['mejor_puesto_medio']=ranks.min(axis=1);out['peor_puesto_medio']=ranks.max(axis=1)
    return out,pd.DataFrame(meta)


def resumen_social(d, grupo):
    rows=[]
    usable=d.dropna(subset=['epnren','renta_territorial'])
    e75=usable.epnren.quantile(.75);r25=usable.renta_territorial.quantile(.25)
    for label,g in d.groupby(grupo,dropna=False,sort=True):
        social=g.dropna(subset=['epnren','renta_territorial'])
        rows.append({'grupo':'Sin dato' if pd.isna(label) else str(label),'total':len(g),'con_renta_y_epnren':len(social),
                     'cobertura_porcentaje':100*len(social)/len(g),
                     'renta_mediana':social.renta_territorial.median(),
                     'coincidencias':int((social.epnren.gt(e75)&social.renta_territorial.lt(r25)).sum()) if len(usable)>=20 else pd.NA})
    return pd.DataFrame(rows)


def exportar(tablas, metadatos):
    buffer=io.BytesIO()
    with ZipFile(buffer,'w',ZIP_DEFLATED) as z:
        for name,frame in tablas.items():z.writestr(name+'.csv',frame.to_csv(index=False,sep=';',decimal=',').encode('utf-8-sig'))
        z.writestr('metodologia_y_procedencia.json',json.dumps({'version':VERSION,'diccionario':FUENTE,**metadatos},ensure_ascii=False,indent=2,default=str))
    return buffer.getvalue()
