"""Síntesis reproducible para el informe. Reutiliza los motores existentes."""
import hashlib
import json
import numpy as np
import pandas as pd
from motor import normalizar,calidad,calcular_escenarios,resumen_calidad

ESCENARIOS={'escenario_1_energia':'Energía',
    'escenario_2_energia_emisiones':'Energía y emisiones CEE',
    'escenario_3_con_contexto_social':'Energía, emisiones y entorno social'}


def fmt(value,dec=0):
    return f'{float(value):,.{dec}f}'.replace(',','_').replace('.',',').replace('_','.')


def firma(raw):
    return hashlib.sha256(raw.to_json().encode()).hexdigest()


def estadistica(serie):
    values=pd.to_numeric(serie,errors='coerce').replace([np.inf,-np.inf],np.nan).dropna()
    return {'n':len(values),'mediana':values.median() if len(values) else None,
            'p25':values.quantile(.25) if len(values) else None,
            'p75':values.quantile(.75) if len(values) else None}


def preparar(raw,nombre,huella,ranking=None,crrem=None,enlaces=None,revisiones=None):
    normalized,_=normalizar(raw)
    flags=calidad(normalized)
    cfg=ranking or {}
    indices=cfg.get('indices',list(raw.index))
    included=flags.loc[indices].copy()
    pesos=tuple(cfg.get('pesos',(.5,.3,.2)))
    modo=cfg.get('modo','superficie')
    selected=cfg.get('escenario','escenario_1_energia')
    ranked=calcular_escenarios(included,pesos,modo)
    opposite=calcular_escenarios(included,pesos,'anual' if modo=='superficie' else 'superficie')
    valid_ids=set(ranked.id_visual)
    links=[x for x in (enlaces or []) if str(x.get('id')) in valid_ids]
    changes=(ranked['puesto_'+selected]-opposite['puesto_'+selected]).abs().dropna()
    stats={col:estadistica(ranked[col].where(ranked[col].ge(0))) for col in ['epnren','emisiones','energia_final',
        'epnren_anual_cee','emisiones_anual_cee','renta_territorial']}
    available={key:int(ranked[key].notna().sum()) for key in ESCENARIOS}
    notes=[]
    n=len(ranked)
    notes.append(f'El análisis incluye {fmt(n)} registros de los {fmt(len(raw))} importados. La unidad es el certificado o fila; no se acredita que cada registro represente un edificio físico distinto.')
    energy=stats['epnren']
    if energy['n']:
        notes.append(f"La mediana de energía primaria no renovable es {fmt(energy['mediana'],2)} kWh/m²·año, calculada sobre {fmt(energy['n'])} certificados. El 50 % central se sitúa entre {fmt(energy['p25'],2)} y {fmt(energy['p75'],2)} kWh/m²·año. Son valores CEE, no consumos medidos.")
    else:notes.append('No hay energía primaria no renovable utilizable para describir el comportamiento energético. No se imputa ni se sustituye por cero.')
    social=stats['renta_territorial']
    notes.append(f"La renta territorial está disponible para {fmt(social['n'])} de {fmt(n)} registros. Los restantes no reciben puntuación social cuando su peso es positivo. Esta cobertura limita la comparación y no permite inferir la renta ni la vulnerabilidad de sus residentes.")
    if available[selected]:
        top=ranked.sort_values(selected,ascending=False,kind='stable').dropna(subset=[selected]).iloc[0]
        ties=int(ranked[selected].eq(top[selected]).sum())
        notes.append(f"En el criterio «{ESCENARIOS[selected]}», la puntuación máxima es {fmt(top[selected],2)}/100 y corresponde a {ties} certificado(s). El primer identificador mostrado es {top.id_visual}. Esta prioridad es relativa a la muestra y no acredita rentabilidad, ahorro potencial ni urgencia técnica.")
    else:notes.append('El criterio elegido no se puede ordenar con los datos disponibles; no se presentan prioridades inventadas.')
    if len(changes):notes.append(f'Cambiar entre intensidad por m² y total anual modifica los puestos en una mediana de {fmt(changes.median(),1)} posiciones absolutas, sobre {fmt(len(changes))} registros comparables. Ambas lecturas deben conservarse: describen magnitudes distintas.')
    else:notes.append('No hay registros comparables suficientes para contrastar los puestos por m² y total anual.')
    try:
        from modulo_energia_cee import diagnosticar,resumen
        diagnostic=resumen(diagnosticar(raw.loc[indices]))
        diagnostic_error=None
    except (ValueError,KeyError,TypeError) as exc:
        diagnostic={};diagnostic_error=str(exc)
    return {'nombre':nombre,'huella':huella,'firma_datos':firma(raw),'total':len(raw),'n':n,
            'raw':raw.loc[indices].copy(),'ranking':ranked,'opuesto':opposite,'pesos':pesos,'modo':modo,
            'escenario':selected,'filtros':cfg.get('filtros','Sin filtros; conjunto completo'),
            'estadisticas':stats,'disponibles':available,'conclusiones':notes,
            'calidad_total':resumen_calidad(flags),'calidad_incluida':resumen_calidad(included),
            'diagnostico':diagnostic,'error_diagnostico':diagnostic_error,'enlaces':links,
            'revisiones':[x for x in (revisiones or []) if str(x.get('id')) in valid_ids],
            'crrem_config':crrem,'cambios_mediana':float(changes.median()) if len(changes) else None}


def resumir_crrem(summary,frames,config,operacional=False):
    """Instantánea ligera de resultados ya calculados por la herramienta."""
    from copy import deepcopy
    result={'config':deepcopy(config),'summary':summary.copy(deep=True),'operacional':operacional,
            'n':len(summary),'base':int(config['base']),'error':None,'pendiente':False,
            'series':{},'individual':None}
    chosen=config.get('certificado')
    if chosen not in frames:chosen=next(iter(frames),None)
    if chosen:result['individual']=(chosen,frames[chosen].copy(deep=True))
    if frames and not operacional:
        for metric in ['eui_kwh_m2_anio','ci_kg_m2_anio']:
            values=pd.DataFrame({key:frame[metric] for key,frame in frames.items()})
            bands=values.quantile([.1,.5,.9],axis=1).T
            bands.columns=['P10','Mediana','P90']
            bands['Umbral']=next(iter(frames.values()))['umbral_eui' if metric.startswith('eui') else 'umbral_ci']
            result['series'][metric]=bands
    return result


def recuperar_crrem(datos):
    """Lee resultados de la sesión. No genera nuevos escenarios al exportar."""
    from copy import deepcopy
    item=datos.get('crrem_config') or {}
    cfg=item.get('config',{})
    result=deepcopy(item.get('resultado')) if item.get('resultado') else {
        'config':cfg,'summary':pd.DataFrame(),'operacional':cfg.get('modo')=='Evaluación con entradas documentadas',
        'n':0,'base':cfg.get('base',2025),'error':None,'pendiente':True,'series':{},'individual':None}
    try:
        from crrem import verificar_fuentes
        result['fuentes']=verificar_fuentes()
    except (ValueError,OSError) as exc:
        result.update(error=str(exc),summary=pd.DataFrame(),series={},individual=None)
    return result
