"""Ejecuta las funciones de análisis sobre los 15 CEE oficiales congelados."""
from pathlib import Path
import json
import pandas as pd
from motor import cargar_archivo,normalizar,calidad,calcular_escenarios,exportar_csv
from modulo_energia_cee import diagnosticar,resumen

ROOT=Path(__file__).parent


def evaluar():
    folder=ROOT/'datos_piloto'
    path=folder/'CEE_Madrid_15_reales.csv'
    raw=cargar_archivo(path.name,path.read_bytes())
    n,aliases=normalizar(raw)
    q=calidad(n)
    relative=calcular_escenarios(q,modo='superficie')
    absolute=calcular_escenarios(q,modo='anual')
    comparison=pd.DataFrame({'certificado':n.id_visual,'superficie_cee_m2':n.superficie_m2,
                            'epnr_cee_kwh_m2_anio':n.epnren,'epnr_cee_kwh_anio':relative.epnren_anual_cee})
    for key,title in [('escenario_1_energia','energia'),('escenario_2_energia_emisiones','energia_emisiones')]:
        comparison['puesto_m2_'+title]=relative['puesto_'+key]
        comparison['puesto_anual_'+title]=absolute['puesto_'+key]
    comparison['cambio_energia_m2_a_anual']=comparison['puesto_m2_energia']-comparison['puesto_anual_energia']
    (folder/'comparacion_puestos.csv').write_bytes(exportar_csv(comparison))
    sensitivity=[]
    for mode in ['superficie','anual']:
        for energy,carbon in [(1.,0.),(.8,.2),(.6,.4),(.5,.5),(.2,.8),(0.,1.)]:
            result=calcular_escenarios(q,pesos=(energy,carbon,0.),modo=mode)
            result=result[['id_visual','escenario_3_con_contexto_social','puesto_escenario_3_con_contexto_social']].copy()
            result['modo']=mode;result['peso_energia']=energy;result['peso_emisiones']=carbon;result['peso_social']=0
            sensitivity.append(result)
    (folder/'sensibilidad_sin_componente_social.csv').write_bytes(exportar_csv(pd.concat(sensitivity,ignore_index=True)))
    state=n[['id_visual']].copy()
    state['CRREM_operacional']='No evaluable: faltan GIA, usos completos y consumos operacionales por vector'
    state['renta_territorial_enlazada']=False
    state['anio_desalineamiento']=pd.NA
    (folder/'estado_CRREM_y_social.csv').write_bytes(exportar_csv(state))
    corr=n[['epnren','emisiones','energia_final','superficie_m2']].corr(method='pearson')
    (folder/'correlaciones_exploratorias.csv').write_bytes(exportar_csv(corr.rename_axis('variable').reset_index()))
    top=lambda result,key:result.sort_values(key,ascending=False).id_visual.head(5).tolist()
    report={'n':len(n),'columnas_reconocidas':aliases,'controles_cee':resumen(diagnosticar(raw)),
            'top5_epnr_por_m2':top(relative,'escenario_1_energia'),
            'top5_epnr_anual':top(absolute,'escenario_1_energia'),
            'certificados_cambian_puesto_epnr':int(comparison.cambio_energia_m2_a_anual.ne(0).sum()),
            'correlacion_pearson_epnr_emisiones':float(corr.loc['epnren','emisiones']),
            'escenario_social_con_peso_20_evaluable':int(relative.escenario_3_con_contexto_social.notna().sum()),
            'evaluaciones_CRREM_operacionales':0,
            'alcance':'Selección intencional de 15 certificados, no representa el parque madrileño; energía y emisiones calculadas CEE, no medidas ni ahorros.'}
    (folder/'resumen_piloto.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False,indent=2))


if __name__=='__main__': evaluar()
