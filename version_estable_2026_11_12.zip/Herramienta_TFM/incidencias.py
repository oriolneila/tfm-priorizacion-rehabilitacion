"""Revisiones humanas locales, por conjunto, con historial y reversión explícita."""
import copy
import hashlib
import json
import re
import sqlite3
import pandas as pd
from datetime import date,datetime,timezone
from urllib.parse import urlparse
from social import ROOT,INE,consulta,interpretar_renta

DB=ROOT/'datos_usuario/revisiones.sqlite3'
ACCEPTED={'Enlace automático por parcela','Enlace revisado manualmente'}
CAT_URL='https://www.sedecatastro.gob.es/'
INE_URL='https://www.ine.es/dynt3/inebase/index.htm?capsel=12384&padre=12385'


def huella_candidato(item):
    fields=['id','referencia','direccion_cee','direccion_catastro','seccion_censal',
            'renta_media_seccion_eur_persona','anio_renta','nota_ine','fuente_renta','latitud','longitud']
    return hashlib.sha256(json.dumps({k:item.get(k) for k in fields},sort_keys=True,ensure_ascii=False).encode()).hexdigest()


def historial(cohort,path=None):
    path=path or DB
    if not path.exists():return []
    with sqlite3.connect(path) as db:
        rows=db.execute('SELECT contenido FROM revisiones WHERE conjunto=? ORDER BY numero',(cohort,)).fetchall()
    return [json.loads(x[0]) for x in rows]


def guardar_revision(cohort,base,candidato,decision,responsable,fecha,evidencia,explicacion,confirmado,path=None):
    if not re.fullmatch(r'[0-9a-f]{64}',cohort):raise ValueError('Conjunto no identificado')
    if decision not in ('Aceptar enlace','Excluir del cálculo social','Mantener pendiente'):raise ValueError('Decisión no válida')
    if not confirmado:raise ValueError('Confirma que has realizado la comprobación indicada')
    if not responsable.strip() or len(explicacion.strip())<15:raise ValueError('Indica quién revisó y explica el resultado con detalle')
    parsed=urlparse(evidencia.strip())
    if parsed.scheme not in ('https','http') or not parsed.netloc:raise ValueError('Añade un enlace válido a la fuente o evidencia consultada')
    checked=date.fromisoformat(str(fecha))
    if checked>date.today():raise ValueError('La comprobación no puede tener fecha futura')
    if base['id']!=candidato['id']:raise ValueError('El resultado corresponde a otro certificado')
    if decision=='Aceptar enlace':
        if base.get('anio_renta') and candidato.get('anio_renta')!=base['anio_renta']:
            raise ValueError('Conserva el año de renta del conjunto para no mezclar periodos en el ranking')
        # Aceptar la localización nunca crea ni modifica una renta inventada.
        a={'CUSEC':candidato.get('seccion_censal'),'dato1':candidato.get('renta_media_seccion_eur_persona'),
           'indicador1':'Renta neta media por persona','unidad1':'Euros','periodo':str(candidato.get('anio_renta','')),
           'nota1':candidato.get('nota_ine')}
        interpretar_renta([{'attributes':a}])
        if not str(candidato.get('fuente_renta','')).startswith(INE+'/'):raise ValueError('Primero consulta la renta oficial del INE para la sección comprobada')
        if base.get('nota_ine') and candidato.get('seccion_censal')==base.get('seccion_censal') and not candidato.get('nota_ine'):
            raise ValueError('Una revisión manual no elimina una limitación publicada por el INE')
    record={'id':base['id'],'huella_base':huella_candidato(base),'decision':decision,
            'responsable':responsable.strip(),'fecha_comprobacion':str(checked),'evidencia':evidencia.strip(),
            'explicacion':explicacion.strip(),'guardado_utc':datetime.now(timezone.utc).isoformat(),
            'candidato':copy.deepcopy(candidato)}
    path=path or DB
    path.parent.mkdir(parents=True,exist_ok=True)
    with sqlite3.connect(path) as db:
        db.execute('CREATE TABLE IF NOT EXISTS revisiones (numero INTEGER PRIMARY KEY AUTOINCREMENT, conjunto TEXT NOT NULL, contenido TEXT NOT NULL)')
        db.execute('INSERT INTO revisiones(conjunto,contenido) VALUES (?,?)',(cohort,json.dumps(record,ensure_ascii=False)))
    return record


def aplicar_revisiones(links,records):
    latest={x['id']:x for x in records}
    result=[]
    for original in links:
        item=copy.deepcopy(original)
        review=latest.get(item['id'])
        if review:
            if review['huella_base']!=huella_candidato(original):
                item.update(estado_social='Pendiente: datos cambiados tras revisión',motivo='La consulta cambió. Repite la comprobación; la revisión anterior se conserva en el historial.')
            else:
                item=copy.deepcopy(review['candidato'])
                item['estado_social']={'Aceptar enlace':'Enlace revisado manualmente','Excluir del cálculo social':'Excluido tras revisión','Mantener pendiente':'Pendiente tras revisión'}[review['decision']]
                item['revision_manual']={k:v for k,v in review.items() if k!='candidato'}
                item['motivo']=review['explicacion']
        result.append(item)
    return result


def consultar_seccion(section,year,cache):
    if not re.fullmatch(r'\d{10}',section):raise ValueError('La sección censal debe tener 10 dígitos, incluidos los ceros iniciales')
    # Las capas t, t-1 y t-2 se identifican por el periodo devuelto, no por suposición.
    for layer in (2,5,8):
        data,url=consulta(INE+f'/{layer}/query',{'f':'json','where':f"CUSEC='{section}'",'outFields':'*','returnGeometry':'false'},cache)
        features=data.get('features',[])
        if len(features)==1 and str(features[0]['attributes'].get('periodo'))==str(year):
            value=interpretar_renta(features)
            if value['seccion_censal']!=section:raise ValueError('El INE devolvió otra sección')
            return dict(value,fuente_renta=url)
    raise ValueError('No se encuentra esa sección y año en las capas disponibles. Conserva la incidencia pendiente; no uses otro año sin revisión metodológica.')


def guia(item):
    if item.get('nota_ine'):
        return 'Renta con limitación del INE','Lee la nota original y comprueba que el dato es una cota. No busques ingresos personales. Puedes documentar la revisión, excluir el caso o usar la cota como sensibilidad desde la barra lateral; seguirá siendo una cota.'
    if item.get('estado_social')=='Enlace automático por parcela':
        return 'Comprobación voluntaria','El enlace automático no tiene incidencias abiertas. Puedes contrastarlo o excluirlo si encuentras una discrepancia.'
    return 'Localización o renta por comprobar','Busca la referencia en Catastro, identifica parcela y portales y compara la dirección del CEE con el domicilio catastral. Comprueba en el Atlas del INE a qué sección y año corresponde. Si son accesos de la misma parcela, explica cómo lo has comprobado; si es otra sección, introduce su código y consulta su renta oficial antes de guardar.'


def completar_bases(raw,links,ids):
    if not ids:return copy.deepcopy(links)
    from motor import normalizar
    normalized,_=normalizar(raw)
    if normalized.id_visual.duplicated().any():raise ValueError('Asigna identificadores únicos a los CEE antes de revisar incidencias')
    bases=copy.deepcopy(links)
    known={x['id'] for x in bases}
    for _,row in normalized.loc[normalized.id_visual.isin(ids)].iterrows():
        if row.id_visual not in known:
            text=lambda key:'' if pd.isna(row[key]) else str(row[key])
            bases.append({'id':str(row.id_visual),'direccion_cee':text('direccion'),'referencia':text('referencia'),
                          'estado_social':'Pendiente','renta_media_seccion_eur_persona':None})
    return bases
