"""Pantalla de marca previa a Inicio. No carga datos ni muestra navegación."""
import streamlit as st
from apariencia import ICONO


def abrir():
    st.session_state['acceso_abierto']=True
    st.session_state['navegacion_principal']='Inicio'
    st.session_state['animar_entrada_inicio']=True


def mostrar_acceso():
    st.markdown('''<style>
[data-testid="stHeader"], [data-testid="stSidebar"], [data-testid="stToolbar"] {display:none;}
[data-testid="stMainBlockContainer"] {padding:0;}
.st-key-pantalla_acceso {position:fixed; inset:0; width:100%; height:100svh; max-width:none; margin:0; padding:24px; display:flex; flex-direction:column; align-items:center; justify-content:center; text-align:center; overflow:auto;}
.acceso-marca {text-align:center;}
.acceso-marca [data-testid="stHeadingWithActionElements"] {display:flex; justify-content:center;}
.acceso-marca h1, .acceso-marca p {text-align:center;}
.st-key-pantalla_acceso [data-testid="stButton"] {display:flex; justify-content:center; margin-top:30px;}
.acceso-logo {width:100px; height:100px; padding:12px; border-radius:23px; background:#205743; color:white; margin:0 auto 28px;}
.acceso-logo svg {display:block; width:100%; height:100%;}
.acceso-marca h1 {font-family:'Segoe UI',Arial,sans-serif; font-size:clamp(32px,5vw,48px); font-weight:650; letter-spacing:-1.5px; line-height:1.15; color:#224a3a; margin:0; padding:0;}
.acceso-marca p {font-size:12px; font-weight:600; letter-spacing:3px; color:#617d69; margin:15px 0 0;}
</style>''',unsafe_allow_html=True)
    with st.container(key='pantalla_acceso'):
        st.markdown(f'<div class="acceso-marca"><div class="acceso-logo">{ICONO}</div><h1>Rehabilitación</h1><p>ANÁLISIS SOSTENIBLE</p></div>',unsafe_allow_html=True)
        st.button('Abrir la herramienta',type='primary',on_click=abrir)
