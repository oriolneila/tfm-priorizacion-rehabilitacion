"""Guía autónoma para comprobar incidencias y conservar su resolución."""
import copy
import json
import sqlite3
from datetime import date
import pandas as pd
import streamlit as st
from motor import normalizar,exportar_csv
from social import ROOT
from incidencias import (ACCEPTED,CAT_URL,INE_URL,historial,guardar_revision,
                         consultar_seccion,completar_bases,guia)


def mostrar_incidencias(raw):
    st.write('Aquí puedes entender qué falta, comprobarlo en una fuente oficial y registrar el resultado. Guardar una revisión actualiza el cálculo y conserva las decisiones anteriores. No necesitas consultar el chat.')
    normalized,_=normalizar(raw)
    cohort=st.session_state['social_conjunto']
    try:
        bases=completar_bases(raw,st.session_state.get('social_base',[]),normalized.id_visual.tolist())
        history=historial(cohort)
    except (ValueError,OSError,sqlite3.Error) as exc:
        st.error(str(exc));return
    current={x['id']:x for x in st.session_state.get('social_actual',[])}
    items=[current.get(x['id'],x) for x in bases]
    if not items:
        st.info('No hay certificados en el conjunto activo.');return
    if 'incidencia_guardada' in st.session_state:st.success(st.session_state.pop('incidencia_guardada'))
    st.subheader('1. Elige un caso')
    def state(item):
        if item['estado_social'].startswith('Excluido'):return 'Excluido por revisión'
        if item.get('revision_manual') and item['estado_social'] in ACCEPTED:return 'Revisado con limitación' if item.get('nota_ine') else 'Revisado y aceptado'
        if item.get('nota_ine'):return 'Revisar limitación de renta'
        if item['estado_social'] not in ACCEPTED:return 'Pendiente de comprobación'
        return 'Sin incidencia automática'
    overview=pd.DataFrame([{'CEE':x['id'],'Estado':state(x),'Dirección CEE':x.get('direccion_cee',''),
                            'Motivo':x.get('motivo','') or x.get('nota_ine','')} for x in items])
    pending=[x for x in items if state(x) in ('Pendiente de comprobación','Revisar limitación de renta')]
    only=st.checkbox('Mostrar solo casos pendientes o con limitaciones',value=True)
    options=pending if only else items
    if not options:
        st.success('No quedan casos pendientes en esta vista. Desmarca el filtro para consultar o cambiar una revisión.')
        options=items
    st.dataframe(overview.loc[overview.CEE.isin([x['id'] for x in options])],hide_index=True,width='stretch')
    identity=st.selectbox('Incidencia que quieres resolver',[x['id'] for x in options],
                          format_func=lambda key:key+' · '+state(next(x for x in options if x['id']==key)))
    item=next(x for x in items if x['id']==identity)
    base=next(x for x in bases if x['id']==identity)
    st.subheader('2. Qué debes comprobar')
    title,instructions=guia(item)
    st.warning(title) if identity in [x['id'] for x in pending] else st.info(title)
    st.write(instructions)
    st.write('**Dirección del certificado:** '+str(item.get('direccion_cee') or 'No disponible'))
    st.write('**Domicilio de Catastro:** '+str(item.get('direccion_catastro') or 'No disponible'))
    st.write('**Referencia para buscar:** '+str(item.get('referencia') or 'No disponible'))
    st.markdown(f'1. [Abrir el buscador y mapa de Catastro]({CAT_URL}). Entra en «Buscador de inmuebles y visor cartográfico», busca la referencia indicada y comprueba parcela, accesos y números de portal.\n2. [Abrir los resultados del Atlas de renta del INE]({INE_URL}). En «Resultados por municipios, distritos y secciones censales», selecciona la provincia y comprueba sección, indicador «Renta neta media por persona», año y notas. [Ver la cartografía oficial del INE](https://www.ine.es/servergis2/rest/services/ws/ADRH_renta_media_por_persona/MapServer?f=jsapi). No uses el código postal como sección censal.\n3. Anota el enlace o documento consultado y explica cómo has resuelto la discrepancia. Si no puedes confirmarlo, conserva el caso pendiente o exclúyelo del cálculo social.')
    if item.get('seccion_censal'):
        st.write(f"**Sección candidata:** {item['seccion_censal']} · **Año:** {item.get('anio_renta','sin dato')} · **Renta publicada:** {item.get('renta_media_seccion_eur_persona','sin dato')} €/persona·año")
    if item.get('nota_ine'):st.warning('Nota original del INE: '+item['nota_ine']+' Aceptar la localización mantiene esta limitación. La cota solo entra en el ranking si activas la opción de cotas en la barra lateral.')
    st.subheader('3. Introduce lo que has comprobado')
    st.caption('Si confirmas la localización y la sección candidata, conserva la renta publicada. Si has encontrado otra sección, consulta su renta oficial aquí antes de guardar. No se permite escribir una renta sin fuente.')
    mode=st.radio('Resultado de la comprobación territorial',['Confirmar la sección candidata','He comprobado otra sección censal'],key='inc_modo_'+identity)
    candidate=copy.deepcopy(item)
    if mode=='He comprobado otra sección censal':
        section=st.text_input('Código de sección censal comprobado (10 dígitos)',value=str(item.get('seccion_censal','')),key='inc_seccion_'+identity)
        year=int(st.number_input('Año de renta que has comprobado',min_value=2015,max_value=date.today().year,value=int(item.get('anio_renta') or 2024),disabled=bool(base.get('anio_renta')),key='inc_anio_'+identity))
        st.caption('Se conserva el año de la renta candidata para no mezclar periodos en el ranking.')
        if st.button('Consultar renta oficial de esa sección',key='inc_consultar_'+identity):
            try:
                with st.spinner('Consultando la sección y año en el INE…'):
                    official=consultar_seccion(section.strip(),year,ROOT/'fuentes/social_respuestas')
                st.session_state['inc_candidato_'+identity]={'section':section.strip(),'year':year,'valor':official}
                st.success('Renta oficial obtenida. Revisa el resultado y guarda la comprobación debajo.')
            except (ValueError,OSError) as exc:st.error(f'No se puede obtener una renta verificable: {exc}')
        fetched=st.session_state.get('inc_candidato_'+identity)
        ready=bool(fetched and fetched['section']==section.strip() and fetched['year']==year)
        if ready:
            candidate.update(fetched['valor'])
            candidate['metodo']='Sección comprobada manualmente; renta consultada al INE por código y año'
            st.write(f"Renta oficial: {candidate['renta_media_seccion_eur_persona']:.2f} €/persona·año · {candidate['anio_renta']}")
            if candidate.get('nota_ine'):st.warning(candidate['nota_ine'])
        else:st.info('Consulta la sección indicada para poder aceptar este cambio. Puedes dejar el caso pendiente sin consulta.')
    else:
        ready=bool(candidate.get('fuente_renta') and candidate.get('seccion_censal'))
    with st.form('revision_'+identity):
        decision=st.selectbox('Decisión tras la comprobación',['Mantener pendiente','Aceptar enlace','Excluir del cálculo social'])
        reviewer=st.text_input('Persona que realiza la revisión')
        checked=st.date_input('Fecha de la comprobación',value=date.today(),max_value=date.today())
        evidence=st.text_input('Enlace de la fuente o evidencia consultada',placeholder='https://…')
        explanation=st.text_area('Resultado y justificación',placeholder='Explica qué parcela y portal has comprobado, qué discrepancia has resuelto y qué documento lo acredita. No introduzcas datos personales de residentes.')
        confirm=st.checkbox('He realizado la comprobación y la justificación describe lo observado')
        save=st.form_submit_button('Guardar resultado de la comprobación')
    if save:
        try:
            if decision=='Aceptar enlace' and not ready:raise ValueError('Primero obtén la renta oficial para la sección comprobada')
            guardar_revision(cohort,base,candidate,decision,reviewer,checked,evidence,explanation,confirm)
        except (ValueError,OSError,sqlite3.Error) as exc:st.error(f'No se ha guardado: {exc}')
        else:
            st.session_state['incidencia_guardada']='Comprobación guardada en este equipo. El conjunto y el ranking ya usan la nueva decisión; puedes revisarla de nuevo sin perder el historial.'
            st.rerun()
    st.subheader('4. Historial y copia de seguridad')
    st.caption('Las revisiones se guardan en datos_usuario/revisiones.sqlite3 y se recuperan al reiniciar en este equipo para el mismo archivo CEE. No son una firma ni una verificación de identidad. Para conservar una copia legible, descarga el historial; para trasladar el trabajo completo, copia también la carpeta datos_usuario. No se borran decisiones anteriores: para revertir una aceptación, guarda una nueva revisión como pendiente o excluida.')
    if history:
        rows=[{k:v for k,v in x.items() if k!='candidato'} for x in history]
        view=pd.DataFrame(rows)[['id','decision','responsable','fecha_comprobacion','evidencia','explicacion','guardado_utc']]
        st.dataframe(view.rename(columns={'id':'CEE','decision':'Decisión','responsable':'Revisor',
            'fecha_comprobacion':'Fecha comprobada','explicacion':'Justificación','guardado_utc':'Guardado (UTC)'}),
            hide_index=True,width='stretch',column_config={'evidencia':st.column_config.LinkColumn('Evidencia',display_text='Abrir fuente')})
        st.download_button('Descargar historial de comprobaciones',json.dumps({'sha256_cee':cohort,'revisiones':history},ensure_ascii=False,indent=2).encode(),'historial_comprobaciones.json')
    else:st.info('Aún no se ha guardado ninguna revisión para este conjunto. Los casos de ejemplo no se dan por resueltos automáticamente.')
    with st.expander('Otras incidencias: datos del CEE y entradas CRREM'):
        st.write('Si falta superficie, tipo de inmueble o un indicador energético, abre «Diagnóstico energético CEE / pre-CRREM» y contrasta el dato con el certificado original. Corrige el CSV y vuelve a cargarlo; es un nuevo conjunto y no hereda revisiones del archivo anterior. No rellenes consumos desconocidos con cero.')
        st.write('Para CRREM operacional se necesitan superficie GIA y consumos completos documentados. Aporta esos datos en «Alineamiento CRREM → Evaluación con entradas documentadas». Resolver una incidencia social no convierte el CEE en consumo medido ni completa esos campos.')
