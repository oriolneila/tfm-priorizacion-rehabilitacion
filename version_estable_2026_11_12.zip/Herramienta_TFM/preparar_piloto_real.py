"""Selecciona 15 certificados del ZIP oficial, sin generar valores energéticos."""
from pathlib import Path
import argparse
import hashlib
import json
import pandas as pd
from motor import cargar_archivo, normalizar, calidad, calcular_escenarios, exportar_csv
from modulo_energia_cee import diagnosticar, resumen

ROOT=Path(__file__).parent
SOURCE_URL='https://datos.comunidad.madrid/catalogo/dataset/971ee067-8ec1-47a1-a973-f1f3704d5d20/resource/5d7a31ec-322a-4868-877a-24885251ce5c/download/registro_certificados_eficiencia_energetica_2025.zip'
EXPECTED='15c3dbe564f7dbd5e5ca757679838513379fb0035019cfd89538b0ef463531b0'


def preparar(source):
    blob=source.read_bytes()
    digest=hashlib.sha256(blob).hexdigest()
    if digest!=EXPECTED:
        raise ValueError('La fuente difiere de la versión congelada; revisar antes de seleccionar')
    raw=cargar_archivo(source.name,blob)
    # Posición lógica CSV, base 1 sin contar cabecera ni líneas vacías.
    raw['fila_fuente']=range(1,len(raw)+1)
    date=pd.to_datetime(raw['edif_fecha'],format='%d/%m/%Y',errors='coerce')
    reference=raw['edif_refcat'].str.upper().str.replace(' ','',regex=False)
    target=(raw['edif_tipo'].eq('BloqueDeViviendaCompleto') &
            raw['edif_tiporeg'].eq('Edificio Existente') &
            raw['edif_muni'].str.strip().str.upper().eq('MADRID') & date.dt.year.eq(2025))
    subset=raw.loc[target].copy()
    n,_=normalizar(subset)
    diag=diagnosticar(subset)
    valid=diag['candidato_precrrem'] & ~diag['alerta_extremo_cee'] & n['epnren'].gt(0) & n['emisiones'].ge(0)
    valid &= reference.loc[subset.index].str.fullmatch(r'[A-Z0-9]{14}(?:[A-Z0-9]{6})?',na=False)
    subset=subset.loc[valid].copy()
    subset['grupo_referencia']=reference.loc[subset.index].str[:14]
    selected=subset.drop_duplicates('grupo_referencia',keep='first').head(15).copy()
    if len(selected)!=15:
        raise ValueError(f'Solo hay {len(selected)} candidatos disponibles')
    columns=['edif_tiporeg','edif_tipo','edif_muni','edif_zonaclim','edif_año','edif_fecha','edif_superf',
             'final_global','final_calef','final_refrig','final_acs','final_ilu','norenov_global',
             'norenov_co2global','cal_norenovglobal','cal_co2global','calefac_vector','refrig_vector','acs_vector']
    sample=selected[columns].copy()
    sample.insert(0,'id',[f'CEE_MAD_{i:02}' for i in range(1,16)])
    sample['origen_dato']='CEE Madrid 2025 oficial; indicador calculado, no medido'
    sample=sample.reset_index(drop=True)
    output=ROOT/'datos_piloto'
    output.mkdir(exist_ok=True)
    path=output/'CEE_Madrid_15_reales.csv'
    path.write_bytes(exportar_csv(sample))
    controls=resumen(diagnosticar(sample))
    audit={'fuente_url':SOURCE_URL,'licencia':'Creative Commons Attribution, según portal de Madrid',
           'consulta':'2026-10-24','sha256_zip':digest,'sha256_muestra':hashlib.sha256(path.read_bytes()).hexdigest(),
           'registros_fuente':len(raw),'cohorte_madrid_bloque_existente_certificado_2025':int(target.sum()),
           'candidatos_controles':len(subset),'muestra':len(sample),
           'seleccion':'Primeros 15 registros en orden original que superan controles, con primeros 14 caracteres de referencia distintos. Selección intencional para prueba, no aleatoria ni representativa. No acredita edificio único.',
           'controles':controls,
           'campos_no_disponibles':['renta territorial enlazada','sección censal','GIA conciliada','consumos operacionales 12 meses completos'],
           'filas':[{'id':sample.iloc[i]['id'],'fila_logica_csv':int(row['fila_fuente']),
                     'sha256_fila_original':hashlib.sha256(json.dumps(raw.loc[row.name].drop('fila_fuente').to_dict(),ensure_ascii=False,sort_keys=True).encode()).hexdigest()}
                    for i,(_,row) in enumerate(selected.iterrows())]}
    (output/'seleccion_y_procedencia.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8')
    normalized,_=normalizar(sample)
    flags=calidad(normalized)
    for mode in ['superficie','anual']:
        result=calcular_escenarios(flags,modo=mode)
        result['fuente_sha256']=digest
        (output/f'resultados_{mode}.csv').write_bytes(exportar_csv(result))
    (output/'diagnostico_CEE.csv').write_bytes(exportar_csv(diagnosticar(sample)))
    print(json.dumps({k:v for k,v in audit.items() if k!='filas'},ensure_ascii=False,indent=2))


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('zip_oficial',type=Path)
    preparar(parser.parse_args().zip_oficial)
