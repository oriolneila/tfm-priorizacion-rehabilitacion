# Piloto de la herramienta con 15 CEE reales

**Actualización posterior:** se implementó el cálculo energético y de carbono, validado con los ejemplos oficiales CRREM. La interfaz ahora permite escenarios CEE y evaluación con entradas documentadas; el estado y las restricciones se detallan en `CRREM_IMPLEMENTACION.md`. El informe siguiente conserva la revisión inicial del piloto, cuando el módulo solo mostraba curvas y bloqueos.

24 de octubre de 2026. Esta es la referencia del estado actual; las limitaciones de disponibilidad descritas en documentos anteriores corresponden a revisiones previas.

## Fuente y selección

Se localizó en Descargas el ZIP completo CEE 2025 y se descargó de nuevo desde el portal oficial para contrastarlo. Ambos archivos tienen SHA-256 `15c3dbe564f7dbd5e5ca757679838513379fb0035019cfd89538b0ef463531b0` y contienen 110.650 registros. La copia congelada queda en `publicacion/datos_originales`.

Fuente: Comunidad de Madrid, Registro de Certificados de Eficiencia Energética de Edificios, recurso CEEE 2025: https://datos.comunidad.madrid/dataset/registro_certificados_eficiencia_energetica/resource/5d7a31ec-322a-4868-877a-24885251ce5c. Licencia indicada en el portal: Creative Commons Attribution. Archivo de 17.757.703 bytes; consulta del 24/10/2026. El portal publica 2024/2025 en ZIP por su volumen. El año del recurso no equivale necesariamente al del certificado: aquí se exige además fecha de certificado en 2025.

Selección reproducible: municipio Madrid, bloque de viviendas completo, edificio existente, certificado fechado en 2025. Hay 8.071 registros que cumplen esos criterios. Tras controles CEE, energía primaria y emisiones válidas, referencias de formato simple y exclusión de extremos exploratorios quedan 6.459 candidatos. Se toman los primeros 15 en orden de origen con primeros 14 caracteres catastrales distintos. No se seleccionan por resultado del ranking ni por año de cruce. Es una muestra intencional para prueba funcional, no aleatoria ni representativa del parque urbano.

Se conservan sin modificar los indicadores y vectores originales. Los únicos campos nuevos de entrada son un identificador de análisis (`CEE_MAD_01` a `CEE_MAD_15`) y la etiqueta de procedencia. No se generan direcciones, rentas, consumos ni superficies. Se omiten dirección, número registral y referencia catastral en la muestra de uso; se registra la posición lógica y huella de cada fila en `datos_piloto/seleccion_y_procedencia.json`. La ausencia de referencia en esta copia aparece como aviso de calidad; no prueba que falte en la fuente.

## Qué se ha probado

| Función | Resultado en los 15 certificados |
|---|---|
| Lectura, normalización, unidades y trazabilidad | 15 filas comparadas campo a campo con el ZIP oficial |
| Calidad de energía, emisiones, superficie y tipo | Sin faltantes en esas variables; referencias omitidas y renta ausente señaladas |
| Energía por m² y anual calculada | 15 resultados en ambos modos |
| Energía + emisiones CEE | 15 resultados en ambos modos |
| Escenario con componente social de peso positivo | Sin puntuación: no hay renta territorial enlazada |
| Sensibilidad a pesos de energía/emisiones | Seis pares de pesos, en ambos modos; peso social cero declarado |
| Diagnóstico CEE previo a CRREM | 15 pasan los controles exploratorios definidos |
| Trayectorias CRREM | Curvas oficiales de España residencial disponibles; se muestran aparte del CEE |
| Estado operacional CRREM | Los 15 quedan no evaluables: faltan GIA conciliada y consumo completo de 12 meses por vector |
| Exportación y recarga | Se conservan identificadores y valores anuales |

Superar los controles numéricos CEE no acredita corrección física del certificado. Los ceros de servicios se conservan como aparecen en el registro; no permiten deducir por sí solos que el servicio no exista en el edificio. La suma de servicios puede ser coherente y seguir sin representar todos los usos. Los cocientes entre energía primaria y final necesitan una investigación específica, no una conversión genérica.

## Primeros resultados del piloto

En energía primaria no renovable por m², las cinco primeras posiciones son `CEE_MAD_06`, `CEE_MAD_13`, `CEE_MAD_08`, `CEE_MAD_02` y `CEE_MAD_03`. En energía primaria anual calculada pasan a ser `CEE_MAD_11`, `CEE_MAD_15`, `CEE_MAD_09`, `CEE_MAD_12` y `CEE_MAD_06`.

Cambian de puesto 14 de los 15 certificados al pasar de EPNR por m² a EPNR anual. Por ejemplo, `CEE_MAD_11` pasa del puesto 11 al 1, mientras `CEE_MAD_06` pasa del 1 al 5. Esta diferencia refleja objetivos distintos y la influencia del tamaño; no prueba que un ranking sea mejor.

La correlación de Pearson entre EPNR y emisiones CEE en estos 15 certificados es aproximadamente 0,9644. La fuerte asociación aconseja discutir su redundancia al ponderarlas; no se extrapola a todo Madrid. Los resultados son magnitudes calculadas de certificación, no consumos medidos, ahorros reales ni una recomendación de intervención.

## Cambios de la aplicación

El conjunto ficticio y su selector se han eliminado de la aplicación y de la nueva entrega. También se retiraron los paquetes generados anteriores que contenían ese ejemplo. El ZIP original v0.3 aportado por el usuario permanece intacto en Descargas como fuente histórica. Los casos artificiales de las pruebas automáticas están aislados en `tests`; no se cargan como edificios ni como resultados del TFM.

Los tres módulos usan ahora el mismo conjunto activo de 15 CEE reales, sin recurrir a la muestra antigua de 80 filas. Se mantienen datos ausentes como ausentes. No se genera una curva operacional del edificio a partir del CEE ni se rellenan rentas ficticias para completar el escenario social.

## Reproducción y archivos

Desde la carpeta de la herramienta, con Python 3.12 y dependencias de `requirements-lock.txt`:

```sh
python preparar_piloto_real.py ../datos_originales/registro_certificados_eficiencia_energetica_2025.zip
python evaluar_piloto_real.py
python -m pytest -q
python -m streamlit run app.py --global.developmentMode false
```

En una entrega descomprimida sin el ZIP completo, descargarlo desde la fuente citada y pasarlo como argumento al primer comando. Las pruebas funcionales usan la muestra incluida; el contraste completo de filas exige también el ZIP original.

`datos_piloto/` contiene la muestra real, procedencia, diagnóstico, resultados de ambos modos, comparación de puestos, sensibilidad sin componente social, correlaciones, estado CRREM/social y resumen JSON. Las capturas de pantalla documentan la revisión de la aplicación local. La nueva entrega no incluye casos ficticios de estudio.

Faltan la guía docente, la auditoría completa anterior, el enlace social territorial, GIA y datos operacionales/estimaciones calibradas. No se considera terminado el caso académico completo ni una evaluación operacional CRREM.

## Uso de IA

Codex/OpenAI asistió en localizar y contrastar la fuente, seleccionar filas mediante reglas explícitas, retirar los ejemplos de la aplicación, ejecutar pruebas, revisar la interfaz y documentar el piloto. No se han generado datos energéticos del estudio mediante IA. El autor debe revisar las reglas y las interpretaciones.
