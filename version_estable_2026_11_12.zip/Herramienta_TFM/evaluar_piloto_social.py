"""Regenera el ranking social sin red con la cohorte y respuestas congeladas."""
import json
import hashlib
import pandas as pd
from social import ROOT,aplicar_enlaces
from motor import cargar_archivo,normalizar,calidad,calcular_escenarios,exportar_csv

folder=ROOT/'datos_piloto'
path=folder/'CEE_Madrid_15_reales.csv'
raw=cargar_archivo(path.name,path.read_bytes())
location=pd.read_csv(folder/'localizacion_CEE_15.csv',dtype=str,keep_default_na=False)
raw=raw.merge(location.drop(columns='edif_muni'),on='id',validate='one_to_one')
links=json.loads((folder/'enlaces_sociales.json').read_text(encoding='utf-8'))
normalized,_=normalizar(aplicar_enlaces(raw,links))
for mode in ['superficie','anual']:
    result=calcular_escenarios(calidad(normalized),pesos=(.5,.3,.2),modo=mode)
    result['sha256_cee']=hashlib.sha256(path.read_bytes()).hexdigest()
    result['sha256_enlaces_sociales']=hashlib.sha256((folder/'enlaces_sociales.json').read_bytes()).hexdigest()
    result['pesos_energia_emisiones_social']='50;30;20'
    (folder/f'resultados_sociales_{mode}.csv').write_bytes(exportar_csv(result))
pd.DataFrame(links).to_csv(folder/'auditoria_social_INE.csv',sep=';',index=False,encoding='utf-8-sig')
print('Ranking social reproducido: 12 utilizables / 15 CEE; pesos exploratorios 50/30/20; renta 2024.')
