"""Informe PDF local, con conclusiones trazables y figuras vectoriales."""
from io import BytesIO
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
from html import escape
import hashlib
import json
import pandas as pd
import numpy as np
import reportlab
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,PageBreak,KeepTogether
from reportlab.graphics.shapes import Drawing,Line,Rect,String,PolyLine
from informe_datos import preparar,recuperar_crrem,ESCENARIOS

VERDE=colors.HexColor('#205743')
SUAVE=colors.HexColor('#edf3ef')
AZUL=colors.HexColor('#437da2')
GRIS=colors.HexColor('#5e7265')
W=A4[0]-96
VERSION='1.0'


def numero(value,dec=0):
    if value is None or pd.isna(value):return 'Sin dato'
    return f'{float(value):,.{dec}f}'.replace(',','_').replace('.',',').replace('_','.')


def estilos():
    # Tipografías incluidas por ReportLab: no requiere fuentes web o del equipo.
    folder=Path(reportlab.__file__).parent/'fonts'
    for name,file in [('Informe','Vera.ttf'),('Informe-Bold','VeraBd.ttf')]:
        if name not in pdfmetrics.getRegisteredFontNames():pdfmetrics.registerFont(TTFont(name,str(folder/file)))
    pdfmetrics.registerFontFamily('Informe',normal='Informe',bold='Informe-Bold',italic='Informe',boldItalic='Informe-Bold')
    ss=getSampleStyleSheet()
    ss.add(ParagraphStyle('Texto',fontName='Informe',fontSize=9,leading=14,textColor=colors.HexColor('#293c31'),spaceAfter=9))
    ss.add(ParagraphStyle('TituloInforme',parent=ss['Texto'],fontName='Informe-Bold',fontSize=30,leading=37,textColor=VERDE,spaceAfter=20))
    ss.add(ParagraphStyle('SeccionInforme',parent=ss['Texto'],fontName='Informe-Bold',fontSize=19,leading=25,textColor=VERDE,spaceAfter=16,keepWithNext=True))
    ss.add(ParagraphStyle('SubInforme',parent=ss['Texto'],fontName='Informe-Bold',fontSize=11,leading=16,textColor=VERDE,spaceBefore=10,keepWithNext=True))
    ss.add(ParagraphStyle('NotaInforme',parent=ss['Texto'],fontSize=7.5,leading=11,textColor=GRIS,spaceAfter=10))
    ss.add(ParagraphStyle('CeldaInforme',parent=ss['Texto'],fontSize=7.5,leading=11,spaceAfter=0))
    return ss


def tabla(headers,rows,widths,ss):
    def cell(x):return Paragraph(escape(str(x)),ss['CeldaInforme'])
    values=[[cell(x) for x in headers]]+[[cell(x) for x in row] for row in rows]
    if len(values)==1:values.append([cell('Sin datos')]+[cell('') for _ in headers[1:]])
    t=Table(values,colWidths=widths,repeatRows=1,hAlign='LEFT')
    t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),SUAVE),('VALIGN',(0,0),(-1,-1),'TOP'),
        ('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#f8faf8')]),
        ('LINEBELOW',(0,0),(-1,0),.6,colors.HexColor('#cedbd1')),
        ('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),
        ('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6)]))
    return t


def barras(labels,values,title,unit='Certificados'):
    height=max(85,45+16*len(labels))
    d=Drawing(W,height)
    d.add(String(0,height-12,title,fontName='Informe-Bold',fontSize=9,fillColor=VERDE))
    maxv=max(values) if len(values) and max(values)>0 else 1
    if unit=='Puntuación':maxv=100
    left=170;span=W-left-45
    for i,(label,value) in enumerate(zip(labels,values)):
        y=height-36-i*16
        text=str(label);text=text[:27]+'...' if len(text)>30 else text
        d.add(String(0,y+2,text,fontName='Informe',fontSize=7.5,fillColor=GRIS))
        d.add(Rect(left,y,span,10,fillColor=SUAVE,strokeColor=None))
        d.add(Rect(left,y,span*float(value)/maxv,10,fillColor=VERDE,strokeColor=None))
        d.add(String(left+span+6,y+1,numero(value,1 if unit=='Puntuación' else 0),fontName='Informe',fontSize=7.5,fillColor=VERDE))
    d.add(String(left,8,unit,fontName='Informe',fontSize=7,fillColor=GRIS))
    return d


def lineas(frame,title,unit):
    d=Drawing(W,245)
    d.add(String(0,232,title,fontName='Informe-Bold',fontSize=9,fillColor=VERDE))
    d.add(String(0,216,unit,fontName='Informe',fontSize=8,fillColor=GRIS))
    x0,y0=48,48;pw,ph=W-65,150
    data=frame.astype(float).replace([np.inf,-np.inf],np.nan)
    maxv=float(data.max().max()) if data.notna().any().any() else 1
    maxv=max(maxv*1.08,1)
    years=np.asarray(data.index,dtype=float);lo,hi=min(years),max(years)
    palette=[colors.HexColor('#aac4d4'),AZUL,colors.HexColor('#7d9eb4'),VERDE]
    for k in range(5):
        yy=y0+ph*k/4
        d.add(Line(x0,yy,x0+pw,yy,strokeColor=colors.HexColor('#e0e8e2'),strokeWidth=.5))
        d.add(String(x0-6,yy-3,numero(maxv*k/4,1),textAnchor='end',fontName='Informe',fontSize=7,fillColor=GRIS))
    for year in sorted(set([int(lo),int(hi)]+list(range(int(lo)+1,int(hi),5)))):
        xx=x0+pw*(year-lo)/max(hi-lo,1)
        d.add(String(xx,y0-14,str(year),textAnchor='middle',fontName='Informe',fontSize=7,fillColor=GRIS))
    for i,col in enumerate(data):
        vals=data[col].to_numpy();mask=np.isfinite(vals)
        points=[(x0+pw*(x-lo)/max(hi-lo,1),y0+ph*y/maxv) for x,y in zip(years[mask],vals[mask])]
        color=VERDE if col in ('Umbral','CRREM') else palette[i%len(palette)]
        if len(points)>1:d.add(PolyLine(points,strokeColor=color,strokeWidth=2 if col in ('Mediana','Umbral','CRREM') else 1,fillColor=None))
        xx=8+(i%4)*122
        d.add(Line(xx,12,xx+13,12,strokeColor=color,strokeWidth=2))
        d.add(String(xx+18,9,str(col)[:22],fontName='Informe',fontSize=7,fillColor=GRIS))
    return d


def generar_pdf(raw,nombre,huella,ranking=None,crrem=None,enlaces=None,revisiones=None):
    datos=preparar(raw,nombre,huella,ranking,crrem,enlaces,revisiones)
    climate=recuperar_crrem(datos)
    ss=estilos();story=[]
    now=datetime.now(ZoneInfo('Europe/Madrid'))
    def p(text,style='Texto'):story.append(Paragraph(escape(str(text)),ss[style]))
    def section(title):
        story.append(PageBreak());p(title,'SeccionInforme')
    def note(text):p(text,'NotaInforme')
    ranked=datos['ranking'];n=datos['n'];selected=datos['escenario']
    story.append(Spacer(1,48))
    p('REHABILITACIÓN · ANÁLISIS SOSTENIBLE','SubInforme')
    story.append(Spacer(1,25));p('Informe de análisis\n y conclusiones'.replace('\n',''),'TituloInforme')
    p('Síntesis de los certificados energéticos, las prioridades relativas, el entorno social y los escenarios de descarbonización.')
    story.append(Spacer(1,22))
    story.append(tabla(['Conjunto de trabajo','Alcance'],[
        [nombre,f"{numero(n)} certificados incluidos de {numero(datos['total'])} importados"],
        ['Fecha de generación',now.strftime('%d/%m/%Y · %H:%M (Europe/Madrid)')],
        ['Calidad e interpretación','CEE calculado; prioridades exploratorias; renta territorial; CRREM condicionado a entradas e hipótesis.'],
        ['Contenido','Resumen ejecutivo · datos y calidad · energía · prioridades · entorno social · CRREM · conclusiones · trazabilidad']], [W*.37,W*.63],ss))
    story.append(Spacer(1,24))
    p('Este informe no acredita consumos medidos, ahorro de una rehabilitación, vulnerabilidad individual ni validación externa de las prioridades. Las filas CEE pueden corresponder a edificios, viviendas o partes. No se suman como un parque de edificios únicos.')
    note('El informe se redacta a partir de los cálculos y coberturas del archivo analizado. Los apartados sin datos suficientes se indican expresamente.')

    section('1. Resumen ejecutivo')
    for item in datos['conclusiones']:p(item)
    summary=climate.get('summary',pd.DataFrame())
    calculated=int(summary.get('eui_escenario',pd.Series(dtype=float)).notna().sum())
    if climate.get('error'):p('No se puede generar el apartado cuantitativo CRREM: '+climate['error'])
    elif climate.get('pendiente'):p('El apartado CRREM está pendiente para la configuración actual: no se han exportado resultados calculados en esta sesión. No se crean escenarios nuevos al generar el informe.')
    elif climate.get('operacional'):
        p(f'Se han podido recalcular {numero(calculated)} entradas operacionales documentadas aportadas por el usuario. La documentación y las declaraciones de compatibilidad no equivalen a una auditoría externa o certificación CRREM.')
    else:p(f"La última ejecución CEE-CRREM recogió {numero(calculated)} escenarios calculables de {numero(climate['n'])} registros de su conjunto. Los cruces son matemáticos y dependen de las hipótesis; no constituyen años de desalineamiento operacional validados.")
    conclusion_climatica=None
    if not climate.get('pendiente') and not climate.get('error') and calculated:
        valid_summary=summary[summary.eui_escenario.notna()]
        counts=[]
        for key,label in [('cruce_energia_exploratorio','energético'),('cruce_carbono_exploratorio','de carbono')]:
            vals=valid_summary[key]
            counts.append(f"{numero(vals.notna().sum())} presentan cruce {label} hasta 2050 y {numero(vals.isna().sum())} no lo presentan en ese horizonte")
        conclusion_climatica='Entre los resultados CRREM calculables, '+'; '.join(counts)+'. Los casos no evaluables quedan fuera de este recuento. No presentar cruce hasta 2050 no acredita alineamiento permanente ni sustituye la revisión de las entradas.'
        p(conclusion_climatica)

    section('2. Datos, alcance y calidad')
    p('Configuración del informe','SubInforme')
    filtros=datos['filtros']
    if isinstance(filtros,dict):
        names={'municipios':'Municipios','tipos':'Tipos CEE','apartar_referencias_repetidas':'Apartar referencias repetidas',
            'apartar_multirreferencia':'Apartar varias referencias','apartar_sin_tipo':'Apartar registros sin tipo'}
        rows=[]
        for key,value in filtros.items():
            label=('Sí' if value else 'No') if isinstance(value,bool) else (', '.join(map(str,value)) or 'Todos') if isinstance(value,list) else str(value)
            rows.append([names.get(key,key),label])
        story.append(tabla(['Filtro','Selección'],rows,[W*.5,W*.5],ss))
    else:p('Filtros: '+str(filtros))
    p('Magnitud actual: '+('por m² y año' if datos['modo']=='superficie' else 'total anual calculado CEE')+'. Criterio seleccionado: '+ESCENARIOS[selected]+'.')
    p('Pesos del escenario social (energía / emisiones CEE / entorno social): '+' / '.join(numero(x*100,1)+' %' for x in datos['pesos'])+'. El segundo escenario conserva los pesos fijos 60 % / 40 %.')
    from apariencia import CONTROLES
    allq=datos['calidad_total'].set_index('control').registros_afectados
    rows=[[CONTROLES.get(row.control,row.control),numero(allq[row.control]),numero(row.registros_afectados)] for row in datos['calidad_incluida'].itertuples()]
    story.append(tabla(['Comprobación','Archivo completo','Incluidos'],rows,[W*.6,W*.2,W*.2],ss))
    note('Las comprobaciones cuentan incidencias, no acreditan validez física. Una misma fila puede tener varias alertas. No se sustituyen datos ausentes por cero.')
    if datos['diagnostico']:
        d=datos['diagnostico']
        p(f"El diagnóstico CEE identifica {numero(d.get('candidato_precrrem',0))} registros que cumplen los controles exploratorios de tipo, energía, servicios, superficie, suma y vectores, y {numero(d.get('alerta_extremo_cee',0))} con alerta energética extrema. Son recuentos distintos; el cálculo CRREM excluye también los extremos.")
        note('Los límites de superficie 25-100.000 m², energía final 5-1.000 kWh/m²·año para el escenario y tolerancia de suma son reglas exploratorias de la herramienta; no son umbrales oficiales CRREM.')
    elif datos['error_diagnostico']:p('Diagnóstico por servicios no disponible: '+datos['error_diagnostico'])

    section('3. Resultados energéticos y emisiones CEE')
    specs=[('epnren','EPNR','kWh/m²·año'),('energia_final','Energía final CEE','kWh/m²·año'),
        ('emisiones','Emisiones CEE','kg CO2/m²·año'),('epnren_anual_cee','EPNR anual CEE','kWh/año'),
        ('emisiones_anual_cee','Emisiones CEE anuales','kg CO2/año')]
    rows=[]
    for key,label,unit in specs:
        s=datos['estadisticas'][key]
        rows.append([label+' ('+unit+')',numero(s['n']),numero(s['mediana'],2),numero(s['p25'],2),numero(s['p75'],2)])
    story.append(tabla(['Indicador','n','Mediana','P25','P75'],rows,[W*.43,W*.1,W*.16,W*.155,W*.155],ss))
    note('Estadísticos sin ponderar sobre valores utilizables. Total anual por certificado = intensidad × superficie del mismo CEE. Los indicadores primarios y finales son magnitudes distintas; no se convierten entre sí para estimar facturas.')
    values=ranked.epnren.dropna()
    if len(values):
        counts,edges=np.histogram(values.to_numpy(),bins=min(6,max(1,len(values))))
        labels=[numero(a,0)+' a '+numero(b,0) for a,b in zip(edges[:-1],edges[1:])]
        story.append(barras(labels,counts.tolist(),'Distribución de EPNR (kWh/m²·año)'))
        note('Intervalos cerrados a la izquierda y abiertos a la derecha, salvo el último. Los valores extremos se conservan cuando el ranking no los excluye; su presencia exige revisar el certificado.')

    section('4. Prioridades y comparación de criterios')
    story.append(tabla(['Criterio','Registros con puntuación'],[[label,numero(datos['disponibles'][key])] for key,label in ESCENARIOS.items()],[W*.73,W*.27],ss))
    top=ranked.dropna(subset=[selected]).sort_values(selected,ascending=False,kind='stable').head(10)
    p('Primeros certificados del criterio seleccionado','SubInforme')
    story.append(tabla(['Puesto','Certificado','Municipio','Puntuación /100'],[
        [numero(r['puesto_'+selected]),r.id_visual,str(r.municipio) if pd.notna(r.municipio) else 'Sin dato',numero(r[selected],2)] for _,r in top.iterrows()],
        [W*.12,W*.32,W*.36,W*.2],ss))
    note('Hasta 10 filas, orden estable para empates. El puesto puede repetirse y la selección puede cortar un empate. La tabla completa se conserva en las descargas CSV de la herramienta.')
    if len(top):story.append(barras(top.id_visual.tolist(),top[selected].tolist(),'Puntuaciones relativas del criterio seleccionado','Puntuación'))
    p('Comparación por m² frente a anual','SubInforme')
    p('Mediana de cambios absolutos de puesto: '+numero(datos['cambios_mediana'],1)+'. El total anual requiere superficie válida; por ello puede cambiar la cobertura. Una posición más alta no equivale a mayor ahorro o beneficio esperado.')

    section('5. Dimensión social y revisión de incidencias')
    usable=int(ranked.renta_territorial.gt(0).sum())
    story.append(barras(['Con renta utilizable','Sin renta utilizable'],[usable,n-usable],'Cobertura social del conjunto incluido'))
    s=datos['estadisticas']['renta_territorial']
    p(f"La mediana territorial es {numero(s['mediana'],2)} €/persona·año sobre {numero(s['n'])} certificados con valor utilizable. P25: {numero(s['p25'],2)}; P75: {numero(s['p75'],2)}. Son estadísticas por certificado, no por persona ni por sección censal única.")
    links=datos['enlaces']
    if links:
        state=pd.Series([x.get('estado_social','Sin estado') for x in links]).value_counts()
        story.append(tabla(['Estado del enlace','Certificados'],[[key,numero(value)] for key,value in state.items()],[W*.78,W*.22],ss))
        years=sorted({str(x.get('anio_renta')) for x in links if x.get('anio_renta') is not None})
        p('Años de renta presentes en el complemento: '+', '.join(years)+'. No se confunden con el año del certificado.')
        bounds=sum(bool(x.get('nota_ine')) for x in links)
        p(f'Hay {numero(bounds)} enlaces con nota original del INE. Las cotas estadísticas no son valores individuales exactos; solo entran en el ranking cuando la opción correspondiente está activada.')
        limited_ids={str(x['id']) for x in links if x.get('nota_ine')}
        included_bounds=int((ranked.id_visual.isin(limited_ids)&ranked.renta_territorial.gt(0)).sum())
        p(f'De los registros con nota, {numero(included_bounds)} tienen renta utilizable en el cálculo de este informe. Los valores candidatos excluidos no intervienen en las medianas ni en las puntuaciones sociales.')
        if len(years)>1:p('El complemento contiene más de un año de renta. La mediana conjunta mezcla periodos; deben revisarse por separado antes de interpretar diferencias territoriales.')
    else:p('No hay un complemento territorial trazable para esta selección. Una columna de renta sin enlace documentado no acredita una consulta al INE.')
    p('Revisiones registradas','SubInforme')
    p(f"Se conservan {numero(len(datos['revisiones']))} anotaciones del historial para los registros incluidos. Este recuento incluye revisiones sucesivas; no equivale a casos únicos resueltos.")
    note('El informe no reproduce direcciones ni referencias catastrales. Para comprobar un enlace concreto, utiliza el apartado Resolver incidencias y su historial. No se infiere pobreza energética ni vulnerabilidad individual a partir de renta territorial y CEE.')

    if climate.get('pendiente'):
        story.append(Spacer(1,18));p('6. CRREM: hipótesis, cobertura y resultados','SeccionInforme')
    else:section('6. CRREM: hipótesis, cobertura y resultados')
    if climate.get('pendiente'):
        p('CRREM pendiente: no hay resultados terminados para la configuración actual en esta sesión. Ejecuta el módulo Alineamiento CRREM y vuelve a exportar para incorporarlos. El informe no rellena ese apartado con hipótesis nuevas ni recupera resultados de otro archivo.')
    else:p(f"Resultados de la última ejecución CRREM terminada: {numero(climate['n'])} registros en su propio ámbito. Los filtros del ranking no se aplican retrospectivamente a ese cálculo. No se mezclan configuraciones ni se vuelve a ejecutar el modelo al exportar.")
    cfg=climate.get('config',{})
    if cfg:story.append(tabla(['Parámetro','Configuración'],[
        ['Tipología',cfg.get('tipo','Residential Multi-Family')],['Año base',str(climate['base'])],
        ['Modo',cfg.get('modo','Escenario a partir del CEE')],
        ['Reducción energética anual',numero(float(cfg.get('reduccion',0))*100,2)+' %'],
        ['Complemento IDAE','Sí' if cfg.get('complemento',False) else 'No'],
        ['Zona IDAE',cfg.get('perfil','Continental') if cfg.get('complemento',False) else 'No aplicado'],
        ['Relación de superficie',numero(cfg.get('ratio',1),2) if cfg.get('modo')!='Evaluación con entradas documentadas' else 'GIA de cada entrada'],
        ['Vistas del informe','Por m²; total anual del ejemplo individual cuando hay superficie']], [W*.5,W*.5],ss))
    if climate.get('error'):
        p('Datos o fuentes insuficientes: '+climate['error'])
        p('No se publican curvas, cruces ni años operacionales para esta selección.')
    elif climate.get('pendiente'):pass
    else:
        valid=summary[summary.get('eui_escenario',pd.Series(index=summary.index,dtype=float)).notna()]
        p(f"{numero(len(valid))} registros calculables de {numero(climate['n'])} en la última ejecución recogida. "+('Se recoge la última entrada documentada calculada, declarada por el usuario; no existe verificación externa automática.' if climate.get('operacional') else 'Los resultados son escenarios exploratorios; ninguno se convierte en evaluación operacional validada.'))
        if climate.get('operacional') and len(valid):
            story.append(tabla(['Certificado','Año base','Origen','EUI (kWh/m²·año)','Carbono (kg CO2/m²·año)'],[
                [r.certificado,str(r.anio),r.origen,numero(r.eui_escenario,2),numero(r.ci_escenario,2)] for r in valid.head(10).itertuples()],
                [W*.26,W*.14,W*.16,W*.22,W*.22],ss))
            note('Se muestran hasta 10 entradas. Cada entrada conserva su propio año base y tipología; no se agregan periodos ni superficies diferentes.')
        rows=[]
        for key,label in [('cruce_energia_exploratorio','Energía'),('cruce_carbono_exploratorio','Carbono')]:
            crosses=valid.get(key,pd.Series(index=valid.index,dtype=float))
            rows.append([label,numero(crosses.notna().sum()),numero(crosses.isna().sum()),numero(crosses.dropna().median(),0)])
        story.append(tabla(['Métrica','Con cruce hasta 2050','Sin cruce hasta 2050','Mediana entre cruces'],rows,[W*.2,W*.26,W*.28,W*.26],ss))
        note('La tabla solo cuenta registros calculables; los no evaluables se contabilizan aparte. La mediana de año utiliza exclusivamente registros con cruce, por lo que no describe a todo el conjunto. Igualar el umbral no se considera superarlo.')
        if not climate.get('operacional'):
            note('Se utiliza superficie habitable CEE como proxy de GIA y reparto por sistemas como proxy de vectores. No hay calibración individual, facturas completas ni conciliación GIA. El complemento IDAE, cuando se activa, transfiere proporciones agregadas; no predice el consumo individual. Una reducción positiva es una hipótesis del usuario.')
        for key,label,unit in [('eui_kwh_m2_anio','Energía del escenario y trayectoria CRREM','kWh/m²·año'),('ci_kg_m2_anio','Carbono del escenario y trayectoria CRREM','kg CO2/m²·año')]:
            frame=climate['series'].get(key)
            if frame is not None:
                story.append(lineas(frame,label,unit))
                note('Mediana, P10 y P90 sin ponderar por certificado, con umbral CRREM por m². P10-P90 no es un intervalo de confianza ni una suma de edificios.')
        if climate.get('individual'):
            identity,frame=climate['individual']
            section('6.1. Ejemplo individual del conjunto incluido')
            p('Certificado: '+str(identity)+'. Se utiliza el seleccionado si está incluido y es calculable; en otro caso, el primero calculable. No es una muestra representativa.')
            for val,lim,label,unit in [('eui_kwh_m2_anio','umbral_eui','Energía','kWh/m²·año'),('ci_kg_m2_anio','umbral_ci','Carbono','kg CO2/m²·año')]:
                story.append(lineas(frame[[val,lim]].rename(columns={val:'Escenario',lim:'CRREM'}),label+' por m²',unit))
            area=None
            if 'superficie_escenario_m2' in valid:
                matches=valid[valid.certificado.eq(identity)]
                if len(matches):area=float(matches.iloc[0].superficie_escenario_m2)
            if area is not None:
                section('6.2. Comparación anual del certificado')
                p('Certificado: '+str(identity)+'. Superficie del cálculo: '+numero(area,2)+' m². Cada curva y su umbral se multiplican por esa misma superficie; el año de cruce no cambia.')
                for val,lim,label,unit in [('eui_kwh_m2_anio','umbral_eui','Energía anual','kWh/año'),('ci_kg_m2_anio','umbral_ci','Carbono anual','kg CO2/año')]:
                    story.append(lineas((frame[[val,lim]]*area).rename(columns={val:'Escenario',lim:'CRREM'}),label,unit))
                note('En total anual no existe un umbral común para inmuebles con distintas superficies. El ejemplo no se extrapola ni se suma al resto de certificados.')

    section('7. Conclusiones y próximos pasos')
    for i,text in enumerate(datos['conclusiones'],1):p(str(i)+'. '+text)
    if conclusion_climatica:p(conclusion_climatica)
    p('Implicaciones para la toma de decisiones','SubInforme')
    p('Utiliza las prioridades para seleccionar certificados que revisar. Antes de proponer una intervención, confirma edificio o parte, superficie, servicios y estado real del inmueble. Las puntuaciones no permiten estimar inversión, ahorro o retorno económico.')
    if n-usable:p(f'Completa o revisa el enlace social de los {numero(n-usable)} registros sin renta utilizable antes de interpretar el escenario social como una comparación de todo el conjunto. Mantén sus resultados energéticos cuando existan datos válidos.')
    p('Para pasar de un escenario CEE a una evaluación operacional CRREM, reúne consumos finales completos de 12 meses, concilia GIA y perímetro, documenta ocupación, exportaciones y factores aplicables. Los resultados medidos y estimados deben conservar su procedencia y limitaciones.')
    if climate.get('error'):p('Resuelve las insuficiencias del apartado CRREM antes de interpretar trayectorias temporales de esta selección.')
    p('Las diferencias observadas describen este conjunto y sus filtros. No se demuestra causalidad ni representatividad del parque de Madrid. Los resultados son apoyo a un análisis técnico posterior.')

    section('8. Método, fuentes y trazabilidad')
    p('La redacción automática utiliza reglas basadas en recuentos, medianas, percentiles, coberturas y resultados de los motores existentes. No se utilizan servicios externos de generación de texto ni se completan datos desconocidos. Los gráficos y tablas son generados a partir del mismo conjunto del informe.')
    rows=[['Archivo importado',nombre],['SHA-256 del archivo',huella],['SHA-256 de datos de análisis',datos['firma_datos']],
        ['Versión del informe',VERSION],['Generación',now.isoformat()],['Filtros',str(datos['filtros'])],
        ['Pesos y magnitud',str(datos['pesos'])+'; '+datos['modo']],['Criterio',ESCENARIOS[selected]],
        ['Complemento social incluido',hashlib.sha256(json.dumps(datos['enlaces'],sort_keys=True,ensure_ascii=False,default=str).encode()).hexdigest()]]
    story.append(tabla(['Elemento','Valor'],rows,[W*.3,W*.7],ss))
    manifest=climate.get('fuentes',{})
    p('Fuentes CRREM instaladas y verificadas','SubInforme')
    p('Trayectorias '+str(manifest.get('version_trayectorias','sin verificar'))+'; guía '+str(manifest.get('guia','sin verificar'))+'; Blueprint '+str(manifest.get('blueprint','sin verificar'))+'. Fecha de consulta conservada: '+str(manifest.get('fecha_consulta','sin dato'))+'. El informe no comprueba si existe una edición posterior.')
    for item in manifest.get('archivos',[]):
        story.append(KeepTogether([Paragraph(escape(item['archivo']),ss['SubInforme']),
            Paragraph(escape(item['url']),ss['NotaInforme']),Paragraph('SHA-256: '+item['sha256'],ss['NotaInforme'])]))
    sources=sorted({str(x.get('fuente_renta')) for x in links if x.get('fuente_renta')})
    if sources:
        p('Fuentes territoriales conservadas en el complemento','SubInforme')
        for url in sources[:10]:note(url)
        if len(sources)>10:note(f'{len(sources)} referencias distintas en el complemento; se muestran hasta 10. La auditoría social completa se descarga desde la herramienta.')
    note('La copia local del archivo y el historial de revisiones se conservan en este equipo. El informe es una instantánea de los datos y configuración disponibles al pulsar exportar; no se actualiza después de descargarlo.')
    buf=BytesIO()
    def pie(canvas,doc):
        canvas.saveState();canvas.setStrokeColor(colors.HexColor('#dbe5de'))
        canvas.line(48,36,A4[0]-48,36);canvas.setFont('Informe',7);canvas.setFillColor(GRIS)
        canvas.drawString(48,24,'REHABILITACIÓN · ANÁLISIS SOSTENIBLE')
        canvas.drawRightString(A4[0]-48,24,f'{doc.page}');canvas.restoreState()
    doc=SimpleDocTemplate(buf,pagesize=A4,leftMargin=48,rightMargin=48,topMargin=48,bottomMargin=51,
        title='Informe de análisis y conclusiones',author='Rehabilitación · Análisis sostenible')
    doc.build(story,onFirstPage=pie,onLaterPages=pie)
    return buf.getvalue()
