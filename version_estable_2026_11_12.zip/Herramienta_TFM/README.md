# Herramienta TFM de rehabilitación sostenible

Estado: herramienta con importación CSV/ZIP, 29/10/2026. Los módulos utilizan el archivo importado por el usuario. No existe una opción de muestra precargada. Los 15 CEE originales se conservan únicamente como documentación histórica y datos reales de las pruebas de regresión.

Consultar CRREM_IMPLEMENTACION.md para el cálculo energético y de carbono, validación oficial y límites de las estimaciones. PILOTO_15_CEE.md documenta la selección real y METODOLOGIA_CRREM.md conserva la cronología anterior.

## Abrir

Con Python 3.12, instalar requirements-lock.txt y ejecutar:

    python -m pip install -r requirements-lock.txt
    python -m streamlit run app.py --global.developmentMode false

La primera pantalla muestra únicamente el logo, «Rehabilitación · Análisis sostenible» y el botón «Abrir la herramienta». Este botón lleva a «Inicio», conservando su presentación, tres dimensiones y guía de uso. Desde Inicio, pulsa «Entrar a la herramienta» para acceder al ranking. La pantalla de marca aparece una vez por sesión y al recargar la página; no carga datos ni muestra el menú lateral.

Importa un CSV/ZIP si todavía no hay archivo guardado. Se conserva una copia local del último archivo en datos_usuario/conjunto_activo.sqlite3, con su nombre y huella SHA-256; se recupera al iniciar nuevas sesiones o reiniciar la aplicación. «Cambiar o retirar archivo» elimina esta copia y permite importar otro, sin modificar el archivo original ni el historial de revisiones. El archivo guardado es común a esta instalación local; no es un almacenamiento aislado por cuentas. No se incluye en las entregas ZIP.

Puedes volver a «Inicio» o elegir Ranking exploratorio, Diagnóstico energético CEE / pre-CRREM, Alineamiento CRREM, Entorno social · INE o Resolver incidencias en el menú lateral. Resolver incidencias explica qué comprobar, enlaza fuentes oficiales y permite guardar decisiones, evidencia e historial. Ver RESOLVER_INCIDENCIAS.md. Verificación de esta versión: 81 pruebas superadas, con copias temporales aisladas de los datos de trabajo.

## Presentación revisada el 25/10/2026

El menú lateral se simplifica el 29/10/2026: el selector «Sección» muestra nombres breves (Inicio, Prioridades, Diagnóstico CEE, Trayectorias CRREM, Entorno social e Incidencias). El informe se destaca arriba y el conjunto activo se resume con su número de certificados. «Archivo de trabajo» reúne el nombre, la recuperación local y el cambio de archivo. «Datos sociales», «Filtrar certificados» y «Pesos del escenario social» se muestran cerrados inicialmente, con todas sus opciones disponibles. La comparación por m²/anual permanece visible y el botón de incidencias abre directamente la guía de revisión. Se indican filtros activos, pesos personalizados y cambios de inclusión de renta/cotas para que no pasen inadvertidos.

Diseño compartido en los cinco módulos: cabecera, identidad visual, tipografía del sistema, colores verdes, tarjetas de indicadores y gráficas con estilo coherente. El ranking se organiza en cuatro pestañas: Prioridades, Calidad de datos, Comparación de rankings y Exportación. La tabla principal resume los indicadores esenciales; «Todos los indicadores del conjunto ordenado» conserva el detalle. Las descargas completas mantienen sus campos y resultados. Los controles CRREM se agrupan en columnas y conservan las vistas por m² y anual.

La presentación se configura en apariencia.py, estilo.css y .streamlit/config.toml. No utiliza fuentes web ni recursos visuales externos. El CSS incluye adaptación a ventanas estrechas y foco visible para navegación por teclado. Se conservan los avisos de alcance, procedencia y calidad. Este cambio no modifica motores, fuentes oficiales, criterios, pesos ni datos. Las evidencias y entregas anteriores del caso de estudio conservan su versión original.

## Informe resumen en PDF

El botón «Exportar informe (PDF)» aparece en el menú lateral, bajo el selector de módulo, cuando hay un archivo cargado y un análisis disponible. Genera localmente un informe con resumen ejecutivo, calidad y cobertura, resultados energéticos por m²/anuales, prioridades, entorno social, incidencias, CRREM, conclusiones y trazabilidad. Incorpora tablas y figuras vectoriales; no envía datos a servicios de IA ni requiere una clave externa.

En el ranking utiliza los filtros, pesos, magnitud y criterio actuales. En los demás módulos resume el conjunto completo; el informe identifica ese alcance. CRREM recoge la última ejecución terminada compatible con los datos y parámetros actuales de la sesión, con su propio ámbito explícito. Incluye curvas del conjunto y del certificado seleccionado por m²/anuales cuando existen datos. Si todavía no se ha ejecutado CRREM, o sus parámetros han cambiado sin un cálculo terminado, indica «pendiente»: no crea un escenario nuevo para rellenar el informe. Las evaluaciones documentadas conservan su origen y no se presentan como auditorías externas.

La redacción usa reglas reproducibles basadas en cifras calculadas. No atribuye ahorros, consumos medidos ni vulnerabilidad individual al CEE y la renta territorial. Muestra hasta 10 prioridades y conserva las descargas CSV completas existentes. Es una instantánea de los datos disponibles al pulsar; no sustituye la evidencia documental ni se actualiza posteriormente.

## Alcance de los cálculos

Funcionan rankings por m²/anual de energía y emisiones CEE, comparación de puestos, diagnóstico y exportación. CRREM calcula energía y carbono, proyección con factores eléctricos anuales, créditos de exportación y ambos años de desalineamiento para entradas completas documentadas. El núcleo reproduce cuatro ejemplos oficiales y su agregado. La suite tiene 74 pruebas superadas con el estudio externo instalado junto a la aplicación.

Para los 15 CEE se muestran escenarios parciales y un complemento IDAE opcional, con gráficas y cruces exploratorios. No se presentan como evaluaciones operacionales validadas: faltan GIA conciliada y consumos completos medidos o una estimación calibrada. El módulo «Entorno social · INE» enlaza renta territorial 2024: 12 CEE utilizables por defecto, dos direcciones pendientes y una cota por secreto estadístico opcional. La renta se incorpora al ranking; no altera CRREM. Ver DIMENSION_SOCIAL.md.

Los datos están en datos_piloto/; fuentes CRREM originales y huellas en fuentes/. Las pruebas automáticas están aisladas en tests/ y no aportan edificios ficticios a la aplicación. Ejecutar python -m pytest -q para comprobar el código y python ejecutar_piloto_crrem.py para regenerar escenarios y validación. La reproducción desde el ZIP original se explica en PILOTO_15_CEE.md.
# Comparación gráfica del conjunto CEE

El modo «Escenario a partir del CEE» muestra la gráfica individual y, debajo, «Todos los CEE · comparación conjunta». Comparte los controles de energía/carbono, año, reducción, superficie y complemento IDAE. Cada certificado conserva su línea e identificador; la leyenda permite destacar uno o varios. Por m² se utiliza la trayectoria CRREM común; en anual se dibuja un umbral discontinuo por certificado, multiplicado por su superficie. La gráfica no agrega edificios y permite descargar los valores representados. Solo incluye registros calculables y muestra su cobertura. Mantiene la condición de escenario exploratorio, sin convertir los CEE en consumos operacionales.

## Importación masiva comprobada el 25/10/2026

Se ha probado en navegador la carga del ZIP oficial completo (110.650 filas) y la importación CSV/ZIP de una cohorte externa de 9.364 certificados. La selección y el enriquecimiento masivo están documentados fuera de la app; no se ha añadido un apartado de carga especial del caso. Las descargas del ranking por m²/anual y CRREM coinciden con las salidas reproducibles. El lector conserva notas y cotas de complementos sociales importados, incluidos años expresados como 2024,0. Se distinguen códigos de registro repetidos por fila, sin atribuirles identidad de edificio.

Las tablas grandes muestran una vista previa de 1.000 registros y mantienen la descarga completa. Para más de 50 escenarios, CRREM muestra mediana y P10-P90 de todos y permite elegir hasta 50 líneas detalladas; no es un intervalo de confianza. Los controles exploratorios CEE excluyen escenarios incompatibles y mantienen el motivo. Las fuentes se comprueban por SHA-256 y se reutiliza la huella mientras no cambien tamaño ni fecha de modificación del archivo.

