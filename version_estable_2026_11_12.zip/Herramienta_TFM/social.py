"""Enlace reproducible CEE → parcela catastral → sección y renta INE.

Solo servicios públicos oficiales; ninguna renta se imputa a hogares individuales.
"""
from pathlib import Path
import hashlib
import json
import re
import unicodedata
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime,timezone
import pandas as pd

ROOT=Path(__file__).parent
INE='https://www.ine.es/servergis2/rest/services/ws/ADRH_renta_media_por_persona/MapServer'
CATASTRO='https://ovc.catastro.meh.es/OVCServWeb/OVCWcfCallejero/COVCCoordenadas.svc/rest/Consulta_CPMRC'


def descargar(url,cache):
    cache=Path(cache);cache.mkdir(parents=True,exist_ok=True)
    path=cache/(hashlib.sha256(url.encode()).hexdigest()+'.json')
    if path.exists():
        record=json.loads(path.read_text(encoding='utf-8'))
    else:
        request=urllib.request.Request(url,headers={'User-Agent':'TFM-Sostenibilidad/1.0'})
        with urllib.request.urlopen(request,timeout=20) as response:
            content=response.read().decode('utf-8-sig')
        record={'url':url,'consulta_utc':datetime.now(timezone.utc).isoformat(),'contenido':content,
                'sha256_contenido':hashlib.sha256(content.encode()).hexdigest()}
        path.write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
    if hashlib.sha256(record['contenido'].encode()).hexdigest()!=record['sha256_contenido']:
        raise ValueError('La respuesta guardada no coincide con su huella')
    return record


def consulta(base,params,cache):
    record=descargar(base+'?'+urllib.parse.urlencode(params),cache)
    data=json.loads(record['contenido'])
    if 'error' in data:raise ValueError('Error del servicio oficial: '+str(data['error']))
    return data,record['url']


def interpretar_renta(features):
    if len(features)!=1:raise ValueError('Punto sin sección única: revisar localización o límite censal')
    a=features[0]['attributes']
    if not re.fullmatch(r'\d{10}',str(a.get('CUSEC',''))):raise ValueError('Código de sección no válido')
    if a.get('indicador1')!='Renta neta media por persona' or a.get('unidad1')!='Euros':
        raise ValueError('Indicador o unidad INE incompatible')
    value=a.get('dato1')
    if value is None or not 0<float(value)<1e7:raise ValueError('Renta ausente o no utilizable')
    year=str(a.get('periodo',''))
    if not re.fullmatch(r'20\d{2}',year):raise ValueError('Año de renta no identificado')
    note=a.get('nota1') or ''
    return {'seccion_censal':a['CUSEC'],'renta_media_seccion_eur_persona':float(value),
            'anio_renta':int(year),'nota_ine':note,'calidad_renta':'Cota publicada por INE' if note else 'Valor publicado por INE',
            'municipio_ine':a.get('NMUN','')}


def direccion_compatible(cee,catastro):
    def clean(value):
        return ''.join(c for c in unicodedata.normalize('NFKD',value.upper()) if not unicodedata.combining(c))
    cee,catastro=clean(cee),clean(catastro)
    if re.search(r'\b(BQ|BLOQUE)\s*\d',cee):return False
    ignore={'CALLE','CL','C','DE','DEL','LA','LAS','LOS','EL','N','NO','NUMERO','MADRID'}
    tokens={t for t in re.findall(r'[A-Z]+',cee) if t not in ignore and len(t)>1}
    other=set(re.findall(r'[A-Z]+',catastro))
    numbers=re.findall(r'\d+',cee);target=re.findall(r'\d+',catastro)
    return bool(tokens and len(tokens & other)/len(tokens)>=.8 and numbers and target and numbers[0]==target[0])


def enlazar_fila(row,cache):
    result={'id':str(row.id_visual),'direccion_cee':str(row.get('direccion','') or ''),
            'referencia':str(row.get('referencia','') or ''),'estado_social':'Pendiente',
            'renta_media_seccion_eur_persona':None}
    try:
        ref=result['referencia'].strip().upper()
        if not re.fullmatch(r'[A-Z0-9]{14}(?:[A-Z0-9]{6})?',ref):
            raise ValueError('Falta referencia catastral única: revisar dirección y aportar referencia de parcela')
        url=CATASTRO+'?'+urllib.parse.urlencode({'Provincia':'','Municipio':'','SRS':'EPSG:4326','RefCat':ref[:14]})
        record=descargar(url,cache)
        tree=ET.fromstring(record['contenido'])
        nodes=tree.findall('.//{*}coord')
        if len(nodes)!=1:raise ValueError('Catastro no devuelve una parcela única')
        node=nodes[0]
        actual=(node.findtext('.//{*}pc1') or '')+(node.findtext('.//{*}pc2') or '')
        if actual!=ref[:14]:raise ValueError('Referencia devuelta distinta de la solicitada')
        lon=float(node.findtext('.//{*}xcen'));lat=float(node.findtext('.//{*}ycen'))
        if not (-19<lon<5 and 27<lat<45):raise ValueError('Coordenadas fuera del ámbito esperado')
        result.update(longitud=lon,latitud=lat,direccion_catastro=node.findtext('.//{*}ldt'),fuente_localizacion=url)
        params={'f':'json','geometry':f'{lon},{lat}','geometryType':'esriGeometryPoint','inSR':4326,
                'spatialRel':'esriSpatialRelIntersects','outFields':'*','returnGeometry':'false'}
        data,url=consulta(INE+'/2/query',params,cache)
        value=interpretar_renta(data.get('features',[]))
        if str(row.get('municipio','')).upper()=='MADRID' and not value['seccion_censal'].startswith('28079'):
            raise ValueError('La sección obtenida no pertenece al municipio del CEE')
        # Un punto representativo de parcela cerca de un límite exige revisión.
        border=dict(params,distance=5,units='esriSRUnit_Meter')
        nearby,_=consulta(INE+'/2/query',border,cache)
        if len(nearby.get('features',[]))!=1:raise ValueError('Parcela a menos de 5 m de un límite censal: revisar')
        result.update(value,estado_social='Enlace automático por parcela',fuente_renta=url,
                      metodo='Punto representativo catastral EPSG:4326 intersectado con capa de secciones ADRH del mismo servicio')
        if not direccion_compatible(result['direccion_cee'],result['direccion_catastro']):
            result['estado_social']='Pendiente de revisar dirección'
            result['motivo']='Dirección CEE y domicilio catastral no conciliados; renta candidata excluida del ranking'
    except Exception as exc:
        result['motivo']=str(exc)
    return result


def aplicar_enlaces(raw,enlaces,usar_cotas=False):
    """Enlace por ID único: nunca por posición; pendientes no aportan renta."""
    from motor import normalizar
    normalized,_=normalizar(raw)
    links=pd.DataFrame(enlaces)
    if links.empty:return raw.copy()
    if links.id.duplicated().any() or normalized.id_visual.duplicated().any():
        raise ValueError('Los identificadores repetidos impiden el enlace social')
    lookup=links.set_index('id')
    result=raw.copy()
    accepted=lookup['estado_social'].isin(['Enlace automático por parcela','Enlace revisado manualmente'])
    if not usar_cotas and 'nota_ine' in lookup:accepted &= lookup.nota_ine.fillna('').eq('')
    for col in ['renta_media_seccion_eur_persona','seccion_censal','anio_renta','nota_ine','calidad_renta','fuente_renta','estado_social']:
        values=lookup[col] if col in lookup else pd.Series(dtype='object')
        if col=='renta_media_seccion_eur_persona':values=values.where(accepted)
        result[col]=normalized.id_visual.map(values)
    for col in ['responsable','fecha_comprobacion','evidencia','explicacion','guardado_utc']:
        values=lookup.apply(lambda row:row.get('revision_manual',{}).get(col,'') if isinstance(row.get('revision_manual'),dict) else '',axis=1)
        result['revision_'+col]=normalized.id_visual.map(values)
    return result


def enlaces_importados(raw):
    """Lee el complemento declarado en un CSV, conservando candidatos y notas."""
    required={'estado_social','seccion_censal','anio_renta','fuente_renta','renta_candidata_ine_eur_persona'}
    if not required.issubset(raw.columns):return []
    from motor import normalizar,_a_numero
    normalized,_=normalizar(raw)
    values=_a_numero(raw['renta_candidata_ine_eur_persona'])
    years=_a_numero(raw['anio_renta'])
    links=[]
    for pos,(_,row) in enumerate(raw.iterrows()):
        clean=lambda key: str(row.get(key,'')).strip() if pd.notna(row.get(key,'')) else ''
        item={key:clean(key) for key in ['estado_social','seccion_censal','nota_ine','fuente_renta','fuente_localizacion','direccion_catastro','calidad_renta','metodo','motivo']}
        item.update(id=str(normalized.iloc[pos].id_visual),direccion_cee=str(normalized.iloc[pos].direccion),referencia=str(normalized.iloc[pos].referencia),
                    renta_media_seccion_eur_persona=None if pd.isna(values.iloc[pos]) else float(values.iloc[pos]))
        year=years.iloc[pos]
        item['anio_renta']=int(year) if pd.notna(year) and year%1==0 and 2000<=year<=2100 else None
        if item['estado_social'] in ('Enlace automático por parcela','Enlace revisado manualmente'):
            if not (re.fullmatch(r'\d{10}',item['seccion_censal']) and item['anio_renta'] and item['renta_media_seccion_eur_persona'] is not None and item['renta_media_seccion_eur_persona']>0 and item['fuente_renta'].startswith('https://www.ine.es/')):
                item.update(estado_social='Pendiente',motivo='Complemento social importado incompleto o incompatible')
        links.append(item)
    return links


def recuperar_piloto():
    """Reconstruye únicamente la localización de las mismas filas oficiales auditadas."""
    from motor import cargar_archivo
    folder=ROOT/'datos_piloto'
    meta=json.loads((folder/'seleccion_y_procedencia.json').read_text(encoding='utf-8'))
    source=ROOT.parent/'datos_originales/registro_certificados_eficiencia_energetica_2025.zip'
    blob=source.read_bytes()
    if hashlib.sha256(blob).hexdigest()!=meta['sha256_zip']:raise ValueError('ZIP CEE distinto del auditado')
    allrows=cargar_archivo(source.name,blob)
    records=[]
    for item in meta['filas']:
        row=allrows.iloc[item['fila_logica_csv']-1]
        digest=hashlib.sha256(json.dumps(row.to_dict(),ensure_ascii=False,sort_keys=True).encode()).hexdigest()
        if digest!=item['sha256_fila_original']:raise ValueError('Fila original distinta de la auditada')
        records.append({'id':item['id'],'edif_direc':row.edif_direc,'edif_refcat':row.edif_refcat,'edif_muni':row.edif_muni})
    return pd.DataFrame(records)


if __name__=='__main__':
    from motor import normalizar
    raw=recuperar_piloto()
    raw.to_csv(ROOT/'datos_piloto/localizacion_CEE_15.csv',index=False)
    normalized,_=normalizar(raw)
    links=[]
    for _,row in normalized.astype(object).where(normalized.notna(),'').iterrows():
        links.append(enlazar_fila(row,ROOT/'fuentes/social_respuestas'))
        (ROOT/'datos_piloto/enlaces_sociales.json').write_text(json.dumps(links,ensure_ascii=False,indent=2),encoding='utf-8')
        print(row.id_visual,links[-1]['estado_social'],links[-1].get('motivo',''),flush=True)
