"""Página de entrada y orientación, sin carga ni cálculo de datos."""
import streamlit as st


def entrar():
    st.session_state['navegacion_principal']='Ranking exploratorio'


def mostrar_portada():
    if st.session_state.pop('animar_entrada_inicio',False):
        st.markdown('''<style>
@keyframes entrada-inicio {
    from {opacity:0; transform:translateY(6px);}
    to {opacity:1; transform:translateY(0);}
}
@keyframes entrada-menu {from {opacity:0;} to {opacity:1;}}
[data-testid="stMainBlockContainer"] {animation:entrada-inicio 1.5s cubic-bezier(.4,0,.2,1) .12s both;}
[data-testid="stSidebar"] {animation:entrada-menu 1.35s ease-in-out .12s both;}
@media (prefers-reduced-motion:reduce) {
    [data-testid="stMainBlockContainer"], [data-testid="stSidebar"] {animation:none;}
}
</style>''',unsafe_allow_html=True)
    st.sidebar.caption('Una mirada conjunta a energía, descarbonización y entorno social.')
    st.markdown('''<section class="portada-hero">
<div class="sobre-titulo">REHABILITACIÓN · ANÁLISIS SOSTENIBLE</div>
<h1>Entender los edificios.<br>Orientar su rehabilitación.</h1>
<p>Una herramienta para explorar certificados energéticos, comparar trayectorias de descarbonización y comprender el contexto social de cada activo.</p>
<div class="portada-sello">Trabajo Fin de Máster <span>·</span> Herramienta de apoyo a la decisión</div>
</section>''',unsafe_allow_html=True)
    st.button('Entrar a la herramienta',type='primary',on_click=entrar,icon=':material/arrow_forward:')
    if st.session_state.get('archivo_recordado'):
        st.success('Archivo activo guardado en este equipo: '+st.session_state['archivo_recordado'][0])
    st.caption('Importa tu archivo CSV o ZIP. Se conserva una copia local para continuar al volver a abrir la herramienta.')
    st.markdown('''<div class="portada-dimensiones">
<article><span class="portada-numero">01 / ENERGÍA</span><h2>Diagnosticar y comparar</h2><p>Revisa los datos del certificado y compara energía y emisiones por m² o como total anual calculado.</p></article>
<article><span class="portada-numero">02 / DESCARBONIZACIÓN</span><h2>Explorar trayectorias</h2><p>Consulta CRREM para España, representa cada certificado y compara el conjunto con supuestos explícitos.</p></article>
<article><span class="portada-numero">03 / ENTORNO SOCIAL</span><h2>Incorporar el contexto</h2><p>Consulta la renta territorial del INE, revisa la calidad del enlace y registra las comprobaciones pendientes.</p></article>
</div>''',unsafe_allow_html=True)
    with st.expander('Cómo empezar'):
        st.markdown('1. **Carga los datos.** Importa un CSV/ZIP en el menú lateral o continúa con el archivo guardado.\n2. **Revisa su calidad.** Consulta el diagnóstico y resuelve las incidencias que puedan afectar al análisis.\n3. **Explora y exporta.** Compara prioridades, consulta CRREM y descarga los resultados con su trazabilidad.')
    st.markdown('''<div class="portada-alcance"><strong>Interpretar los resultados con criterio</strong><p>El CEE recoge valores calculados, no consumos medidos. Los escenarios CEE-CRREM son exploratorios; una evaluación operacional exige entradas completas y documentadas. La renta describe el entorno censal, no los hogares. La herramienta apoya el análisis y no sustituye una evaluación técnica del inmueble.</p></div>''',unsafe_allow_html=True)
