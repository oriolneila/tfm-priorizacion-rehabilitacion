"""Contraste independiente del núcleo con los cuatro ejemplos CRREM v1.1."""
import json
import openpyxl
import pandas as pd
import numpy as np
from crrem import ROOT
from crrem_operacional import CARRIERS, proyectar, comparar, agregar


def validar():
    fixtures=json.loads((ROOT/'fuentes/worked-examples-fixtures-v1.1.json').read_text(encoding='utf-8'))
    book=openpyxl.load_workbook(ROOT/'fuentes/worked-examples-v1.1.xlsx',read_only=True,data_only=True)
    rows=list(book['Example Input'].values); book.close()
    field_map={'Elec_Grid':'electricidad_red','Gas':'gas','Oil':'gasoleo','District_Heating':'calor_red',
               'District_Cooling':'frio_red','Biomass_Other':'biomasa','Renew_Consumed':'renovable_autoconsumida'}
    results=[]; reports=[]
    for i,asset in enumerate(fixtures['assets']):
        inp={r['field']:r['value'] for r in asset['steps']['step_1']['rows']}
        factors_in={r['field']:r['value'] for r in asset['steps']['step_3']['rows']}
        consumos={k:0. for k in CARRIERS}
        consumos.update({dest:inp[src] for src,dest in field_map.items()})
        base=asset['reporting_year']; years=range(base,2051)
        grid=pd.Series(rows[5+i][7:],index=range(2020,2051)).loc[base:]
        factors={k:pd.Series(0.,index=years) for k in CARRIERS}
        factors['electricidad_red']=grid
        factors['gas']=pd.Series(factors_in['EF_Gas'],index=years)
        factors['gasoleo']=pd.Series(rows[35][7],index=years)
        factors['calor_red']=pd.Series(factors_in['EF_District_Heating'],index=years)
        factors['frio_red']=pd.Series(factors_in['EF_District_Cooling'],index=years)
        # Claves de fila observadas en el libro, no trayectorias inventadas.
        pathway_rows=[24,25,None,28]
        if i==2:
            eui_curve=pd.Series(.65*np.array(rows[26][7:])+.35*np.array(rows[27][7:]),index=range(2020,2051))
        else:
            eui_curve=pd.Series(rows[pathway_rows[i]][7:],index=range(2020,2051))
        co2_curve=pd.Series(asset['trajectories']['pathway_curve_kgco2e_m2_yr'],index=years)
        frame=proyectar(consumos,inp['GIA'],factors,base,inp['Renew_Exported'])
        frame,cross=comparar(frame,eui_curve,co2_curve,base,inp['GIA'])
        expected=asset['summary']
        error=float(np.max(np.abs(frame.ci_kg_m2_anio.to_numpy()-asset['trajectories']['asset_curve_kgco2e_m2_yr'])))
        report={'ejemplo':asset['name'],'eui_calculada':float(frame.eui_kwh_m2_anio.iloc[0]),
                'eui_referencia':expected['eui_kwh_m2_yr'],'ci_calculada':float(frame.ci_kg_m2_anio.iloc[0]),
                'ci_referencia':expected['carbon_intensity_kgco2e_m2_yr'],
                'max_error_curva_ci':error,'cruce_calculado':cross,
                'cruce_referencia':{'energia':expected['misalignment_year_eui'],'carbono':expected['misalignment_year_co2']}}
        report['superado']=(abs(report['eui_calculada']-report['eui_referencia'])<=fixtures['tolerances']['eui_kwh_m2_yr'] and
                            abs(report['ci_calculada']-report['ci_referencia'])<=fixtures['tolerances']['intensity_kgco2e_m2_yr'] and
                            error<=fixtures['tolerances']['intensity_kgco2e_m2_yr'] and cross==report['cruce_referencia'])
        reports.append(report);results.append((frame,inp['GIA']))
    portfolio,cross=agregar(results)
    exp=fixtures['portfolio']['summary']
    reports.append({'ejemplo':'Agregado por GIA','cruce_calculado':cross,
                    'cruce_referencia':{'energia':exp['misalignment_year_eui'],'carbono':exp['misalignment_year_co2']},
                    'eui_calculada':float(portfolio.eui_kwh_m2_anio.iloc[0]),'ci_calculada':float(portfolio.ci_kg_m2_anio.iloc[0]),
                    'superado':cross=={'energia':exp['misalignment_year_eui'],'carbono':exp['misalignment_year_co2']} and
                    abs(portfolio.eui_kwh_m2_anio.iloc[0]-exp['eui_kwh_m2_yr'])<=fixtures['tolerances']['eui_kwh_m2_yr'] and
                    abs(portfolio.ci_kg_m2_anio.iloc[0]-exp['carbon_intensity_kgco2e_m2_yr'])<=fixtures['tolerances']['intensity_kgco2e_m2_yr']})
    for report in reports: report['superado']=bool(report['superado'])
    return reports


if __name__=='__main__':
    result=validar()
    (ROOT/'datos_piloto/validacion_referencias_CRREM.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2))
