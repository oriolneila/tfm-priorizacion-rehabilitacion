# Dimensión social: enlace territorial reproducible

Actualización: 24/10/2026. No se han generado rentas ficticias.

Se utiliza la **renta neta media anual por persona de la sección censal**, en euros/persona·año, del Atlas de distribución de renta de los hogares del INE. Representa el contexto territorial, no la renta de los ocupantes, el precio del inmueble ni un diagnóstico individual de pobreza energética. Menor renta produce mayor puntuación relativa social mediante el motor de ranking existente. Los pesos siguen siendo hipótesis metodológicas del usuario.

## Fuente y localización

- INE: https://www.ine.es/servergis2/rest/services/ws/ADRH_renta_media_por_persona/MapServer . Se consulta la capa 2, ADRH_secciones_t. El servicio se verificó como ADRH 2024. La respuesta `periodo` de cada sección confirma 2024, frente a páginas informativas antiguas que todavía mostraban 2023.
- Catastro: https://ovc.catastro.meh.es/OVCServWeb/OVCWcfCallejero/COVCCoordenadas.svc/rest/help . Consulta_CPMRC devuelve el punto representativo de parcela, domicilio y referencia. Se consulta con los primeros 14 caracteres de la referencia del CEE y EPSG:4326. No resuelve la geometría del edificio ni asegura un portal concreto en parcelas con varios accesos.
- Las localizaciones de los mismos 15 registros se recuperan por posición y huella de fila auditadas del ZIP CEE oficial. El CSV energético original no se modifica. El complemento localizacion_CEE_15.csv conserva dirección y referencia públicas, por lo que deja de ser una muestra anonimizada en su vista social.

Cada respuesta queda congelada en fuentes/social_respuestas, con URL, fecha UTC, contenido y SHA-256. La reproducción usa esas respuestas sin red; no reemplaza silenciosamente las rentas al cambiar el servicio. Para actualizar otra edición debe crearse una nueva copia del conjunto de respuestas y revisar el año y el esquema. No confundir reproducción congelada con consulta en vivo.

Se exige una parcela única, referencia devuelta coincidente, coordenadas plausibles, sección única, indicador y unidad correctos y año identificado. Para el piloto Madrid se exige código municipal 28079. Se consulta además un radio de 5 metros alrededor del punto: más de una sección implica revisión. Es una salvaguarda conservadora, no una validación geométrica completa de toda la parcela. La cartografía es la incorporada a la propia capa ADRH consultada; no se mezcla con un seccionado actual descargado aparte.

Se contrasta la dirección textual con el domicilio catastral: tokens de vía y primer número, tras normalizar abreviaturas y acentos. Las indicaciones de bloque se remiten a revisión. La coincidencia es una comprobación automática auxiliar, no una verificación presencial. Sin referencia única no se escoge un candidato por parecido: el usuario puede completarla en la interfaz. No se ha añadido OCR de certificados PDF.

## Resultado de los 15 CEE

Se encontraron 15 rentas candidatas de 2024. Hay 13 enlaces automáticos con dirección compatible; dos permanecen pendientes:

- CEE_MAD_05: CEE en calle Minerva frente a domicilio de parcela en calle Omega. Puede existir un acceso alternativo, pero no se presupone.
- CEE_MAD_14: CEE con bloque 31 y número 19 frente a domicilio catastral Pozohalcón 31(S). Requiere conciliar bloque, portal y parcela.

CEE_MAD_12 tiene una cota superior publicada por secreto estadístico, según nota literal del INE. No se trata como renta exacta: queda excluida por defecto del ranking y puede incorporarse explícitamente como sensibilidad. Resultado inicial: **12 rentas utilizables, 2 localizaciones pendientes y 1 cota excluida**. Al activar cotas, 13 rentas utilizables. Las rentas candidatas de los pendientes son visibles solo para auditoría.

## Interfaz y exportación

El módulo «Entorno social · INE» muestra dirección CEE, domicilio catastral, sección, año, renta candidata/publicada, nota original, calidad, motivo e inclusión efectiva. Permite consultas individuales, completar referencias y descargar auditoría y trazabilidad. La barra lateral permite desactivar la renta y activar opcionalmente cotas. El ranking energético conserva los 15 registros; cuando el peso social es positivo, solo los que tienen renta utilizable reciben puntuación del escenario social. No se sustituyen vacíos por cero ni se reponderan las dimensiones silenciosamente.

El CSV del ranking conserva sección, año, fuente, notas y huella del complemento social. CRREM sigue siendo independiente de la renta. La renta 2024 se utiliza como contexto de certificados fechados en 2025; no se etiqueta como renta de 2025.

Para reproducir: `python social.py` recupera la localización original y reproduce el enlace con las respuestas congeladas. `python -m pytest -q` comprueba, entre otros casos, la reproducción sin red, la correspondencia por ID al reordenar filas, el bloqueo de secciones ambiguas, las dos exclusiones y el tratamiento opcional de cotas.

IA utilizada: Codex para implementar el enlace, inspeccionar respuestas oficiales, documentar y preparar comprobaciones. No se ha utilizado para estimar rentas ni completar localizaciones ausentes.
