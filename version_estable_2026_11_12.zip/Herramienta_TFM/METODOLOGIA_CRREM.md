# Continuación verificable del TFM · 24/10/2026

**Revisión de cálculo posterior al piloto:** el carbono ya no está deshabilitado. El módulo operacional calcula energía y carbono y se contrasta con los cuatro ejemplos oficiales y su agregado. Para los CEE se han añadido escenarios con hipótesis explícitas, sin declararlos operacionales. El documento vigente para ese módulo es `CRREM_IMPLEMENTACION.md`; los apartados históricos de esta nota describen lo disponible en cada fase anterior.

**Actualización del piloto real:** se localizó el ZIP completo CEE Madrid 2025 en Descargas y se contrastó con una nueva descarga oficial. Su SHA-256 coincide con el documentado. La aplicación usa ahora 15 certificados seleccionados reproduciblemente desde esa fuente y se han retirado los ejemplos ficticios. El estado actual, resultados y reglas de selección están en `PILOTO_15_CEE.md`; este documento conserva también la cronología de las revisiones anteriores, cuando esos archivos aún no estaban localizados. La muestra histórica de 80 filas y su informe se conservan solo en `publicacion/referencias_v03`, fuera de la aplicación activa.

## Inventario y alcance

Se continúa el código existente en `publicacion/Herramienta_TFM`; no se ha reconstruido el proyecto desde cero. Se conserva el ranking energético, climático CEE y social territorial.

Se recuperó `Markdown pegado.md` desde el adjunto del chat de continuidad y se conserva como `CONTINUIDAD_RECUPERADA.md`. El adjunto comienza con la continuación del apartado 3.4; los primeros apartados solo son visibles parcialmente en el chat recuperado.

En la primera revisión no se encontraron en la carpeta del proyecto el ZIP v0.3, la guía docente, el ZIP CEE Madrid 2025 ni sus tablas de auditoría. Posteriormente el usuario facilitó `C:/Users/ornet/Downloads/Herramienta_TFM_v03_Grafica_CRREM.zip`: se revisó íntegramente y se extrajo sin sobrescribir la continuación en `publicacion/referencias_v03/Herramienta_TFM_v03`. Siguen sin localizarse `Área de contenido.pdf`, el ZIP completo CEE 2025 y su auditoría. No se han buscado otros archivos personales fuera de las rutas facilitadas.

Las 18 pruebas originales de v0.3 se ejecutaron con éxito en su carpeta aislada. Las cifras de la auditoría completa siguen sin reproducirse. No se verifica el calendario académico ni se afirma haber revisado la guía docente ausente. Esta entrega integra las funciones útiles recuperadas de v0.3 y las referencias oficiales de la continuación; no es una versión final científicamente validada.

### Recuperación de v0.3

SHA-256 del ZIP: `637e7bf5914ddeb9502ad1e92bd2a202c00c9daf69a88853bc19d37d043b51f1`. Se recuperaron el diagnóstico pre-CRREM, la muestra CEE de 80 filas y sus cinco pruebas originales (una expectativa se corrigió para no considerar acreditada una cohorte por su formato). Se añadieron tres regresiones del diagnóstico y dos pruebas de sus módulos en la interfaz. Se restituyó la tabla que compara los puestos por m² y anual con los mismos filtros.

La interfaz anterior de curvas ficticias/importadas y su modelo se conservan en la referencia v0.3, pero no se activan en la continuación: la carga oficial integrada, la comprobación de huellas y el contrato operacional estricto sustituyen a las casillas que daban por verificada una curva importada. El motor de carbono previo sigue siendo referencia de desarrollo, no una evaluación validada.

La muestra incluida en v0.3 se conserva byte a byte; SHA-256 `826abde6018ee1875f2375cfb895767a407b6af22525e967304297e14dbe7590`. El README original la describe como real y seleccionada, pero faltan el conjunto fuente y el script de selección para comprobar ese origen. Se auditaron únicamente sus 80 filas: todas declaran bloque completo existente y pasan controles numéricos/coherencia CEE; ninguna permite acreditar los vectores de cada servicio con los campos presentes. Los agregados por vector son un reparto previo estimado y no sustituyen esa evidencia. EUI operacional y año CRREM se mantienen vacíos. `AUDITORIA_MUESTRA_V03.json` conserva los recuentos y columnas.

El campo `anio_certificado` indica 2024 en 79 filas y 2025 en una. No debe confundirse el año del certificado con el año del recurso de descarga ni interpretarse esta selección como muestra representativa de 2025. Las cifras 110.650 / 12.930 / 10.144 del README v0.3 se consideran afirmaciones heredadas pendientes de reproducción, no resultados de esta entrega.

## Fuentes oficiales congeladas

- Biblioteca oficial consultada el 24/10/2026: https://crrem.org/learn/
- Dataset enlazado como v2.05, 30/04/2026: https://crrem.org/wp-content/uploads/crrem-library/pathways-v2.05.xlsx
- Assessment Guide v1.03, mayo de 2026 (página actualizada el 28/05/2026): https://crrem.org/library/assessment-guide/
- Technical Blueprint v1.1, exportado el 29/07/2026: https://crrem.org/wp-content/uploads/crrem-library/blueprint.md
- Factores: https://crrem.org/wp-content/uploads/crrem-library/emission-factors-v2.05.xlsx

Los originales están en `fuentes/`; `manifest.json` registra URL y SHA-256. El motor comprueba esas huellas antes de leer las curvas. No necesita conexión durante el análisis.

Se inspeccionaron ambas hojas en m²: `CO2 Pathways (sqm)` y `EUI Pathways kWh (sqm)`. La cabecera está en la fila 5, años 2020–2050 en H:AL. España unifamiliar está en la fila 270 y plurifamiliar en la 271. Se seleccionan país y tipo exactos, no números de fila codificados. Ambas hojas identifican escenario 1,5 °C. La hoja de carbono excluye gases fluorados y se etiqueta kgCO₂, sin afirmar que represente todos los GEI.

Comprobaciones de referencia del libro: plurifamiliar H271 = 96,607045707958 kWh/m²·año; M271 (2025) = 74,8876217803633; R271 (2030) = 58,0512099797786. En carbono R271 = 6,01932155854557 kgCO₂/m²·año. Son umbrales de referencia, no resultados de edificios madrileños.

Incidencias documentales: el resumen del libro de trayectorias dice `Version: V2.05 - xxxx 2026`; se conserva literalmente y se toma la fecha publicada en la biblioteca como metadato externo. El libro de factores incluye enlaces de algunos combustibles con año 2027, posterior a esta consulta. No se corrigen ni completan esos datos de forma inventada. La comparación de carbono del edificio queda deshabilitada, aunque se permite explorar su curva. La web oficial también informa de una revisión de la metodología energética en curso: https://crrem.org/news-article/towards-the-next-generation-of-crrem-energy-pathways/. Una propuesta de revisión no se trata como nueva trayectoria adoptada.

## CEE: magnitudes y límites

El modo por m² usa la intensidad del certificado sin dividirla de nuevo por superficie. El total anual se calcula como intensidad × superficie del mismo certificado, manteniendo su perímetro. Superficies ausentes, no finitas o no positivas impiden el total anual. No se rellena con cero. Los totales son calculados del CEE, no energía medida, ahorro potencial ni totales de edificios completos cuando el certificado cubre una parte.

No se convierte `norenov_global` con un coeficiente general. `final_global` no se interpreta como consumo operacional completo. Tampoco se suman automáticamente energía global y servicios: podría duplicarse energía. No se equipara superficie habitable con GIA.

Para desarrollar el estimador propuesto en continuidad faltan: CSV y diccionario originales comprobados, conciliación por servicio/vector, usos omitidos y posibles solapamientos, fuentes estadísticas originales pertinentes, número de viviendas cuando corresponda, calibración de uso/clima, superficie compatible y análisis de incertidumbre. No se implementan factores arbitrarios ni otra corrección climática sobre el certificado sin una meteorología de referencia definida.

## Comparación energética operacional

El módulo independiente admite solo España y residencial unifamiliar/plurifamiliar. EUI = suma de energía consumida / GIA; incluye renovable producida y autoconsumida, excluye exportación. No calcula CO₂ del edificio. Requiere 12 meses, cobertura completa, ocupación completa, perímetro completo y GIA verificada. Casos parciales quedan bloqueados: no se extrapolan. Las declaraciones son responsabilidad del investigador y no sustituyen una auditoría.

A: medido y declarado compatible; B: estimado con fuente/justificación; C: CEE calculado no operacional; D: insuficiente. A/B son etiquetas internas de procedencia, no certificaciones de calidad CRREM. Las estimaciones necesitan además incertidumbre y validación externa antes de usarse como conclusiones.

El primer cruce es el primer año con intensidad del edificio estrictamente mayor que el umbral. Igualdad no es cruce; un edificio ya por encima devuelve el año base; sin cruce se informa “sin cruce hasta 2050”. No se interpola ni extrapola sobre años ausentes. Demanda constante es el caso base; la reducción compuesta del deslizador es un escenario del usuario. Los totales anuales se muestran como apoyo y no cambian la definición de alineamiento por intensidad.

El módulo no aplica ajustes de cobertura, vacancia, clima, usos mixtos, factores de emisión futuros, créditos de exportación ni gases fluorados. No se presenta como implementación completa ni evaluación certificada de CRREM.

## Contrato de entrada JSON

El archivo debe contener valores reales documentados; esta plantilla con campos pendientes no es un ejemplo evaluable. Los vectores no utilizados deben declararse como 0 tras comprobarlo. Las cantidades son kWh/año consumidos, nunca energía primaria ni energía exportada.

```json
{
  "pais": "Spain",
  "tipo": "Residential Multi-Family",
  "anio": 2025,
  "origen": "medido",
  "justificacion": "Identificar facturas, contadores, periodo, superficie y conciliación",
  "meses": 12,
  "perimetro_completo": false,
  "gia_verificada": false,
  "cobertura_completa": false,
  "ocupacion_completa": false,
  "gia_m2": null,
  "consumos_kwh": {
    "electricidad_red": null, "gas": null, "gasoleo": null,
    "calor_red": null, "frio_red": null, "biomasa": null,
    "otros": null, "renovable_autoconsumida": null
  }
}
```

## Reproducción y pendientes

Python 3.12 recomendado. Instalar `requirements-lock.txt`, ejecutar `python -m pytest -q` y `python -m streamlit run app.py` desde la carpeta de la herramienta. Los archivos originales están congelados; cambiarlos exige revisar fuentes, manifiesto y pruebas. Los datos de prueba son sintéticos. El test del valor del libro no constituye validación independiente frente a ejemplos oficiales de edificios.

Para finalizar el caso real: recuperar guía docente y auditoría anterior; verificar definiciones, unidades y unidad de análisis, certificados sucesivos y duplicados; conciliar datos operacionales y GIA; validar carbono contra ejemplos oficiales y resolver factores; completar cruce social territorial. El ZIP CEE 2025 completo ya está disponible y se ha reproducido un piloto de 15 registros; se calculó sensibilidad energética sin componente social. Aún no hay una clasificación operacional CRREM de edificios reales.

## Uso de IA

24/10/2026 — Codex/OpenAI: recuperación de contexto, inventario local, consulta y descarga de fuentes oficiales, revisión metodológica, ampliación del código existente, pruebas y documentación. No se ha empleado aprendizaje automático para predecir consumos. El autor debe revisar y comprender el código y declarar el uso de IA según la guía docente cuando se recupere.
