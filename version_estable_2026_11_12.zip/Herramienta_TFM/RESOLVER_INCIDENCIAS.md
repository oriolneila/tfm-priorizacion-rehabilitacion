# Resolver incidencias sin depender del chat

En el menú lateral, abre **Resolver incidencias**. La primera versión resuelve los enlaces de localización y renta social; ofrece además orientación hacia los módulos donde completar o corregir datos CEE y entradas operacionales CRREM.

1. Elige el CEE. Por defecto se muestran los casos pendientes y las rentas con limitación del INE. Desmarca el filtro para consultar una revisión anterior o revisar voluntariamente otro CEE.
2. Lee la discrepancia. La ficha muestra dirección del certificado, domicilio catastral y referencia de parcela. Incluye enlaces a Catastro, tablas de renta del INE y cartografía del servicio oficial, con instrucciones sobre qué consultar. No se requiere buscar documentación en este chat.
3. Comprueba parcela y portales. Si confirmas que las dos direcciones corresponden a accesos de la misma parcela y a la sección indicada, conserva la renta candidata. Si has comprobado otra sección, introduce su código completo de 10 dígitos y consulta la renta oficial desde la ficha. El programa comprueba indicador, unidad y periodo; no permite escribir una renta arbitraria.
4. Registra persona revisora, fecha, enlace de evidencia y una explicación del resultado. Confirma que realizaste la comprobación y decide aceptar, mantener pendiente o excluir del cálculo social. No introduzcas información privada sobre residentes.
5. Guarda. La aplicación vuelve a calcular el conjunto: una aceptación aparece como **Enlace revisado manualmente**; una exclusión o un caso pendiente no aporta renta al ranking. No se modifica el certificado original ni CRREM.

## Límites y conservación

Una revisión humana no elimina las notas de secreto estadístico. La cota de CEE_MAD_12 permanece limitada y solo puede incorporarse al ranking con la opción explícita de cotas de la barra lateral. La edición de renta se conserva para no mezclar años al corregir una sección de la cohorte.

Las decisiones se guardan en **datos_usuario/revisiones.sqlite3**, en el equipo donde se ejecuta Streamlit, separadas por SHA-256 del archivo CEE. Se recuperan tras recargar o reiniciar la herramienta. Se conserva un historial de decisiones: para revertir una aceptación, registra una nueva revisión pendiente o excluida. No es una firma digital ni autentica la identidad del revisor.

Si cambia el contenido del archivo CEE, se trata como otro conjunto y no hereda revisiones. Si cambia una renta candidata, sección, dirección o localización tras una nueva consulta, su huella ya no coincide y la revisión previa queda pendiente de repetición. No se borra el historial.

La ficha permite descargar el historial en JSON como copia legible. Para trasladar el estado completo a otra instalación, copia la carpeta **datos_usuario** junto a la herramienta y utiliza el mismo archivo CEE. El JSON de historial no tiene importación automática. La entrega de distribución excluye esa carpeta para no incluir revisiones de usuarios. Las respuestas oficiales se conservan en fuentes/social_respuestas para reproducir las consultas.

Las exportaciones del ranking conservan el estado manual, responsable, fecha, evidencia y explicación de la revisión aplicada. La auditoría social incluye la revisión y la fuente de la renta.

Los tres casos reales del piloto siguen sin resolverse hasta que una persona haga la comprobación. Las aceptaciones simuladas de las pruebas solo se escriben en bases temporales aisladas y no se incorporan al estudio.

## Verificación

La suite comprueba persistencia entre sesiones, separación entre conjuntos, aceptación, reversión, campos obligatorios, fecha no futura, invalidación tras cambiar datos, protección de las cotas y consulta de renta por código de sección sin conexión usando una respuesta oficial congelada. También comprueba el formulario de la interfaz y la actualización del ranking.
