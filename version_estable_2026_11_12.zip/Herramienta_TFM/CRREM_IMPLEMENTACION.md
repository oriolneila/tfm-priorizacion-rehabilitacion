# Cálculo CRREM: implementación y límites de las entradas

Estado del 24/10/2026. Esta revisión sustituye las descripciones anteriores que indicaban que el carbono estaba deshabilitado.

## Funciones implementadas

El módulo calcula energía final anual, EUI, emisiones por vector, carbono bruto/neto, crédito de exportación, intensidad anual de carbono y primer año de superación de las trayectorias de energía y carbono hasta 2050. La electricidad usa el factor anual oficial de España y no una reducción arbitraria de emisiones. La energía de referencia se mantiene constante; la mejora anual positiva es un escenario del usuario.

Se incluyen las renovables producidas y autoconsumidas en EUI, con factor de emisiones cero. Las renovables exportadas no forman parte de EUI. El crédito de exportación queda limitado a las emisiones de la electricidad importada: el excedente no compensa gas, gasóleo ni otras emisiones.

Alcance de la interfaz: España, residencial unifamiliar o plurifamiliar de uso único, escenario 1,5 °C, CO₂ sin gases fluorados, periodo completo de 12 meses y ocupación completa declarada. No se extrapolan vacancia, cobertura ni periodos parciales. No se implementan correcciones climáticas futuras ni se confunde la zona IDAE con una trayectoria CRREM. El núcleo incluye agregación por GIA para validación; la interfaz se centra en cada certificado.

## Validación contra la referencia oficial

Se descargaron el libro `worked-examples-v1.1.xlsx` y su compañero `worked-examples-fixtures-v1.1.json` desde https://crrem.org/learn/. No se cargan como edificios madrileños: sirven exclusivamente para contrastar el cálculo.

| Ejemplo oficial | EUI calculada, kWh/m²·año | CI calculada, kg CO₂/m²·año | Año energía | Año carbono |
|---|---:|---:|---:|---:|
| Midtown Tower | 158,6667 | 34,9058 | 2024 | 2025 |
| Pacific Plaza Mall | 232,7273 | 106,6183 | 2031 | 2036 |
| Northgate Quarter | 141,6667 | 20,1965 | 2030 | 2036 |
| Tokyo Logistics Park | 56,0667 | 15,5856 | 2030 | 2032 |
| Agregado por GIA | 156,6549 | 54,5759 | 2030 | 2035 |

Los diez años coinciden exactamente con los publicados. Las intensidades quedan dentro de las tolerancias oficiales; la diferencia máxima frente a las curvas de carbono redondeadas de los cuatro ejemplos es inferior a 0,001 kg/m²·año. Se recalculan las emisiones desde los consumos y factores del libro y los cruces desde sus trayectorias; no se copian los años esperados como resultado.

El ejemplo mixto utiliza las proporciones de uso del libro oficial para construir la curva de referencia; no implica que la interfaz española admita cualquier caso mixto o región mundial. El informe reproducible está en `datos_piloto/validacion_referencias_CRREM.json`. Reproducir los ejemplos no constituye aval de CRREM Foundation ni valida la calidad de las entradas del piloto.

## Dos modos de uso

### 1. Escenario a partir del CEE

Este modo funciona con los 15 certificados reales ya seleccionados. Reconstruye los servicios de calefacción, refrigeración y ACS multiplicando sus intensidades de energía final por la superficie habitable del certificado. Asigna cada servicio al vector del sistema declarado cuando es único y reconocido. Un vector ambiguo impide el cálculo; un cero del registro no acredita que el uso operacional no exista.

La superficie habitable actúa como **denominador proxy de GIA**, expresamente no verificado. La relación inicial 1 conserva la magnitud existente del CEE: no es un factor de conversión aprobado. Puede modificarse como sensibilidad; se registra en la exportación. Se asume un escenario sin flujos FV, exportaciones ni consumos comunes adicionales desconocidos. No se transforman esas hipótesis en datos observados.

Por defecto se calculan únicamente los servicios CEE, manteniendo las advertencias de perímetro incompleto. Se muestran los **cruces matemáticos del escenario**, mientras el campo de año CRREM operacional permanece vacío. El modo por m² y la vista anual de la gráfica multiplican ambas curvas por la misma superficie; no cambian el cruce.

### Complemento estadístico opcional IDAE

Fuente: IDAE, SPAHOUSEC III, publicación enero 2026, información estadística de referencia 2021 y mediciones 2021–2022. Descarga original: https://informesweb.idae.es/descargas/SPAHOUSEC%20III%20-%20Descargas.zip. Se lee `01 Consumo por uso y zona climática.xlsx`, hoja `Export`. El perfil derivado conserva la huella del ZIP, huella de la tabla y filas utilizadas en `fuentes/perfil_IDAE_SPAHOUSEC_III.json`.

Para cada zona y vector soportado se calcula:

    R_v = consumo IDAE de otros usos del vector / consumo IDAE conjunto de calefacción, refrigeración y ACS del mismo vector
    complemento_v = energía CEE de esos servicios y vector × R_v

Se usa una razón adimensional entre consumos en ktep: no se confunden ktep regionales con kWh de un edificio. La iluminación ya certificada se descuenta del complemento eléctrico para no sumarla dos veces. No se imputan vectores nuevos a partir de una cocina o equipamiento no observado. No hay un coeficiente genérico desde EPNR ni doble corrección climática.

En la zona Continental, los cocientes otros/térmicos son aproximadamente 5,08134 para electricidad, 0,042849 para gas natural y 0 para gasóleo. **No son coeficientes calibrados para los 15 edificios.** La agregación incluye viviendas con distintos combustibles y tipologías; transferirla a un edificio con calefacción eléctrica puede exagerar su consumo. Por eso el complemento está desactivado por defecto y se presenta como análisis de sensibilidad, no como estimador operacional validado.

Ejemplo real del piloto: para `CEE_MAD_01`, usando el escenario de superficie CEE, los servicios certificados producen EUI 57,19 y CI de escenario 5,22598 en 2025; los cruces matemáticos son 2031 (energía) y 2037 (carbono). Al activar la transferencia IDAE, EUI sube a 347,79172 y CI a 31,78094, con cruces en 2025. La diferencia muestra la sensibilidad y el riesgo de transferencia; **no demuestra que el consumo real sea 347,79 ni que el edificio tenga un Misalignment Year operacional en 2025**.

Los dos escenarios no son extremos de un intervalo de confianza ni una estimación del ahorro de rehabilitación. Para fundamentar una estimación B se necesita calibración o contraste independiente de consumos y superficies.

### 2. Evaluación con entradas documentadas

Se admite introducir datos en el formulario o importar JSON. Cada registro se vincula por identificador al certificado seleccionado; no se reutilizan silenciosamente datos de otro conjunto o año. El formulario comienza sin GIA ni valores de consumo inventados. Los vectores no usados requieren cero explícito y comprobado; un dato desconocido permanece vacío y bloquea el resultado.

Se exigen: año, tipología, GIA y su fuente/conciliación, origen medido o estimado, método y fuente de consumos, cobertura completa de 12 meses, perímetro del edificio completo, ocupación completa y compatibilidad de unidades entre energía y factores (incluida base PCI/PCS cuando corresponda). Las estimaciones requieren una explicación de incertidumbre y validación. Los niveles A/B identifican procedencia y compatibilidad declarada, no una certificación independiente.

Electricidad: serie CRREM v2.05 de España, enfoque location-based, años explícitos. Gas natural y gasóleo: valores exactos del libro congelado (0,18316 y 0,24677 kg/kWh), no las aproximaciones de los textos explicativos. Calor/frío de red, biomasa y otros combustibles con consumo positivo requieren factor específico y fuente. Puede aportarse un factor constante o un diccionario año–valor completo. No se aplican por defecto factores de biomasa/otros con referencias temporales inconsistentes en el libro. No se sustituyen el factor eléctrico oficial ni el cero de renovable autoconsumida.

Formato de factor específico:

    {"calor_red": {"valor": <factor numérico o diccionario de años>, "fuente": <referencia verificable>}}

La plantilla descargable contiene campos pendientes, no un edificio ficticio. Los datos introducidos se conservan solo en la sesión; se deben exportar para reproducir el análisis. Los factores y las curvas oficiales están congelados con SHA-256 en `fuentes/manifest.json`.

## Pruebas y reproducción

La revisión ejecutó 55 pruebas: regresiones existentes, cuatro ejemplos y agregado oficiales, crédito de exportación, autoconsumo, factores anuales, rechazo de vacíos/valores inválidos, exigencia de fuente para factores específicos, escenarios de los 15 CEE, sensibilidad de superficie y formularios Streamlit. Las pruebas de referencia y los casos artificiales de límites están aislados de los datos de estudio. Ver `datos_piloto/pruebas.xml` y `VALIDACION.md`.

    python validar_referencias_crrem.py
    python -m pytest -q
    python -m streamlit run app.py --global.developmentMode false

## Qué sigue pendiente científicamente

El motor energético y de carbono ya está implementado y contrastado contra los ejemplos oficiales. Para los 15 CEE, **todavía no existe validación operacional individual**: faltan GIA conciliada, datos de uso/equipamiento/cobertura, consumos medidos o una estimación calibrada y contraste de los servicios omitidos. Esos hechos no se resuelven con una casilla ni con un promedio nacional.

Para convertir el piloto en resultados operacionales defendibles se necesita aportar o recabar esa evidencia, documentar el error de las estimaciones y recalcular. Hasta entonces, los números del modo CEE se denominan escenarios exploratorios. La dimensión social tampoco se completa sin el enlace territorial correspondiente.

## Uso de IA

Codex/OpenAI: implementación y depuración del cálculo, contraste con referencias oficiales, lectura de tablas IDAE, diseño de escenarios explícitos, pruebas, interfaz y documentación. No se han generado facturas, superficies GIA ni consumos medidos de los edificios. El autor debe revisar el modelo de transferencia y su idoneidad académica antes de usarlo en conclusiones.
