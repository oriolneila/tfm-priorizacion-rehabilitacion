"""Escenarios CEE y CEE + estructura IDAE. Nunca los declara operacionales."""
import json
import numpy as np
import pandas as pd
from crrem import ROOT,TIPOS,trayectoria,verificar_fuentes
from crrem_operacional import CARRIERS,numero,anio,factores_espana,proyectar,comparar
from motor import _a_numero

MAPPING={'ElectricidadPeninsular':'electricidad_red','GasNatural':'gas','GasoleoC':'gasoleo'}
SERVICES=(('calef','calefac_vector'),('refrig','refrig_vector'),('acs','acs_vector'))


def num_cee(value,label):
    value=_a_numero(pd.Series([value])).iloc[0]
    return numero(value,label)


def reconstruir(row,perfil='Continental',complementar=True):
    """E_s*superficie, reparto proxy por sistema; complemento solo mismos vectores.

No rellena renta, GIA ni facturas. Las hipótesis de ausencia de otros flujos
se registran como escenario y nunca como observaciones.
"""
    area=numero(num_cee(row.get('edif_superf'),'Superficie CEE'),'Superficie CEE',positivo=True)
    if row.get('edif_tipo')!='BloqueDeViviendaCompleto' or row.get('edif_tiporeg')!='Edificio Existente':
        raise ValueError('El estimador de este piloto requiere bloque completo existente')
    source=json.loads((ROOT/'fuentes/perfil_IDAE_SPAHOUSEC_III.json').read_text(encoding='utf-8'))
    if perfil not in source['perfiles']: raise ValueError('Zona estadística no disponible')
    energy={k:0. for k in CARRIERS}
    detail=[]; warnings=[]
    for service,vectorcol in SERVICES:
        val=num_cee(row.get('final_'+service),service)
        label=str(row.get(vectorcol,'')).strip()
        if val>0:
            if label not in MAPPING:
                raise ValueError(f'{service}: vector ambiguo/no soportado ({label}); no se reparte automáticamente')
            carrier=MAPPING[label]
            amount=val*area
            energy[carrier]+=amount
            detail.append({'componente':service,'vector':carrier,'kwh_anio':amount,'origen':'Servicio CEE × superficie CEE; reparto proxy por vector del sistema'})
        else:
            warnings.append(f'{service}=0 en registro; no acredita ausencia del uso operacional')
    lighting=num_cee(row.get('final_ilu'),'Iluminación CEE')*area
    certified_total=num_cee(row.get('final_global'),'Final global')*area
    if abs(certified_total-sum(energy.values())-lighting)>max(.2*area,.005*certified_total):
        raise ValueError('Suma de servicios y energía global no coherentes')
    if complementar:
        additions={}
        for carrier,baseline in energy.items():
            if baseline==0: continue
            stats=source['perfiles'][perfil].get(carrier)
            if not stats or stats['cociente_otros_sobre_termicos'] is None:
                raise ValueError(f'No existe complemento estadístico para {carrier}')
            amount=baseline*stats['cociente_otros_sobre_termicos']
            # Iluminación ya certificada no se suma por segunda vez.
            if carrier=='electricidad_red': amount=max(0.,amount-lighting)
            additions[carrier]=amount
        energy['electricidad_red']+=lighting
        for carrier,amount in additions.items():
            energy[carrier]+=amount
            detail.append({'componente':'otros usos (incluye iluminación si no está certificada)',
                           'vector':carrier,'kwh_anio':amount,'origen':f'IDAE SPAHOUSEC III, {perfil}; cociente por vector; transferencia no calibrada'})
    else:
        energy['electricidad_red']+=lighting
    if lighting>0:
        detail.append({'componente':'iluminación certificada','vector':'electricidad_red','kwh_anio':lighting,'origen':'CEE; asignación eléctrica explícita'})
    warnings+=['Superficie habitable CEE utilizada como denominador proxy, no GIA conciliada',
               'Sin ajuste de uso/clima calibrado; CEE en condiciones estándar',
               'Hipótesis de escenario: sin flujos FV, exportación ni consumos comunes adicionales',
               'Complemento IDAE conserva vectores CEE; no acredita cocina, ocupación ni cobertura individual']
    return {'consumos_kwh':energy,'superficie_proxy_m2':area,'detalle':detail,'advertencias':warnings,
            'fuente_estadistica':{'perfil':perfil,'sha256_tabla':source['sha256_tabla'],'url':source['url']},
            'calidad':'C: escenario CEE/IDAE, sin validación operacional',
            'crrem_operacional_evaluable':False}


def evaluar_cohorte(raw,base=2025,complementar=True,reduccion=0,perfil='Continental',ratio_superficie=1.):
    verificar_fuentes()
    base=anio(base); ratio_superficie=numero(ratio_superficie,'Relación superficie',positivo=True)
    curves=(trayectoria(TIPOS[1],'energia'),trayectoria(TIPOS[1],'carbono'))
    from modulo_energia_cee import diagnosticar
    controls=diagnosticar(raw)
    frames={};reports={};rows=[]
    for pos,(index,row) in enumerate(raw.iterrows()):
        identity=str(row.get('id',row.get('edif_codreg',f'Fila-{index+1}')))
        if identity in reports: raise ValueError('Identificadores repetidos: no se sobrescriben edificios')
        try:
            control=controls.iloc[pos]
            if not control['candidato_precrrem'] or control['alerta_extremo_cee']:
                raise ValueError('No supera controles exploratorios CEE: tipo, servicios, suma, vectores, superficie (25–100.000 m²) o energía final (5–1.000 kWh/m²·año). Revisar certificado; estos límites no son umbrales oficiales CRREM.')
            model=reconstruir(row,perfil,complementar)
            area=model['superficie_proxy_m2']*ratio_superficie
            factors,source=factores_espana(model['consumos_kwh'],base)
            projected=proyectar(model['consumos_kwh'],area,factors,base,exportacion=0,reduccion=reduccion)
            frame,cross=comparar(projected,*curves,base,area)
            frames[identity]=frame
            reports[identity]={'estimacion':model,'fuentes_factores':source,'cruce_exploratorio':cross,
                               'superficie_escenario_m2':area,'ratio_superficie':ratio_superficie,
                               'reduccion_anual':reduccion,'base_escenario':base,
                               'operacional_validado':False}
            rows.append({'certificado':identity,'estado':'Escenario calculado; no evaluación operacional',
                         'superficie_escenario_m2':area,'eui_escenario':float(frame.eui_kwh_m2_anio.iloc[0]),
                         'ci_escenario':float(frame.ci_kg_m2_anio.iloc[0]),'cruce_energia_exploratorio':cross['energia'],
                         'cruce_carbono_exploratorio':cross['carbono'],'MY_operacional':pd.NA})
        except (ValueError,KeyError,TypeError) as exc:
            reports[identity]={'error':str(exc),'operacional_validado':False}
            rows.append({'certificado':identity,'estado':'No evaluable: '+str(exc),'MY_operacional':pd.NA})
    return pd.DataFrame(rows),frames,reports
