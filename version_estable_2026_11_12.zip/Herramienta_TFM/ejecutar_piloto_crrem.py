"""Reproduce escenarios de los 15 CEE y el contraste con referencias oficiales."""
import hashlib
import json
import pandas as pd
from crrem import ROOT,verificar_fuentes
from motor import cargar_archivo,exportar_csv
from reconstruccion_cee import evaluar_cohorte
from validar_referencias_crrem import validar


def ejecutar():
    folder=ROOT/'datos_piloto'
    path=folder/'CEE_Madrid_15_reales.csv'
    contents=path.read_bytes()
    origin=json.loads((folder/'seleccion_y_procedencia.json').read_text(encoding='utf-8'))
    if hashlib.sha256(contents).hexdigest()!=origin['sha256_muestra']:
        raise ValueError('Muestra modificada respecto a su procedencia')
    raw=cargar_archivo(path.name,contents)
    sources=verificar_fuentes()
    references=validar()
    if not all(r['superado'] for r in references):raise ValueError('Falló la validación de referencias CRREM')
    (folder/'validacion_referencias_CRREM.json').write_text(json.dumps(references,ensure_ascii=False,indent=2),encoding='utf-8')
    curves=[];info=[]
    for include,label in [(False,'CEE_parcial'),(True,'CEE_IDAE_escenario')]:
        summary,frames,trace=evaluar_cohorte(raw,base=2025,complementar=include)
        (folder/(label+'_resumen.csv')).write_bytes(exportar_csv(summary))
        (folder/(label+'_trazabilidad.json')).write_text(json.dumps({'fuente_cee':origin,
            'escenarios':trace,'fuentes_referencia':sources},ensure_ascii=False,indent=2),encoding='utf-8')
        if frames:
            curves.append(pd.concat([frame.assign(certificado=identity,escenario=label).reset_index()
                                     for identity,frame in frames.items()],ignore_index=True))
        info.append({'escenario':label,'certificados':len(raw),'calculados':len(frames),
                     'evaluaciones_operacionales_validadas':0,
                     'interpretacion':'Cruces matemáticos de escenarios CEE, no años CRREM operacionales'})
    if curves:(folder/'proyecciones_15_CEE_escenarios.csv').write_bytes(exportar_csv(pd.concat(curves,ignore_index=True)))
    (folder/'estado_calculo_CRREM.json').write_text(json.dumps({'escenarios':info,'referencias_oficiales_superadas':5,
        'fuente_muestra_sha256':origin['sha256_muestra'],
        'pendiente':'GIA conciliada y consumos completos medidos o estimación individual calibrada'},ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(info,ensure_ascii=False,indent=2))


if __name__=='__main__':ejecutar()
