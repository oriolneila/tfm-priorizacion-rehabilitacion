"""Panel de cálculo operacional y escenarios CEE claramente diferenciados."""
import hashlib
import json
import altair as alt
import pandas as pd
import streamlit as st
from crrem import ROOT,TIPOS,trayectoria,verificar_fuentes
from crrem_operacional import CARRIERS,evaluar
from reconstruccion_cee import evaluar_cohorte
from motor import normalizar,exportar_csv
from apariencia import grafica

LABELS={'electricidad_red':'Electricidad de red','gas':'Gas natural','gasoleo':'Gasóleo',
        'calor_red':'Calor de red','frio_red':'Frío de red','biomasa':'Biomasa','otros':'Otros combustibles',
        'renovable_autoconsumida':'Renovable generada y consumida en el edificio'}


def plantilla(identity,tipo,base):
    return {'id':identity,'pais':'Spain','tipo':tipo,'anio':base,'origen':'estimado','meses':12,
            'gia_m2':None,'fuente_superficie':'','justificacion':'','incertidumbre':'',
            'gia_verificada':False,'perimetro_completo':False,'cobertura_completa':False,'ocupacion_completa':False,
            'unidades_compatibles':False,
            'consumos_kwh':{k:None for k in CARRIERS},'renovable_exportada_kwh':None,
            'emisiones_f_gases_kg_anio':0,'factores_especificos':{}}


def dibujar(frame,cross,metrica,annual,area,label,operacional):
    energy=metrica=='energia'
    value='eui_kwh_m2_anio' if energy else 'ci_kg_m2_anio'
    limit='umbral_eui' if energy else 'umbral_ci'
    unit=('kWh' if energy else 'kg CO₂')+('/año' if annual else '/m²·año')
    data=frame[[value,limit]].copy()
    if annual: data=data*area
    data=data.rename(columns={value:label,limit:'CRREM v2.05'}).rename_axis('Año').reset_index()
    long=data.melt('Año',var_name='Serie',value_name='Intensidad')
    colors=alt.Scale(domain=['CRREM v2.05',label],range=['#15564A','#437DA2'])
    chart=alt.Chart(long).mark_line(strokeWidth=3).encode(
        x=alt.X('Año:Q',axis=alt.Axis(format='d')),y=alt.Y('Intensidad:Q',title=unit),
        color=alt.Color('Serie:N',scale=colors),strokeDash='Serie:N',tooltip=['Año:Q','Serie:N','Intensidad:Q'])
    year=cross[metrica]
    if year is not None:
        marker=pd.DataFrame({'Año':[year],'valor':[float(data.loc[data['Año'].eq(year),label].iloc[0])]})
        chart=chart+alt.Chart(marker).mark_rule(color='#DCA03D',strokeDash=[4,4]).encode(x='Año:Q')
        chart=chart+alt.Chart(marker).mark_point(color='#DCA03D',filled=True,size=110).encode(x='Año:Q',y='valor:Q')
    st.altair_chart(grafica(chart.properties(height=340)),width='stretch')
    a,b=st.columns(2)
    title='Año de desalineamiento' if operacional else 'Cruce matemático del escenario'
    a.metric(title+' energético',str(cross['energia']) if cross['energia'] is not None else 'Sin cruce hasta 2050')
    b.metric(title+' de carbono',str(cross['carbono']) if cross['carbono'] is not None else 'Sin cruce hasta 2050')
    st.caption('Ambas curvas se multiplican por la misma superficie en vista anual; el año de cruce no cambia. Igualdad con el umbral no cuenta como superación.')


def datos_conjuntos(frames,areas,metrica,annual):
    """Conserva cada edificio y su umbral, incluida su superficie en vista anual."""
    value,limit=('eui_kwh_m2_anio','umbral_eui') if metrica=='energia' else ('ci_kg_m2_anio','umbral_ci')
    records=[]
    for identity,frame in frames.items():
        data=frame[[value,limit]].rename(columns={value:'Valor',limit:'Umbral CRREM'}).rename_axis('Año').reset_index()
        if annual:data[['Valor','Umbral CRREM']]*=areas[identity]
        data['Certificado']=identity
        data['Superficie (m²)']=areas[identity]
        records.append(data)
    return pd.concat(records,ignore_index=True)


def dibujar_conjunto(frames,areas,metrica,annual,total,selected=None):
    st.subheader('Todos los CEE · comparación conjunta')
    if not frames:
        st.info('No hay certificados con datos suficientes para esta comparación.');return
    data=datos_conjuntos(frames,areas,metrica,annual)
    unit=('kWh' if metrica=='energia' else 'kg CO₂')+('/año' if annual else '/m²·año')
    if len(frames)>50:
        grouped=data.groupby('Año')
        bands=grouped.Valor.quantile([.1,.5,.9]).unstack().rename(columns={.1:'P10',.5:'Mediana',.9:'P90'}).reset_index()
        chart=alt.Chart(bands).mark_area(opacity=.2,color='#437DA2').encode(x=alt.X('Año:Q',axis=alt.Axis(format='d')),y=alt.Y('P10:Q',title=unit),y2='P90:Q')
        chart+=alt.Chart(bands).mark_line(color='#437DA2',strokeWidth=3).encode(x='Año:Q',y='Mediana:Q',tooltip=['Año:Q','P10:Q','Mediana:Q','P90:Q'])
        if not annual:
            limits=data[['Año','Umbral CRREM']].drop_duplicates()
            chart+=alt.Chart(limits).mark_line(color='#15564A',strokeDash=[6,4],strokeWidth=3).encode(x='Año:Q',y='Umbral CRREM:Q')
        st.altair_chart(grafica(chart.properties(height=400)),width='stretch')
        st.caption(f'Resumen de los {len(frames)} escenarios: mediana y banda P10–P90 de valores por certificado, sin ponderar. La banda no es un intervalo de confianza. '+('En anual cada edificio tiene su propio umbral; no existe una trayectoria anual común.' if annual else 'Línea verde: trayectoria CRREM por m².'))
        chosen=st.multiselect('Certificados para comparar como líneas (máximo 50)',list(frames),default=[selected] if selected in frames else list(frames)[:1],max_selections=50)
        st.download_button('Descargar datos de todos los escenarios de la gráfica',exportar_csv(data),'comparacion_conjunta_CRREM_completa.csv','text/csv')
        if not chosen:return
        data=data[data.Certificado.isin(chosen)]
        st.caption(f'Comparación detallada: {len(chosen)} certificados seleccionados; el resumen anterior utiliza el conjunto completo.')
    selection=alt.selection_point(fields=['Certificado'],bind='legend')
    assets=alt.Chart(data).mark_line(strokeWidth=2).encode(
        x=alt.X('Año:Q',axis=alt.Axis(format='d')),
        y=alt.Y('Valor:Q',title=unit),
        color=alt.Color('Certificado:N',scale=alt.Scale(scheme='tableau20')),
        opacity=alt.condition(selection,alt.value(.9),alt.value(.1)),
        tooltip=['Certificado:N',alt.Tooltip('Año:Q',format='d'),alt.Tooltip('Valor:Q',format=',.2f'),
                 alt.Tooltip('Umbral CRREM:Q',format=',.2f'),'Superficie (m²):Q']).add_params(selection)
    if annual:
        reference=alt.Chart(data).mark_line(strokeDash=[6,4],strokeWidth=1.5).encode(
            x='Año:Q',y='Umbral CRREM:Q',color='Certificado:N',
            opacity=alt.condition(selection,alt.value(.5),alt.value(.05)),
            tooltip=['Certificado:N','Año:Q','Umbral CRREM:Q','Superficie (m²):Q'])
        caption='Línea continua: cada CEE. Línea discontinua del mismo color: su umbral CRREM multiplicado por su propia superficie. No hay un umbral anual común para edificios de distinto tamaño.'
    else:
        reference=alt.Chart(data[['Año','Umbral CRREM']].drop_duplicates()).mark_line(color='#15564A',strokeWidth=4,strokeDash=[6,4]).encode(
            x='Año:Q',y='Umbral CRREM:Q',tooltip=['Año:Q','Umbral CRREM:Q'])
        caption='Líneas de colores: cada CEE. Línea verde discontinua: trayectoria CRREM común por m².'
    st.altair_chart(grafica((assets+reference).properties(height=460)),width='stretch')
    st.caption(f'{data.Certificado.nunique()} de {total} certificados representados como líneas en esta gráfica. '+caption+' Pulsa un certificado en la leyenda para destacarlo; Mayús permite seleccionar varios. No se suman ni promedian edificios.')
    st.download_button('Descargar datos de la gráfica conjunta',exportar_csv(data),'comparacion_conjunta_CRREM.csv','text/csv')


@st.cache_data(show_spinner=False)
def _cohorte(raw,base,complemento,rate,profile,ratio,manifest_digest):
    return evaluar_cohorte(raw,base,complemento,rate,profile,ratio)


def entrada_formulario(identity,tipo,base):
    method=st.radio('Aportar entradas documentadas',['Editar aquí','Importar JSON'],key='entrada_'+identity)
    if method=='Importar JSON':
        file=st.file_uploader('Entrada o conjunto de entradas operacionales',type='json',key='json_'+identity)
        if file is None:return None
        try:
            parsed=json.loads(file.getvalue())
            entries=parsed if isinstance(parsed,list) else [parsed]
            matches=[x for x in entries if isinstance(x,dict) and x.get('id')==identity]
            if len(matches)!=1:raise ValueError('Debe haber una única entrada con el identificador seleccionado')
            return matches[0]
        except (ValueError,TypeError) as exc:
            st.error(f'Archivo no utilizable: {exc}');return None
    with st.form('operacional_'+identity):
        st.write('Valores anuales finales del edificio completo. Deja vacío lo desconocido; cero solo para un vector comprobado como no utilizado.')
        area=st.number_input('GIA documentada (m²)',min_value=0.,value=None,key='gia_'+identity)
        source_area=st.text_input('Fuente y conciliación de la superficie',key='fuente_area_'+identity)
        origin=st.selectbox('Origen de los consumos',['estimado','medido'],key='origen_'+identity)
        justification=st.text_area('Fuente, periodo y método de los consumos',key='fuente_consumo_'+identity)
        uncertainty=st.text_area('Incertidumbre y validación de las estimaciones',key='incertidumbre_'+identity)
        energy={}
        cols=st.columns(2)
        for i,key in enumerate(CARRIERS):
            energy[key]=cols[i%2].number_input(LABELS[key]+' (kWh/año)',min_value=0.,value=None,key=key+'_'+identity)
        export=st.number_input('Renovable exportada a la red (kWh/año)',min_value=0.,value=None,key='export_'+identity)
        st.caption('La electricidad importada no debe incluir la energía renovable autoconsumida. La producción exportada queda fuera de EUI; su crédito no compensa gas u otros combustibles.')
        specific=st.text_area('Factores específicos de calor/frío, biomasa u otros, si hay consumo (JSON con valor y fuente)',value='{}',key='ef_'+identity)
        gia_ok=st.checkbox('GIA conciliada; excluye aparcamiento interior',key='giaok_'+identity)
        perimeter=st.checkbox('Incluye los usos operacionales de todo el edificio, propietarios y ocupantes',key='perimetro_'+identity)
        coverage=st.checkbox('Cobertura energética completa de 12 meses',key='cobertura_'+identity)
        occupancy=st.checkbox('Ocupación completa; sin extrapolación de vacancia',key='ocupacion_'+identity)
        units=st.checkbox('Consumos finales en kWh compatibles con los factores; PCI/PCS conciliado cuando corresponda',key='unidades_'+identity)
        submit=st.form_submit_button('Calcular energía y carbono')
    if not submit:return None
    try: overrides=json.loads(specific)
    except ValueError:
        st.error('Los factores específicos no son un JSON válido');return None
    entry=plantilla(identity,tipo,base)
    entry.update(gia_m2=area,fuente_superficie=source_area,origen=origin,justificacion=justification,
                 incertidumbre=uncertainty,consumos_kwh=energy,renovable_exportada_kwh=export,
                 gia_verificada=gia_ok,perimetro_completo=perimeter,cobertura_completa=coverage,
                 ocupacion_completa=occupancy,factores_especificos=overrides)
    entry['unidades_compatibles']=units
    return entry


def mostrar_crrem(raw=None):
    st.caption('España residencial · 1,5 °C · CRREM v2.05 · Guide v1.03 · Blueprint v1.1 · CO₂ sin F-gases')
    try:
        manifest=verificar_fuentes()
    except (ValueError,OSError) as exc:
        st.error(f'No se pueden verificar las fuentes: {exc}');return
    tipo_col,base_col=st.columns([3,1])
    with tipo_col:
        tipo=st.selectbox('Tipología CRREM (no se infiere desde el CEE)',TIPOS,index=1)
    with base_col:
        base=int(st.number_input('Año base del análisis',min_value=2020,max_value=2050,value=2025))
    metrica_col,vista_col=st.columns(2)
    with metrica_col:
        metrica=st.radio('Métrica',['energia','carbono'],horizontal=True,format_func=lambda x:{'energia':'Energía','carbono':'Carbono'}[x])
    with vista_col:
        annual=st.radio('Visualización',['Por m²','Anual total'],horizontal=True)=='Anual total'
    mode=st.radio('Modo de cálculo',['Escenario a partir del CEE','Evaluación con entradas documentadas'],horizontal=True)
    if raw is None or raw.empty:
        st.info('Carga un conjunto CEE para seleccionar el registro de trabajo.');return
    normalized,_=normalizar(raw)
    positions=list(range(len(normalized)))
    idx=st.selectbox('Certificado del conjunto activo',positions,format_func=lambda i:str(normalized.iloc[i].id_visual))
    identity=str(normalized.iloc[idx].id_visual)
    from informe_datos import firma
    st.session_state['informe_crrem_config']={'firma':firma(raw),'tipo':tipo,'base':base,'modo':mode,
        'metrica':metrica,'visualizacion':'anual' if annual else 'por m²','certificado':identity}
    known_type={'BloqueDeViviendaCompleto':TIPOS[1],'ViviendaUnifamiliar':TIPOS[0]}.get(str(raw.iloc[idx].get('edif_tipo','')))
    if known_type and tipo!=known_type:
        st.error(f'La tipología del CEE seleccionado corresponde a {known_type}. Revisa la trayectoria elegida.');return
    curve=trayectoria(tipo,metrica)
    st.download_button('Descargar curva oficial seleccionada',curve.rename_axis('anio').to_csv().encode(),'trayectoria_CRREM_ES.csv')
    reduction=st.slider('Hipótesis de reducción energética anual (%)',0,30,0)/100
    st.session_state['informe_crrem_config']['reduccion']=reduction
    st.caption('Cero: energía constante; carbono cambia con el factor eléctrico anual. Una tasa positiva es un escenario del usuario aplicado al consumo, no una reducción directa arbitraria del CO₂. Las exportaciones declaradas permanecen constantes.')
    if mode=='Escenario a partir del CEE':
        st.warning('Escenario exploratorio, no evaluación operacional CRREM: se usa la superficie habitable CEE como proxy de GIA y el reparto por sistemas como proxy de vectores. No hay facturas ni calibración individual. Los años que aparecen son cruces matemáticos condicionados a esas hipótesis.')
        if tipo!=TIPOS[1]:
            st.error('El estimador del piloto corresponde a bloques completos plurifamiliares; selecciona Residential Multi-Family.');return
        complement=st.checkbox('Añadir escenario de otros usos según estructura IDAE SPAHOUSEC III',value=False)
        profile=st.selectbox('Zona estadística IDAE',['Continental','Atlántico norte','Mediterráneo'],index=0) if complement else 'Continental'
        # Las etiquetas se validan contra el perfil realmente descargado.
        profiles=json.loads((ROOT/'fuentes/perfil_IDAE_SPAHOUSEC_III.json').read_text(encoding='utf-8'))['perfiles']
        if complement and profile not in profiles:
            st.error('La etiqueta seleccionada no coincide con las zonas de la tabla IDAE.');return
        ratio=st.number_input('Superficie del escenario / superficie habitable CEE',min_value=.01,value=1.,step=.05)
        st.session_state['informe_crrem_config'].update(complemento=complement,perfil=profile,ratio=ratio)
        st.caption('1 conserva la superficie CEE: no afirma que sea GIA. Otros valores son sensibilidad definida por el usuario, no factores oficiales de conversión.')
        if complement:
            st.info('El complemento transfiere proporciones agregadas de otros usos / usos térmicos del mismo vector. No es una predicción individual. Puede sobrestimar edificios con calefacción eléctrica; no calibra hábitos, ocupación, consumos comunes ni combustibles no presentes en el CEE.')
        digest=hashlib.sha256(json.dumps(manifest,sort_keys=True).encode()).hexdigest()
        with st.spinner('Calculando los escenarios del conjunto activo…'):
            summary,frames,reports=_cohorte(raw,base,complement,reduction,profile,ratio,digest)
        st.caption(f'{len(frames)} de {len(summary)} certificados con escenario calculado. Ninguno se convierte automáticamente en evaluación operacional.')
        if identity not in frames:
            st.error(reports.get(identity,{}).get('error','No hay un escenario para este registro'));return
        frame=frames[identity];report=reports[identity]
        area=report['superficie_escenario_m2'];cross=report['cruce_exploratorio']
        from informe_datos import resumir_crrem
        st.session_state['informe_crrem_resultado']=resumir_crrem(summary,frames,st.session_state['informe_crrem_config'])
        label='CEE + estructura IDAE (escenario)' if complement else 'Servicios CEE (escenario parcial)'
        st.subheader('CEE seleccionado · gráfica individual')
        dibujar(frame,cross,metrica,annual,area,label,False)
        dibujar_conjunto(frames,{key:value['superficie_escenario_m2'] for key,value in reports.items() if key in frames},metrica,annual,len(summary),identity)
        with st.expander('Comparación de los certificados del conjunto'):
            st.dataframe(summary.rename(columns={'certificado':'Certificado','eui_escenario':'EUI escenario (kWh/m²·año)',
                'ci_escenario':'Carbono escenario (kg CO₂/m²·año)','cruce_energia_exploratorio':'Cruce energético exploratorio',
                'cruce_carbono_exploratorio':'Cruce carbono exploratorio','MY_operacional':'Año CRREM operacional'}),hide_index=True,width='stretch')
        with st.expander('Reconstrucción por servicios y vectores'):
            st.dataframe(pd.DataFrame(report['estimacion']['detalle']),hide_index=True)
        with st.expander('Hipótesis, datos originales y trazabilidad'):
            st.write(report['estimacion']['advertencias'])
            st.json(report)
        st.download_button('Descargar tabla de escenarios del conjunto',exportar_csv(summary),'escenarios_CEE_NO_OPERACIONALES.csv','text/csv')
        st.download_button('Descargar proyección anual del certificado',exportar_csv(frame.reset_index()),identity+'_escenario_NO_OPERACIONAL.csv','text/csv')
        st.download_button('Descargar hipótesis y fuentes',json.dumps({'id':identity,'reporte':report,'fuentes':manifest},ensure_ascii=False,indent=2).encode(),identity+'_trazabilidad_escenario.json')
        return
    st.info('Este modo calcula EUI, carbono bruto/neto y ambos años de desalineamiento a partir de entradas completas y documentadas. El CEE no rellena automáticamente GIA ni facturas. No implica certificación por CRREM Foundation.')
    schema=plantilla(identity,tipo,base)
    st.download_button('Descargar plantilla de entradas sin valores inventados',json.dumps(schema,ensure_ascii=False,indent=2).encode(),identity+'_plantilla_operacional.json')
    cohort_hash=hashlib.sha256(raw.to_json().encode()).hexdigest()
    storage='crrem_entradas_'+cohort_hash
    if storage not in st.session_state:st.session_state[storage]={}
    entry=entrada_formulario(identity,tipo,base)
    if entry is not None:
        try:
            if entry.get('id')!=identity or entry.get('tipo')!=tipo or entry.get('anio')!=base:
                raise ValueError('Identificador, tipología o año no coinciden con la selección')
            frame,cross,provenance=evaluar(entry,reduction)
            st.session_state[storage][identity]=entry
        except (ValueError,KeyError,TypeError,OverflowError) as exc:
            st.error(f'No evaluable: {exc}');return
    else:
        entry=st.session_state[storage].get(identity)
        if entry is None:
            st.caption('Pendiente: ninguna entrada operacional completa para este certificado. El formulario no sustituye vacíos por cero.');return
        if entry['tipo']!=tipo or entry['anio']!=base:
            st.warning('La entrada guardada corresponde a otra tipología o año. Revisa la selección.');return
        try: frame,cross,provenance=evaluar(entry,reduction)
        except (ValueError,KeyError,TypeError) as exc:
            st.error(f'No evaluable: {exc}');return
    quality='A: consumos medidos, compatibilidad declarada' if entry['origen']=='medido' else 'B: consumos estimados documentados; resultado condicionado a la estimación'
    from informe_datos import resumir_crrem
    summary=pd.DataFrame([{'certificado':identity,'anio':entry['anio'],'origen':entry['origen'],
        'superficie_escenario_m2':entry['gia_m2'],'eui_escenario':float(frame.eui_kwh_m2_anio.iloc[0]),
        'ci_escenario':float(frame.ci_kg_m2_anio.iloc[0]),'cruce_energia_exploratorio':cross['energia'],
        'cruce_carbono_exploratorio':cross['carbono']}])
    st.session_state['informe_crrem_resultado']=resumir_crrem(summary,{identity:frame},st.session_state['informe_crrem_config'],operacional=True)
    st.write(quality)
    dibujar(frame,cross,metrica,annual,float(entry['gia_m2']),'Edificio (datos documentados)',True)
    st.dataframe(frame.reset_index(),hide_index=True,width='stretch')
    st.download_button('Descargar comparación energética y de carbono',exportar_csv(frame.reset_index()),identity+'_CRREM_documentado.csv','text/csv')
    st.download_button('Descargar entrada y trazabilidad',json.dumps({'entrada':entry,'reduccion':reduction,'cruce':cross,'factores':provenance,'fuentes':manifest},ensure_ascii=False,indent=2).encode(),identity+'_CRREM_trazabilidad.json')
