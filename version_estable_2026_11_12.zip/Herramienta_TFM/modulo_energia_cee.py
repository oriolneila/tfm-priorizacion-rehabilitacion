"""Diagnóstico PRE-CRREM sobre CEE madrileños.

No devuelve ni EUI operacional CRREM ni Misalignment Year.
Los vectores de los equipos son solamente proxy de reparto por servicios.
"""
import numpy as np
import pandas as pd

KNOWN_VECTORS = {
  'ElectricidadPeninsular':'electricidad', 'GasNatural':'gas_natural',
  'GasoleoC':'gasoleo_c', 'GLP':'glp', 'Carbon':'carbon'
}
SERVICIOS=[('calef','calefac_vector'),('refrig','refrig_vector'),('acs','acs_vector')]


def _num(s):
    s=s.astype('string').str.strip()
    # El fichero contiene tanto comas decimales como puntos decimales.
    tiene_coma=s.str.contains(',',regex=False,na=False)
    s=s.where(~tiene_coma,s.str.replace('.', '',regex=False).str.replace(',', '.',regex=False))
    return pd.to_numeric(s,errors='coerce').replace([np.inf,-np.inf],np.nan)


def diagnosticar(df:pd.DataFrame)->pd.DataFrame:
    """Diagnóstico: conserva todas las filas y explica por qué pasan/no pasan filtro."""
    d=df.copy()
    if 'final_global' in d.columns:
        names={'final_global':'CEE_final_global','final_calef':'CEE_final_calef',
               'final_refrig':'CEE_final_refrig','final_acs':'CEE_final_acs',
               'final_ilu':'CEE_final_ilu','edif_superf':'CEE_superficie'}
        if not all(c in d.columns for c in names):
            raise ValueError('Faltan columnas CEE fundamentales para energía final por servicio')
        for old,new in names.items():
            d[new]=_num(d[old])
        if 'edif_tipo' in d.columns and 'edif_tiporeg' in d.columns:
            d['tipo_objetivo']=(d['edif_tipo'].eq('BloqueDeViviendaCompleto') & d['edif_tiporeg'].eq('Edificio Existente'))
        else:
            d['tipo_objetivo']=False
        for name,vcol in SERVICIOS:
            vals=d['CEE_final_'+name]
            vec=d.get(vcol,pd.Series('',index=d.index)).fillna('').astype(str).str.strip()
            d['vector_'+name+'_reconocido'] = (vals.le(0) | vec.isin(KNOWN_VECTORS)) & vals.notna()
    elif {'energia_final_cee_kwh_m2_anio','cee_calef_kwh_m2_anio','cee_refrig_kwh_m2_anio','cee_acs_kwh_m2_anio'}.issubset(d.columns):
        aliases={'energia_final_cee_kwh_m2_anio':'CEE_final_global',
                 'cee_calef_kwh_m2_anio':'CEE_final_calef',
                 'cee_refrig_kwh_m2_anio':'CEE_final_refrig',
                 'cee_acs_kwh_m2_anio':'CEE_final_acs',
                 'cee_ilu_kwh_m2_anio':'CEE_final_ilu',
                 'superficie_habitable_cee_m2':'CEE_superficie'}
        for src,dest in aliases.items():
            if src in d.columns: d[dest]=_num(d[src])
            else: d[dest]=pd.NA
        # El formato depurado no constituye evidencia de haber sido filtrado.
        tipo=d.get('tipo',pd.Series('',index=d.index))
        clase=d.get('clase',pd.Series('',index=d.index))
        d['tipo_objetivo']=tipo.eq('BloqueDeViviendaCompleto') & clase.eq('Edificio Existente')
        for name,vcol in SERVICIOS:
            vals=d['CEE_final_'+name]
            vec=d.get(vcol,pd.Series('',index=d.index)).fillna('').astype(str).str.strip()
            d['vector_'+name+'_reconocido']=(vals.eq(0) | vec.isin(KNOWN_VECTORS)) & vals.notna()
    else:
        raise ValueError('CSV no reconocido. Sube el registro oficial (final_global...) o la base depurada de la auditoría.')
    d['cee_energia_valida']=d['CEE_final_global'].gt(0) & d['CEE_final_global'].lt(999999)
    d['cee_servicios_validos']=pd.Series(True,index=d.index)
    for name in ['calef','refrig','acs','ilu']:
        d['cee_servicios_validos'] &= d['CEE_final_'+name].ge(0) & d['CEE_final_'+name].lt(999999)
    d['cee_superficie_valida']=d['CEE_superficie'].between(25,100000,inclusive='both')
    d['cee_diferencia_suma']=d['CEE_final_global']-sum(d['CEE_final_'+name] for name in ['calef','refrig','acs','ilu'])
    tol=pd.concat([pd.Series(.2,index=d.index),d['CEE_final_global'].mul(.005)],axis=1).max(axis=1)
    d['cee_suma_coherente']=(d['cee_diferencia_suma'].abs()<=tol).fillna(False)
    d['cee_vector_activo_valido']=d[[f'vector_{name}_reconocido' for name,_ in SERVICIOS]].all(axis=1)
    d['candidato_precrrem']=d[['tipo_objetivo','cee_energia_valida','cee_servicios_validos','cee_superficie_valida','cee_suma_coherente','cee_vector_activo_valido']].fillna(False).all(axis=1)
    d['alerta_extremo_cee']=d['CEE_final_global'].lt(5) | d['CEE_final_global'].gt(1000)
    energia=d['CEE_final_global'].where(d['CEE_final_global'].ge(0) & np.isfinite(d['CEE_final_global']))
    area=d['CEE_superficie'].where(d['CEE_superficie'].gt(0) & np.isfinite(d['CEE_superficie']))
    d['cee_kwh_anio_servicios_certificados']=energia*area
    # Son consumos normalizados calculados según el CEE y NO consumos operacionales.
    d['eui_operacional_crrem']=pd.NA
    d['crrem_misalignment_year']=pd.NA
    d['calidad_interpretacion']='CEE (condiciones estandarizadas). NO evaluación CRREM.'
    return d


def resumen(d:pd.DataFrame)->dict:
    return {c:int(d[c].sum()) for c in ['tipo_objetivo','cee_energia_valida','cee_servicios_validos','cee_superficie_valida','cee_suma_coherente','cee_vector_activo_valido','candidato_precrrem','alerta_extremo_cee']}
