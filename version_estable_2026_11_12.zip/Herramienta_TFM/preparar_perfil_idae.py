"""Deriva cocientes de estructura de usos del IDAE; no calibra edificios."""
import io
import json
import zipfile
import hashlib
from pathlib import Path
import openpyxl
from crrem import ROOT


def preparar(source):
    blob=source.read_bytes()
    with zipfile.ZipFile(io.BytesIO(blob)) as archive:
        name=next(n for n in archive.namelist() if n.startswith('01 Consumo por uso y zona'))
        table=archive.read(name)
    book=openpyxl.load_workbook(io.BytesIO(table),read_only=True,data_only=True)
    rows=list(book['Export'].values);book.close()
    regulated={'Calefacción','Agua caliente','Refrigeración'}
    mapping={'Electricidad':'electricidad_red','Gas natural':'gas','Gasóleo':'gasoleo'}
    profiles={}
    for zone in sorted({r[0] for r in rows[1:] if r[0]}):
        profiles[zone]={}
        for fuel,carrier in mapping.items():
            used=[(i+1,r) for i,r in enumerate(rows) if r[0]==zone and r[2]==fuel]
            thermal=sum(float(r[3]) for i,r in used if r[1] in regulated)
            other=sum(float(r[3]) for i,r in used if r[1] not in regulated)
            profiles[zone][carrier]={'termicos_ktep':thermal,'otros_ktep':other,
                'cociente_otros_sobre_termicos':other/thermal if thermal>0 else None,
                'filas_export':[i for i,r in used]}
    report={'editor':'IDAE','estudio':'SPAHOUSEC III','publicacion':'enero 2026','referencia_estadistica':'2021',
            'url':'https://informesweb.idae.es/descargas/SPAHOUSEC%20III%20-%20Descargas.zip',
            'sha256_zip':hashlib.sha256(blob).hexdigest(),'tabla':name,'hoja':'Export',
            'sha256_tabla':hashlib.sha256(table).hexdigest(),
            'unidad_original':'ktep; los cocientes son adimensionales',
            'poblacion':'Hogares del ámbito SPAHOUSEC III; tipologías y usos agregados por zona, no edificios del piloto',
            'advertencia':'Transferencia de proporciones por vector al CEE como escenario de investigación; sin calibración operacional ni inferencia individual. No se imputan nuevos combustibles.',
            'perfiles':profiles}
    (ROOT/'fuentes/perfil_IDAE_SPAHOUSEC_III.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(profiles['Continental'],ensure_ascii=False,indent=2))


if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('zip_idae',type=Path)
    preparar(parser.parse_args().zip_idae)
