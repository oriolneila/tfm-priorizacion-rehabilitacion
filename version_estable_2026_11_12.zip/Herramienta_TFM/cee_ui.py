"""Diagnóstico recuperado de v0.3, sin convertir CEE a operacional."""
from pathlib import Path
import streamlit as st
import pandas as pd
from motor import cargar_archivo, exportar_csv
from modulo_energia_cee import diagnosticar, resumen


def mostrar_diagnostico(tabla):
    st.info("Energía calculada de los servicios certificados. Este diagnóstico revisa los datos del CEE; no estima consumos operacionales ni calcula el año CRREM.")
    try:
        datos=diagnosticar(tabla)
    except (ValueError,KeyError,TypeError) as exc:
        st.error(f"No se puede diagnosticar: {exc}"); return
    st.metric("Certificados cargados", len(datos))
    counts=resumen(datos)
    controles={'tipo_objetivo':'Bloque completo existente', 'cee_energia_valida':'Energía final dentro de los límites',
        'cee_servicios_validos':'Servicios con valores admisibles', 'cee_superficie_valida':'Superficie dentro de los límites',
        'cee_suma_coherente':'Suma de servicios coherente', 'cee_vector_activo_valido':'Vectores activos reconocidos',
        'candidato_precrrem':'Cumple todos los controles exploratorios', 'alerta_extremo_cee':'Valores energéticos extremos por revisar'}
    st.subheader('Comprobaciones del certificado')
    st.caption('Cada fila cuenta los certificados que cumplen la condición indicada; la última identifica alertas.')
    st.dataframe(pd.DataFrame({'Comprobación':[controles[c] for c in counts],'Certificados':list(counts.values())}),hide_index=True,width='stretch')
    st.caption("Los límites 25–100.000 m², 999.999 y tolerancia max(0,2; 0,5 %) son reglas exploratorias heredadas; no son umbrales oficiales CRREM. No se considera verificado el vector por el simple formato del CSV. Una suma coherente tampoco acredita la validez del certificado.")
    columns=[c for c in ['id','id_analisis','municipio','edif_muni','CEE_superficie','CEE_final_global','CEE_final_calef','CEE_final_refrig','CEE_final_acs','CEE_final_ilu','cee_diferencia_suma','cee_kwh_anio_servicios_certificados','tipo_objetivo','cee_vector_activo_valido','candidato_precrrem','alerta_extremo_cee','calidad_interpretacion'] if c in datos]
    st.subheader('Detalle de los certificados')
    etiquetas={'id':'Certificado','id_analisis':'Identificador de análisis','municipio':'Municipio','edif_muni':'Código municipal',
        'CEE_superficie':'Superficie CEE (m²)','CEE_final_global':'Energía final CEE (kWh/m²·año)',
        'CEE_final_calef':'Calefacción (kWh/m²·año)','CEE_final_refrig':'Refrigeración (kWh/m²·año)',
        'CEE_final_acs':'ACS (kWh/m²·año)','CEE_final_ilu':'Iluminación (kWh/m²·año)',
        'cee_diferencia_suma':'Diferencia de la suma (kWh/m²·año)',
        'cee_kwh_anio_servicios_certificados':'Servicios CEE (kWh/año calculados)',
        'tipo_objetivo':'Bloque completo existente','cee_vector_activo_valido':'Vectores reconocidos',
        'candidato_precrrem':'Cumple controles exploratorios','alerta_extremo_cee':'Alerta de valor extremo',
        'calidad_interpretacion':'Alcance de interpretación'}
    st.dataframe(datos[columns],hide_index=True,width='stretch',column_config=etiquetas)
    st.download_button("Descargar diagnóstico sin identificadores directos",exportar_csv(datos[columns]),'diagnostico_CEE_no_operacional.csv','text/csv')
    st.warning("Pasar los controles CEE no acredita consumo operacional. Los vectores declarados son de los sistemas; no validan un reparto completo de consumos por vector. EUI operacional y año CRREM permanecen vacíos.")
