"""Único control añadido: descarga diferida, sin alterar cálculos ni entradas."""
from functools import partial
from copy import deepcopy
import hashlib
import streamlit as st
from informe_datos import firma


def _generar(**kwargs):
    from informe_pdf import generar_pdf
    return generar_pdf(**kwargs)


def boton_informe(raw,nombre,huella,ranking=None,destino=None):
    from incidencias import historial
    config=st.session_state.get('informe_crrem_config')
    if config and config.get('firma')!=firma(raw):config=None
    result=st.session_state.get('informe_crrem_resultado')
    if not config or not result or result.get('config')!=config:result=None
    config={'config':deepcopy(config or {}),'resultado':deepcopy(result)}
    # La función diferida no lee session_state ni ejecuta comandos de Streamlit.
    data=partial(_generar,raw=raw.copy(deep=True),nombre=nombre,huella=huella,ranking=deepcopy(ranking),
        crrem=config,enlaces=deepcopy(st.session_state.get('social_actual',[])),revisiones=historial(huella))
    target=destino if destino is not None else st.sidebar
    target.download_button('Exportar informe (PDF)',data=data,file_name='Informe_rehabilitacion_sostenible.pdf',
        mime='application/pdf',on_click='ignore',key='exportar_informe_pdf',
        width='stretch',type='primary',
        help='En el ranking respeta filtros y pesos actuales; en los demás módulos resume el conjunto completo. Incluye los resultados CRREM ya calculados en esta sesión. No modifica los datos.')
