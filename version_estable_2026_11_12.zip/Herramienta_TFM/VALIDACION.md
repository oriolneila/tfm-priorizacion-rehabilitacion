# Verificación del piloto con 15 CEE reales

25/10/2026, revisión con importación masiva: **74 pruebas superadas**, sin fallos ni omisiones, en 30,29 segundos. Python 3.12.14 y pytest 9.1.1. Informe legible por herramientas en datos_piloto/pruebas.xml. Incluye persistencia y recuperación de revisiones entre sesiones, reversión, aislamiento entre conjuntos, formularios, cotas, CSV/ZIP de la cohorte externa y registro completo con códigos repetidos. Las decisiones simuladas se guardan en bases temporales; no se han resuelto ficticiamente los casos reales. La revisión anterior de incidencias había superado 72 pruebas, la social 62 y la del cálculo CRREM 55.

Se recalculan los cuatro ejemplos oficiales CRREM v1.1 y su agregado desde sus entradas y factores: coinciden exactamente los diez años de desalineamiento y las intensidades cumplen las tolerancias publicadas. El error máximo frente a las curvas de carbono redondeadas es menor de 0,001 kg/m²·año. Esto contrasta la aritmética y el método, no la procedencia de consumos de Madrid ni la calibración del estimador. Ver datos_piloto/validacion_referencias_CRREM.json y CRREM_IMPLEMENTACION.md.

La suite conserva las regresiones del motor, unidades, CRREM y diagnóstico CEE. Añade pruebas de los 15 certificados reales: procedencia, fecha y tipología, correspondencia campo a campo con el ZIP oficial, ambos modos de ranking, ausencia de renta y de resultados operacionales, y exportación/recarga. Las entradas artificiales de regresión se mantienen aisladas en tests; no se incorporan al conjunto del estudio.

Streamlit AppTest comprobó el arranque con 15 filas, modo anual, proyecciones energéticas y de carbono de los escenarios CEE, complemento IDAE opcional, formulario operacional sin imputar vacíos, diagnóstico CEE, rechazo de pesos mayores de 100 % y bloqueo del escenario social sin renta. No se ha probado el flujo completo con datos operacionales reales de los 15 edificios porque no se dispone de ellos.

Se revisaron además en el navegador local el ranking por m²/anual, el diagnóstico y las curvas oficiales con el estado insuficiente de los CEE. Durante la actualización en caliente apareció una versión de un módulo en memoria; se reinició el servicio y se verificó su carga corregida. Las capturas del piloto documentan el resultado.

La ejecución de 74 pruebas produjo doce avisos de deprecación internos del gráfico de Streamlit al usar pandas. No produjeron fallos de cálculo. Se mantienen las versiones congeladas en requirements-lock.txt.

La ejecución de las pruebas no valida físicamente los certificados, el estimador CEE-operacional ni la utilidad del ranking para decisiones reales. La guía docente y la auditoría completa previa siguen pendientes. Las 18 pruebas originales de v0.3 se habían ejecutado con éxito antes de retirar su ejemplo de uso.
# Ampliación: gráfica conjunta

## Ampliación posterior: dimensión social INE

62 pruebas superadas al integrar la dimensión social: enlace original auditado, reproducción de las 15 consultas sin red, integridad de respuestas, unión por identificador al reordenar datos, rechazo de secciones ambiguas, exclusión de dos direcciones no conciliadas y tratamiento opcional de la cota INE. La interfaz muestra 12 rentas utilizables por defecto y 13 al activar cotas; el ranking social funciona con datos reales del entorno y mantiene ausentes los casos no utilizables. Se mantienen avisos de deprecación internos de Streamlit/pandas. Esto no valida la renta de residentes ni las dos localizaciones pendientes. DIMENSION_SOCIAL.md documenta fuente, año, límites y reproducción.

14 pruebas específicas de interfaz y piloto real superadas tras añadir la comparación conjunta. Incluyen renderizado en anual y carbono, presencia de los 15 CEE, 26 años por certificado y conversión de valores y umbrales por la superficie individual. La trayectoria por m² es común; los umbrales anuales conservan las diferencias de tamaño. Las restantes pruebas de cálculo no se han repetido en esta ampliación visual.

