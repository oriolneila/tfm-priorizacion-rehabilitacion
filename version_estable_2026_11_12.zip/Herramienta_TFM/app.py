"""Interfaz del MVP para el TFM de rehabilitación sostenible."""
import streamlit as st
import pandas as pd
from pathlib import Path
from motor import cargar_archivo, normalizar, calidad, calcular_escenarios, resumen_calidad, exportar_csv

st.set_page_config(page_title="Rehabilitación sostenible | Análisis", page_icon=":material/apartment:", layout="wide")
from apariencia import iniciar, cabecera, grafica, controles_legibles
if not st.session_state.get('acceso_abierto',False):
    iniciar(marca_lateral=False)
    from acceso import mostrar_acceso
    mostrar_acceso()
    st.stop()
iniciar()
from datos_ui import restaurar_datos
restaurar_datos()
etiquetas_menu={'Inicio':'Inicio','Ranking exploratorio':'Prioridades',
    'Diagnóstico energético CEE / pre-CRREM':'Diagnóstico CEE','Alineamiento CRREM':'Trayectorias CRREM',
    'Entorno social · INE':'Entorno social','Resolver incidencias':'Incidencias'}
modulo=st.sidebar.selectbox("Sección",list(etiquetas_menu),format_func=etiquetas_menu.get,key='navegacion_principal')
if modulo == 'Inicio':
    from portada import mostrar_portada
    mostrar_portada()
    st.stop()
cabecera(modulo)
espacio_informe=st.sidebar.container()
from datos_ui import cargar_datos
raw, nombre_datos, huella_datos = cargar_datos()
from informe_ui import boton_informe
if modulo == 'Resolver incidencias':
    from incidencias_ui import mostrar_incidencias
    mostrar_incidencias(raw)
    boton_informe(raw,nombre_datos,huella_datos,destino=espacio_informe)
    st.stop()
if modulo == 'Entorno social · INE':
    from social_ui import mostrar_social
    mostrar_social(raw)
    boton_informe(raw,nombre_datos,huella_datos,destino=espacio_informe)
    st.stop()
if modulo == "Diagnóstico energético CEE / pre-CRREM":
    from cee_ui import mostrar_diagnostico
    mostrar_diagnostico(raw)
    boton_informe(raw,nombre_datos,huella_datos,destino=espacio_informe)
    st.stop()
if modulo == "Alineamiento CRREM":
    from crrem_ui import mostrar_crrem
    mostrar_crrem(raw)
    boton_informe(raw,nombre_datos,huella_datos,destino=espacio_informe)
    st.stop()

try:
    data, matched = normalizar(raw)
    flags = calidad(data)
except Exception as exc:
    st.error(f"Error al interpretar los datos: {exc}")
    st.stop()

st.sidebar.markdown('<div class="lateral-etiqueta">COMPARACIÓN</div>',unsafe_allow_html=True)
modo = st.sidebar.radio("Magnitud para priorizar", ["superficie", "anual"],
                        format_func=lambda x: "Por m²" if x == "superficie" else "Total anual",horizontal=True,
                        help="El total anual se calcula como intensidad CEE × superficie del certificado. No equivale a consumo medido ni a ahorro potencial.")
filtros_ui=st.sidebar.expander("Filtrar certificados",expanded=False)
mun = sorted(flags["municipio"].dropna().unique().tolist())
sel = filtros_ui.multiselect("Municipios (vacío = todos)", mun, default=[]) if len(mun) > 1 else []
fil = flags[flags["municipio"].isin(sel)].copy() if sel else flags.copy()
# Selección explícita de tipologías; nunca asumimos "edificio completo" por defecto.
tipos = sorted(flags["tipo_certificado"].dropna().unique().tolist())
sel_tipos = filtros_ui.multiselect("Tipo certificado (vacío = todos; revisar manualmente)", tipos, default=[])
if sel_tipos:
    fil = fil[fil["tipo_certificado"].isin(sel_tipos)].copy()
# No se infiere que un certificado de parte del edificio sea un edificio completo.
exclude_duplicates = filtros_ui.checkbox("Apartar referencias catastrales repetidas", value=False)
if exclude_duplicates:
    fil = fil[~fil["alerta_refcat_repetida"]].copy()
exclude_multiref = filtros_ui.checkbox("Apartar certificados con varias referencias", value=False)
if exclude_multiref:
    fil = fil[~fil["alerta_refcat_multiple"]].copy()
exclude_missing_type = filtros_ui.checkbox("Apartar registros sin tipo de inmueble", value=False)
if exclude_missing_type:
    fil = fil[~fil["alerta_tipo"]].copy()

if sel or sel_tipos or exclude_duplicates or exclude_multiref or exclude_missing_type:
    st.sidebar.caption(f'Filtros activos · {len(fil):,} de {len(flags):,} certificados'.replace(',','.'))
pesos_ui=st.sidebar.expander("Pesos del escenario social",expanded=False)
pesos_ui.caption("Solo modifican el criterio con entorno social. Deben sumar 100 % y requieren una justificación metodológica.")
w_e = pesos_ui.slider("Energía (%)", 0, 100, 50)
w_c = pesos_ui.slider("Emisiones CEE (%)", 0, 100, 30)
w_s = 100 - w_e - w_c
if w_s < 0:
    st.sidebar.error("Energía + emisiones no puede superar el 100 %.")
    st.stop()
pesos_ui.markdown(f"**Entorno social: {w_s} %**")
if (w_e,w_c)!=(50,30):st.sidebar.caption(f'Pesos personalizados · {w_e} / {w_c} / {w_s} %')
res = calcular_escenarios(fil, pesos=(w_e/100, w_c/100, w_s/100), modo=modo)
res['archivo_fuente']=nombre_datos
res['sha256_archivo_fuente']=huella_datos
import hashlib,json
res['sha256_enlaces_sociales']=hashlib.sha256(json.dumps(st.session_state.get('social_actual',[]),ensure_ascii=False,sort_keys=True).encode()).hexdigest()
res['pesos_energia_emisiones_social']=f'{w_e};{w_c};{w_s}'
if res.empty:
    st.warning("No quedan registros con los filtros actuales.")
    boton_informe(raw,nombre_datos,huella_datos,{'indices':list(res.index),'pesos':(w_e/100,w_c/100,w_s/100),'modo':modo,'filtros':'Selección vacía con los filtros actuales'},destino=espacio_informe)
    st.stop()

st.subheader("Resumen del conjunto")
col1, col2, col3, col4 = st.columns(4)
col1.metric("Registros cargados", f"{len(raw):,}".replace(",", "."))
col2.metric("Registros incluidos", f"{len(res):,}".replace(",", "."))
col3.metric("Con EPNR válida", f"{res['epnren'].ge(0).sum():,}".replace(",", "."))
col4.metric("Con renta territorial", f"{res['renta_territorial'].gt(0).sum():,}".replace(",", "."))
st.caption("**Unidad de análisis pendiente de verificar:** cada fila puede ser un edificio, una parte o una vivienda; la referencia catastral por sí sola no resuelve esa diferencia.")

prioridades, calidad_datos, comparaciones, exportacion = st.tabs(["Prioridades", "Calidad de datos", "Comparación de rankings", "Exportación"])
with prioridades:
    st.subheader("Prioridad relativa de los certificados")
    st.caption('Emisiones calculadas del CEE, no alineamiento CRREM. Los pesos son exploratorios; energía y emisiones pueden estar correlacionadas. La renta describe el entorno censal, no los hogares.')
    cols = {"escenario_1_energia": "Energía", "escenario_2_energia_emisiones": "Energía + CO₂ CEE", "escenario_3_con_contexto_social": "Energía + CO₂ CEE + entorno social"}
    selected = st.selectbox("Escenario para ordenar", list(cols), format_func=lambda x: cols[x])
    with st.expander("Cómo se construyen los tres escenarios"):
        st.write("**Escenario 1:** solo energía primaria no renovable del certificado. **Escenario 2:** 60 % energía y 40 % emisiones CEE. **Escenario 3:** los pesos de energía, emisiones y entorno social que has elegido en el panel lateral. Una menor renta implica una mayor puntuación social relativa.")
        st.caption('Revisa direcciones, año, notas y exclusiones en «Entorno social · INE». Las puntuaciones sociales comparan solo certificados con datos utilizables.')
    if res[selected].notna().sum() == 0:
        st.warning("No se puede calcular este escenario: faltan campos obligatorios o algún peso requiere indicadores ausentes.")
    else:
        visible = res.sort_values(selected, ascending=False, na_position="last")
        etiquetas={'id_visual':'Certificado','municipio':'Municipio','tipo_certificado':'Tipo CEE',
               'epnren':'EPNR (kWh/m²·año)','emisiones':'Emisiones CEE (kg/m²·año)',
               'energia_final':'Energía final CEE (kWh/m²·año)','epnren_anual_cee':'EPNR anual (kWh/año)',
               'emisiones_anual_cee':'Emisiones CEE anuales (kg/año)',
               'energia_final_anual_cee':'Energía final CEE anual (kWh/año)',
               'renta_territorial':'Renta territorial (€/persona)','calidad_dato':'Calidad',
               selected:'Puntuación relativa','puesto_'+selected:'Puesto'}
        energy_col='epnren' if modo=='superficie' else 'epnren_anual_cee'
        carbon_col='emisiones' if modo=='superficie' else 'emisiones_anual_cee'
        display=['puesto_'+selected,'id_visual','municipio',energy_col,carbon_col,'renta_territorial',selected]
        tabla_visible=visible[display].rename(columns=etiquetas)
        st.dataframe(tabla_visible.head(1000),hide_index=True,width='stretch',height=420,column_config={
            'Puntuación relativa':st.column_config.ProgressColumn('Puntuación relativa',min_value=0,max_value=100,format='%.1f'),
            etiquetas[energy_col]:st.column_config.NumberColumn(format='%.2f'),
            etiquetas[carbon_col]:st.column_config.NumberColumn(format='%.2f'),
            'Renta territorial (€/persona)':st.column_config.NumberColumn(format='%.2f'),
        })
        if len(tabla_visible)>1000:st.caption('Vista previa de los primeros 1.000 registros ordenados. El cálculo y la descarga incluyen todos los registros del conjunto filtrado.')
        graph=visible.head(20).dropna(subset=[selected])[['id_visual',selected]].rename(columns={'id_visual':'Certificado',selected:'Puntuación'})
        if not graph.empty:
            import altair as alt
            st.subheader('Los 20 primeros certificados')
            chart=alt.Chart(graph).mark_bar(color='#31765A',cornerRadiusEnd=4,size=12).encode(
                x=alt.X('Puntuación:Q',scale=alt.Scale(domain=[0,100]),title='Puntuación relativa · 0–100'),
                y=alt.Y('Certificado:N',sort='-x',title=None),
                tooltip=['Certificado:N',alt.Tooltip('Puntuación:Q',format='.2f')]
            ).properties(height=400)
            st.altair_chart(grafica(chart),width='stretch')
        with st.expander('Todos los indicadores del conjunto ordenado'):
            detalle=['id_visual','municipio','tipo_certificado','epnren','emisiones','energia_final','epnren_anual_cee','emisiones_anual_cee','energia_final_anual_cee','calidad_dato','renta_territorial',selected,'puesto_'+selected]
            st.dataframe(visible[detalle].rename(columns=etiquetas).head(1000).style.format(precision=2,na_rep='Sin dato'),hide_index=True,width='stretch')

with calidad_datos:
    st.subheader('Cobertura y calidad de los datos')
    st.caption('Los controles identifican datos que revisar. Superarlos no acredita la validez física del certificado ni un consumo operacional.')
    a,b=st.columns(2)
    with a:
        st.write('**Archivo completo · antes de filtros**')
        st.dataframe(controles_legibles(resumen_calidad(flags)),hide_index=True,width='stretch')
    with b:
        st.write('**Conjunto incluido · después de filtros**')
        st.dataframe(controles_legibles(resumen_calidad(res)),hide_index=True,width='stretch')
    with st.expander("Revisar filas e incidencias"):
        st.dataframe(res[["id_visual", "referencia", "municipio", "tipo_certificado", "numero_alertas", "alerta_epnren", "alerta_emisiones", "alerta_refcat_repetida", "alerta_refcat_multiple", "alerta_renta"]].head(1000), hide_index=True)

with comparaciones:
    st.subheader("Cambios entre rankings")
    otro = calcular_escenarios(fil, pesos=(w_e/100,w_c/100,w_s/100), modo="anual" if modo == "superficie" else "superficie")
    st.write("Comparación por m² frente a total anual, con los mismos filtros:")
    comparacion=pd.DataFrame({"registro":res["id_visual"], "puesto_modo_actual":res["puesto_"+selected], "puesto_otro_modo":otro["puesto_"+selected]})
    comparacion["variacion_a_favor_modo_actual"]=comparacion["puesto_otro_modo"]-comparacion["puesto_modo_actual"]
    st.dataframe(comparacion.head(1000).rename(columns={'registro':'Certificado','puesto_modo_actual':'Puesto · magnitud actual','puesto_otro_modo':'Puesto · otra magnitud','variacion_a_favor_modo_actual':'Cambio a favor del modo actual'}),hide_index=True,width='stretch')
    st.caption("Variación positiva: mayor prioridad en el modo actual. La cohorte filtrada es la misma, pero las filas con indicadores disponibles pueden diferir: el total anual exige superficie. Los valores ausentes no se sustituyen por cero.")
    if res["escenario_1_energia"].notna().sum() and res["escenario_2_energia_emisiones"].notna().sum():
        rank_cols = ["id_visual", "puesto_escenario_1_energia", "puesto_escenario_2_energia_emisiones", "puesto_escenario_3_con_contexto_social"]
        rank_view = res[rank_cols].copy()
        rank_view["cambio_S1_a_S2"] = rank_view["puesto_escenario_1_energia"] - rank_view["puesto_escenario_2_energia_emisiones"]
        rank_view["cambio_S1_a_S3"] = rank_view["puesto_escenario_1_energia"] - rank_view["puesto_escenario_3_con_contexto_social"]
        st.subheader('Comparación de los tres criterios')
        st.dataframe(rank_view.head(1000).rename(columns={'id_visual':'Certificado','puesto_escenario_1_energia':'Puesto · Energía','puesto_escenario_2_energia_emisiones':'Puesto · Energía y emisiones','puesto_escenario_3_con_contexto_social':'Puesto · Con entorno social','cambio_S1_a_S2':'Cambio · S1 a S2','cambio_S1_a_S3':'Cambio · S1 a S3'}), hide_index=True, width='stretch')
        st.caption("Cambio positivo = sube hacia las primeras posiciones. Si falta un indicador, el puesto queda vacío; no se sustituye por cero.")

with exportacion:
    st.subheader("Resultados y trazabilidad")
    st.write('Descarga el conjunto filtrado completo con sus indicadores, puntuaciones, estados de calidad y procedencia.')
    st.download_button("Descargar resultados completos (CSV)", data=exportar_csv(res), file_name="tfm_ranking_exploratorio.csv", mime="text/csv",type='primary')
    with st.expander('Equivalencia de campos y columnas originales'):
        st.dataframe(pd.DataFrame([{"Campo de análisis": k, "Columna del archivo": v} for k,v in matched.items()]),hide_index=True,width='stretch')
        st.write('Columnas leídas:',list(raw.columns))
    st.caption("Las puntuaciones son posiciones relativas dentro del conjunto analizado: cambiar la muestra puede cambiar el ranking. No existe una validación externa de las prioridades ni una evaluación operacional CRREM de estos CEE.")

boton_informe(raw,nombre_datos,huella_datos,{'indices':list(res.index),'pesos':(w_e/100,w_c/100,w_s/100),
    'modo':modo,'escenario':selected,'filtros':{'municipios':sel,'tipos':sel_tipos,
    'apartar_referencias_repetidas':exclude_duplicates,'apartar_multirreferencia':exclude_multiref,
    'apartar_sin_tipo':exclude_missing_type}},destino=espacio_informe)
