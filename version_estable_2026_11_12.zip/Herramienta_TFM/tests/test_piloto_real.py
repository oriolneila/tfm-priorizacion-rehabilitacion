"""Regresiones sobre los 15 CEE reales, sin valores inventados del estudio."""
from pathlib import Path
import json
import hashlib
import pandas as pd
import pytest
from motor import cargar_archivo, normalizar, calidad, calcular_escenarios, exportar_csv
from modulo_energia_cee import diagnosticar

ROOT=Path(__file__).parents[1]


def muestra():
    path=ROOT/'datos_piloto/CEE_Madrid_15_reales.csv'
    return cargar_archivo(path.name,path.read_bytes())


@pytest.mark.parametrize('metrica',['energia','carbono'])
def test_grafica_conjunta_conserva_quince_cee_y_umbrales_por_superficie(metrica):
    from reconstruccion_cee import evaluar_cohorte
    from crrem_panel import datos_conjuntos
    _,frames,reports=evaluar_cohorte(muestra(),complementar=False)
    areas={key:reports[key]['superficie_escenario_m2'] for key in frames}
    intensidades=datos_conjuntos(frames,areas,metrica,False)
    anuales=datos_conjuntos(frames,areas,metrica,True)
    assert intensidades.Certificado.nunique()==15
    assert intensidades.groupby('Certificado').size().eq(26).all()
    assert intensidades.groupby('Año')['Umbral CRREM'].nunique().eq(1).all()
    assert anuales.groupby('Año')['Umbral CRREM'].nunique().gt(1).all()
    for column in ['Valor','Umbral CRREM']:
        assert anuales[column].tolist()==pytest.approx((intensidades[column]*intensidades['Superficie (m²)']).tolist())


def test_quince_reales_procedencia_y_periodo():
    d=muestra()
    meta=json.loads((ROOT/'datos_piloto/seleccion_y_procedencia.json').read_text(encoding='utf-8'))
    assert len(d)==15
    assert d.id.nunique()==15
    assert pd.to_datetime(d.edif_fecha,format='%d/%m/%Y').dt.year.eq(2025).all()
    assert d.edif_muni.str.upper().eq('MADRID').all()
    assert d.edif_tipo.eq('BloqueDeViviendaCompleto').all()
    assert meta['sha256_muestra']==hashlib.sha256((ROOT/'datos_piloto/CEE_Madrid_15_reales.csv').read_bytes()).hexdigest()
    assert len(meta['filas'])==15
    assert not (ROOT/'ejemplo_SINTETICO.csv').exists()


@pytest.mark.parametrize('modo',['superficie','anual'])
def test_escenarios_reales_y_social_no_inventado(modo):
    n,_=normalizar(muestra())
    out=calcular_escenarios(calidad(n),modo=modo)
    assert out.escenario_1_energia.notna().sum()==15
    assert out.escenario_2_energia_emisiones.notna().sum()==15
    assert out.escenario_3_con_contexto_social.isna().all()
    assert out.renta_territorial.isna().all()
    assert out.epnren_anual_cee.tolist()==pytest.approx((out.epnren*out.superficie_m2).tolist())


def test_diagnostico_real_y_bloqueo_operacional():
    d=diagnosticar(muestra())
    assert d.candidato_precrrem.sum()==15
    assert d.eui_operacional_crrem.isna().all()
    assert d.crrem_misalignment_year.isna().all()


def test_exportar_recargar_sin_cambiar_valores():
    n,_=normalizar(muestra())
    out=calcular_escenarios(calidad(n))
    back=cargar_archivo('resultados.csv',exportar_csv(out))
    assert back.id_visual.tolist()==out.id_visual.tolist()
    assert len(back)==15
    values=pd.to_numeric(back.epnren_anual_cee.str.replace(',','.',regex=False))
    assert values.tolist()==pytest.approx(out.epnren_anual_cee.tolist())


def test_trazabilidad_con_fuente_original_si_disponible():
    from preparar_piloto_real import EXPECTED
    source=ROOT.parent/'datos_originales/registro_certificados_eficiencia_energetica_2025.zip'
    if not source.exists():
        pytest.skip('ZIP fuente no presente; proporcionar para comprobación completa')
    assert hashlib.sha256(source.read_bytes()).hexdigest()==EXPECTED
    original=cargar_archivo(source.name,source.read_bytes())
    d=muestra()
    meta=json.loads((ROOT/'datos_piloto/seleccion_y_procedencia.json').read_text(encoding='utf-8'))
    for i,record in enumerate(meta['filas']):
        row=original.iloc[record['fila_logica_csv']-1]
        assert hashlib.sha256(json.dumps(row.to_dict(),ensure_ascii=False,sort_keys=True).encode()).hexdigest()==record['sha256_fila_original']
        for col in d:
            if col in original:
                assert d.iloc[i][col]==row[col]
