import sqlite3
import pytest
import conjunto_guardado as store


def test_recupera_en_otra_conexion_y_retira(tmp_path,monkeypatch):
    monkeypatch.setattr(store,'DB',tmp_path/'archivo.sqlite3')
    assert store.recuperar() is None
    store.guardar('prueba.csv',b'id;energia\na;12\n')
    assert store.recuperar()==('prueba.csv',b'id;energia\na;12\n')
    store.guardar('otro.zip',b'contenido de prueba aislada')
    assert store.recuperar()[0]=='otro.zip'
    store.retirar()
    assert store.recuperar() is None


def test_detecta_copia_alterada(tmp_path,monkeypatch):
    monkeypatch.setattr(store,'DB',tmp_path/'archivo.sqlite3')
    store.guardar('prueba.csv',b'datos')
    with sqlite3.connect(store.DB) as db:db.execute("UPDATE activo SET contenido=?",(b'alterados',))
    with pytest.raises(ValueError,match='huella'):store.recuperar()
