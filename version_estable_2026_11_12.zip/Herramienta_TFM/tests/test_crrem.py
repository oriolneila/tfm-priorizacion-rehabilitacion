import numpy as np
import pandas as pd
import pytest
from crrem import trayectoria, primer_cruce, evaluar_energia, VECTORES, TIPOS
from motor import normalizar, calidad, calcular_escenarios


@pytest.mark.parametrize("tipo", TIPOS)
@pytest.mark.parametrize("metrica", ["energia", "carbono"])
def test_fuentes_oficiales_completas(tipo, metrica):
    curve = trayectoria(tipo, metrica)
    assert list(curve.index) == list(range(2020, 2051))
    assert np.isfinite(curve).all()


def test_valores_celdas_espana():
    assert trayectoria(TIPOS[1], "energia")[2025] == pytest.approx(74.8876217803633)
    assert trayectoria(TIPOS[1], "carbono")[2030] == pytest.approx(6.01932155854557)


def test_cruce_estricto_y_horizonte():
    s = pd.Series(10., index=range(2025,2051))
    assert primer_cruce(s, s, 2025) is None
    assert primer_cruce(s+1, s, 2025) == 2025
    with pytest.raises(ValueError):
        primer_cruce(s.drop(2030), s, 2025)
    s.loc[2030] = np.inf
    with pytest.raises(ValueError):
        primer_cruce(s, s, 2025)


def entrada():
    return dict(origen="medido", justificacion="PRUEBA SINTETICA", perimetro_completo=True,
                gia_verificada=True, cobertura_completa=True, ocupacion_completa=True, meses=12,
                gia_m2=100, consumos_kwh={k: 1000 for k in VECTORES})


def test_energia_y_anual():
    frame, cross = evaluar_energia(entrada(), TIPOS[1], 2025)
    assert frame.iloc[0,1] == 80
    assert frame.iloc[0,2] == 8000
    assert cross == 2025


@pytest.mark.parametrize("key,value", [("origen","CEE"),("meses",11),("gia_m2",0),
    ("cobertura_completa",False),("justificacion",""),("ocupacion_completa",False)])
def test_bloqueo_insuficientes(key,value):
    item=entrada(); item[key]=value
    with pytest.raises(ValueError):
        evaluar_energia(item,TIPOS[1],2025)


def test_vector_ausente_y_exportaciones():
    item=entrada(); item['consumos_kwh'].pop('gas')
    with pytest.raises(ValueError):
        evaluar_energia(item,TIPOS[1],2025)
    item=entrada(); item['consumos_kwh']['exportacion']=500
    with pytest.raises(ValueError):
        evaluar_energia(item,TIPOS[1],2025)


def test_inversion_ranking_y_area_ausente():
    n,_=normalizar(pd.DataFrame({'norenov_global':[200,100,300], 'edif_superf':[50,500,None]}))
    q=calidad(n)
    rel=calcular_escenarios(q)
    total=calcular_escenarios(q,modo='anual')
    assert rel.loc[0,'punt_energia'] > rel.loc[1,'punt_energia']
    assert total.loc[0,'punt_energia'] < total.loc[1,'punt_energia']
    assert pd.isna(total.loc[2,'punt_energia'])
    assert total.loc[0,'epnren_anual_cee']==10000


def test_inf_y_pesos_nan():
    n,_=normalizar(pd.DataFrame({'norenov_global':['inf']}))
    assert calidad(n).loc[0,'alerta_epnren']
    with pytest.raises(ValueError):
        calcular_escenarios(calidad(n),pesos=(np.nan,0,1))
