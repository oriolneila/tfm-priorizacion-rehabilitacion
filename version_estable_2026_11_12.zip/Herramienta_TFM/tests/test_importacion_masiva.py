"""Regresiones de importación sobre la cohorte externa; no precarga datos en la app."""
from pathlib import Path
import json
import zipfile
import pandas as pd
import pytest
from motor import cargar_archivo,normalizar,calidad,calcular_escenarios
from social import enlaces_importados,aplicar_enlaces
from incidencias import completar_bases

CASE=Path(__file__).resolve().parents[3]/'caso_estudio_2026_10_25'
pytestmark=pytest.mark.skipif(not (CASE/'entradas/cohorte_bloques_2025_social.csv').exists(),reason='El estudio externo no está instalado junto a la aplicación')


def test_csv_y_zip_reproducen_misma_cohorte_y_notas():
    inputs=CASE/'entradas'
    csv=cargar_archivo('cohorte.csv',(inputs/'cohorte_bloques_2025_social.csv').read_bytes())
    zipped=cargar_archivo('cohorte.zip',(inputs/'cohorte_bloques_2025_social.zip').read_bytes())
    pd.testing.assert_frame_equal(csv,zipped)
    meta=json.loads((CASE/'auditoria/seleccion.json').read_text(encoding='utf8'))
    assert len(csv)==meta['flujo'][-1]['n']
    links=enlaces_importados(csv)
    assert len(links)==len(csv)
    n,_=normalizar(aplicar_enlaces(csv,links))
    report=json.loads((CASE/'resultados/resumen.json').read_text(encoding='utf8'))
    assert n.renta_territorial.notna().sum()==report['con_renta']
    bounds,_=normalizar(aplicar_enlaces(csv,links,usar_cotas=True))
    assert bounds.renta_territorial.notna().sum()==report['con_renta']+report['cotas_ine']
    assert n.id_visual.is_unique
    assert not csv.parcela.duplicated().any()


def test_registro_original_con_ids_repetidos_no_bloquea_importacion_sin_revisiones():
    source=CASE.parent/'publicacion/datos_originales/registro_certificados_eficiencia_energetica_2025.zip'
    d=cargar_archivo(source.name,source.read_bytes())
    assert len(d)==json.loads((CASE/'auditoria/seleccion.json').read_text(encoding='utf8'))['filas_fuente']
    assert completar_bases(d,[],[])==[]
    n,_=normalizar(d)
    assert n.id_visual.is_unique
