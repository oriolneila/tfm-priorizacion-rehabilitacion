import json
import numpy as np
import pandas as pd
import pytest
from crrem import ROOT,TIPOS
from crrem_operacional import CARRIERS,proyectar,comparar,factores_espana,evaluar,numero,serie
from validar_referencias_crrem import validar
from reconstruccion_cee import reconstruir,evaluar_cohorte
from motor import cargar_archivo


def muestra():
    p=ROOT/'datos_piloto/CEE_Madrid_15_reales.csv'
    return cargar_archivo(p.name,p.read_bytes())


def test_cuatro_ejemplos_y_agregado_oficiales():
    reports=validar()
    assert len(reports)==5
    assert all(r['superado'] for r in reports)
    assert all(r.get('max_error_curva_ci',0)<.001 for r in reports)


def test_exportacion_no_compensa_combustibles_ni_reduce_eui():
    energy={k:0. for k in CARRIERS};energy.update(electricidad_red=100,gas=200,renovable_autoconsumida=50)
    years=range(2025,2051)
    factors={k:pd.Series(0.,index=years) for k in CARRIERS}
    factors['electricidad_red']=pd.Series(.3,index=years)
    factors['gas']=pd.Series(.2,index=years)
    result=proyectar(energy,100,factors,2025,exportacion=1000)
    assert result.eui_kwh_m2_anio.iloc[0]==3.5
    assert result.credito_exportacion_kg_anio.iloc[0]==30
    assert result.co2_neto_kg_anio.iloc[0]==40


def test_factores_anuales_y_no_reduccion_directa_carbono():
    energy={k:0. for k in CARRIERS};energy['electricidad_red']=100
    ef,origin=factores_espana(energy,2025)
    result=proyectar(energy,100,ef,2025)
    assert result.eui_kwh_m2_anio.nunique()==1
    assert result.ci_kg_m2_anio.iloc[-1]<result.ci_kg_m2_anio.iloc[0]
    assert result.ci_kg_m2_anio.iloc[0]==pytest.approx(.0913792404943125)


def test_termicas_y_otros_exigen_fuente():
    energy={k:0. for k in CARRIERS};energy['calor_red']=100
    with pytest.raises(ValueError,match='específico'):factores_espana(energy,2025)
    ef,_=factores_espana(energy,2025,{'calor_red':{'valor':.2,'fuente':'PRUEBA de factor específico'}})
    assert ef.calor_red.eq(.2).all()
    with pytest.raises(ValueError,match='fuente'):factores_espana(energy,2025,{'calor_red':{'valor':.2}})


def test_escenarios_15_reales_sin_falsear_calidad():
    summary,frames,reports=evaluar_cohorte(muestra(),complementar=False)
    assert len(frames)==15
    assert summary.MY_operacional.isna().all()
    data=muestra().set_index('id')
    for identity,frame in frames.items():
        assert frame.eui_kwh_m2_anio.iloc[0]==pytest.approx(float(data.loc[identity,'final_global']))
        assert reports[identity]['operacional_validado'] is False
    expanded,frames2,reports2=evaluar_cohorte(muestra(),complementar=True)
    assert len(frames2)==15
    assert (expanded.eui_escenario>=summary.eui_escenario).all()
    assert expanded.MY_operacional.isna().all()


def test_sensibilidad_superficie_y_no_doble_iluminacion():
    raw=muestra().head(1)
    _,one,_=evaluar_cohorte(raw,complementar=False,ratio_superficie=1)
    _,two,_=evaluar_cohorte(raw,complementar=False,ratio_superficie=2)
    identity=raw.iloc[0]['id']
    assert two[identity].eui_kwh_m2_anio.iloc[0]==pytest.approx(one[identity].eui_kwh_m2_anio.iloc[0]/2)
    assert two[identity].energia_kwh_anio.iloc[0]==one[identity].energia_kwh_anio.iloc[0]
    # Caso límite aislado: la iluminación ya certificada no se duplica.
    row=raw.iloc[0].copy(); row['final_ilu']='10';row['final_global']=str(float(row['final_global'])+10)
    model=reconstruir(row,complementar=True)
    assert sum(model['consumos_kwh'].values())>0
    assert sum(x['kwh_anio'] for x in model['detalle'])==pytest.approx(sum(model['consumos_kwh'].values()))


def test_entrada_operacional_rechaza_falsos_completos():
    from crrem_panel import plantilla
    entry=plantilla('caso_prueba',TIPOS[1],2025)
    with pytest.raises(ValueError):evaluar(entry)
    entry.update(origen='estimado',justificacion='Caso matemático aislado',fuente_superficie='Prueba',
                 incertidumbre='Solo regresión, no edificio real',gia_m2=100.,gia_verificada=True,
                 perimetro_completo=True,cobertura_completa=True,ocupacion_completa=True,
                 unidades_compatibles=True,
                 consumos_kwh={k:0. for k in CARRIERS},renovable_exportada_kwh=0.)
    entry['consumos_kwh']['electricidad_red']=1000.
    result,cross,source=evaluar(entry)
    assert result.eui_kwh_m2_anio.iloc[0]==10.
    entry['consumos_kwh']['electricidad_red']=None
    with pytest.raises(ValueError):evaluar(entry)


@pytest.mark.parametrize('value',[True,None,np.inf,-1,'no disponible'])
def test_no_imputa_numeros_invalidos(value):
    with pytest.raises(ValueError):numero(value,'Prueba')


def test_no_extrapola_factores_y_rechaza_anios_fraccionarios():
    with pytest.raises(ValueError):serie({2025:.2},range(2025,2051),'Factor')
    with pytest.raises(ValueError):serie({2025.5:.2},range(2025,2051),'Factor')
