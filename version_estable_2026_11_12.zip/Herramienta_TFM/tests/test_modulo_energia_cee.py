import unittest
import pandas as pd
from modulo_energia_cee import diagnosticar, resumen

class TestDiagnosticoCEE(unittest.TestCase):
    def fixture(self):
        return pd.DataFrame([{'edif_tipo':'BloqueDeViviendaCompleto','edif_tiporeg':'Edificio Existente',
            'edif_superf':'400,0','final_global':'102,0','final_calef':'70,0','final_refrig':'12,0',
            'final_acs':'20,0','final_ilu':'0', 'calefac_vector':'GasNatural',
            'refrig_vector':'ElectricidadPeninsular','acs_vector':'GasNatural'}])

    def test_valido_no_es_crrem(self):
        res=diagnosticar(self.fixture())
        self.assertTrue(bool(res.loc[0,'candidato_precrrem']))
        self.assertTrue(pd.isna(res.loc[0,'crrem_misalignment_year']))
        self.assertTrue(pd.isna(res.loc[0,'eui_operacional_crrem']))
        self.assertEqual(float(res.loc[0,'cee_kwh_anio_servicios_certificados']),40800)

    def test_vector_desconocido_excluye(self):
        inp=self.fixture(); inp.loc[0,'refrig_vector']=''
        res=diagnosticar(inp)
        self.assertFalse(bool(res.loc[0,'candidato_precrrem']))

    def test_faltante_no_se_convierte_en_apto(self):
        inp=self.fixture(); inp.loc[0,'final_ilu']=''
        res=diagnosticar(inp)
        self.assertFalse(bool(res.loc[0,'candidato_precrrem']))

    def test_punto_decimal_no_se_multiplica_por_100(self):
        inp=self.fixture(); inp.loc[0,'edif_superf']='1000.00'
        res=diagnosticar(inp)
        self.assertEqual(float(res.loc[0,'CEE_superficie']),1000.0)

    def test_cohorte_preparada(self):
        inp=pd.DataFrame([{'energia_final_cee_kwh_m2_anio':'100.2',
            'cee_calef_kwh_m2_anio':'70.0','cee_refrig_kwh_m2_anio':'10.2',
            'cee_acs_kwh_m2_anio':'20.0','cee_ilu_kwh_m2_anio':'0.0',
            'superficie_habitable_cee_m2':'200.0'}])
        res=diagnosticar(inp)
        self.assertFalse(bool(res.loc[0,'candidato_precrrem']))

    def test_vector_ausente_no_error_ni_apto(self):
        inp=self.fixture().drop(columns=['refrig_vector'])
        self.assertFalse(bool(diagnosticar(inp).loc[0,'candidato_precrrem']))

    def test_area_invalida_no_total(self):
        inp=self.fixture(); inp.loc[0,'edif_superf']='-1'
        self.assertTrue(pd.isna(diagnosticar(inp).loc[0,'cee_kwh_anio_servicios_certificados']))

    def test_cohorte_tipo_y_vectores_explicitados(self):
        inp=self.fixture()
        mapping={'final_global':'energia_final_cee_kwh_m2_anio','final_calef':'cee_calef_kwh_m2_anio',
                 'final_refrig':'cee_refrig_kwh_m2_anio','final_acs':'cee_acs_kwh_m2_anio',
                 'final_ilu':'cee_ilu_kwh_m2_anio','edif_superf':'superficie_habitable_cee_m2',
                 'edif_tipo':'tipo','edif_tiporeg':'clase'}
        self.assertTrue(bool(diagnosticar(inp.rename(columns=mapping)).loc[0,'candidato_precrrem']))

if __name__=='__main__': unittest.main()
