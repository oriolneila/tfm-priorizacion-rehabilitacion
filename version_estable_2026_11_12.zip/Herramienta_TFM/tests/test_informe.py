from io import BytesIO
import hashlib
import pandas as pd
import pytest
import conjunto_guardado
from motor import cargar_archivo,normalizar,calidad,calcular_escenarios
from informe_datos import preparar,recuperar_crrem,resumir_crrem
from informe_pdf import generar_pdf


def entrada():
    name,blob=conjunto_guardado.recuperar()
    return cargar_archivo(name,blob),name,hashlib.sha256(blob).hexdigest()


@pytest.mark.usefixtures('archivo_real_importado')
def test_informe_respeta_seleccion_pesos_y_no_modifica_datos():
    raw,name,sha=entrada();before=raw.copy(deep=True)
    cfg={'indices':list(raw.index[:4]),'pesos':(.7,.3,0),'modo':'anual','escenario':'escenario_2_energia_emisiones'}
    d=preparar(raw,name,sha,ranking=cfg)
    q,_=normalizar(raw.loc[cfg['indices']])
    expected=calcular_escenarios(calidad(q),cfg['pesos'],'anual')
    pd.testing.assert_frame_equal(d['ranking'],expected)
    pd.testing.assert_frame_equal(raw,before)
    assert d['n']==4 and d['total']==15
    assert d['estadisticas']['epnren']['mediana']==pytest.approx(expected.epnren.median())


@pytest.mark.usefixtures('archivo_real_importado')
def test_pdf_real_contiene_apartados_cifras_y_sin_identificadores_directos():
    from pypdf import PdfReader
    raw,name,sha=entrada()
    blob=generar_pdf(raw,name,sha)
    reader=PdfReader(BytesIO(blob))
    text='\n'.join(p.extract_text() for p in reader.pages)
    assert blob.startswith(b'%PDF')
    for title in ['Resumen ejecutivo','Resultados energéticos','Dimensión social','Conclusiones y próximos pasos','SHA-256 del archivo']:
        assert title in text
    assert '15 registros de los 15 importados' in text
    assert 'CRREM pendiente' in text
    assert sha in text.replace('\n','').replace(' ','')
    assert 'edif_refcat' not in text
    assert len(reader.pages)>=8


@pytest.mark.usefixtures('archivo_real_importado')
def test_informe_sin_indicadores_no_inventa_puntuaciones_ni_crrem():
    raw,name,sha=entrada()
    raw=raw[['id']].copy()
    d=preparar(raw,name,sha)
    assert d['disponibles']['escenario_1_energia']==0
    assert any('No hay energía' in x for x in d['conclusiones'])
    cr=recuperar_crrem(d)
    assert cr['summary'].get('eui_escenario',pd.Series(dtype=float)).notna().sum()==0


@pytest.mark.usefixtures('archivo_real_importado')
def test_informe_documentado_vacio_no_se_convierte_en_escenario_cee():
    raw,name,sha=entrada()
    d=preparar(raw,name,sha,crrem={'config':{'modo':'Evaluación con entradas documentadas'}})
    cr=recuperar_crrem(d)
    assert cr['operacional'] is True
    assert cr['summary'].empty
    assert not cr['series']


@pytest.mark.usefixtures('archivo_real_importado')
def test_pdf_conserva_resultado_crrem_ya_calculado_sin_repetir_modelo(monkeypatch):
    from reconstruccion_cee import evaluar_cohorte
    from pypdf import PdfReader
    raw,name,sha=entrada()
    summary,frames,_=evaluar_cohorte(raw,complementar=False)
    cfg={'base':2025,'modo':'Escenario a partir del CEE','tipo':'Residential Multi-Family','certificado':next(iter(frames))}
    snapshot=resumir_crrem(summary,frames,cfg)
    monkeypatch.setattr('reconstruccion_cee.evaluar_cohorte',lambda *a,**kw:pytest.fail('Exportar no debe repetir CRREM'))
    blob=generar_pdf(raw,name,sha,crrem={'config':cfg,'resultado':snapshot})
    text='\n'.join(p.extract_text() for p in PdfReader(BytesIO(blob)).pages)
    assert 'Ejemplo individual' in text
    assert 'Comparación anual' in text
    assert 'CRREM pendiente' not in text
    assert snapshot['summary'].shape==summary.shape
