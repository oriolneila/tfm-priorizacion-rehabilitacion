"""Las resoluciones de prueba nunca se guardan en la base de trabajo real."""
import copy
import json
import hashlib
from datetime import date,timedelta
import pytest
import incidencias
from incidencias import guardar_revision,historial,aplicar_revisiones
from social import ROOT,aplicar_enlaces
from motor import cargar_archivo,normalizar


def sample():
    links=json.loads((ROOT/'datos_piloto/enlaces_sociales.json').read_text(encoding='utf8'))
    return links,next(x for x in links if x['id']=='CEE_MAD_05')


def save(path,base,decision='Aceptar enlace',**changes):
    args=dict(cohort='a'*64,base=base,candidato=copy.deepcopy(base),decision=decision,
              responsable='Revisor de prueba aislada',fecha=date.today(),evidencia='https://www.sedecatastro.gob.es/',
              explicacion='Comprobación simulada exclusivamente en una base temporal de pruebas.',confirmado=True,path=path)
    args.update(changes)
    return guardar_revision(**args)


def test_persistencia_reversion_y_aislamiento(tmp_path):
    links,base=sample();db=tmp_path/'revisiones.sqlite3'
    save(db,base)
    assert len(historial('a'*64,db))==1
    assert historial('b'*64,db)==[]
    revised=aplicar_revisiones(links,historial('a'*64,db))
    assert next(x for x in revised if x['id']==base['id'])['estado_social']=='Enlace revisado manualmente'
    p=ROOT/'datos_piloto/CEE_Madrid_15_reales.csv'
    raw=cargar_archivo(p.name,p.read_bytes())
    n,_=normalizar(aplicar_enlaces(raw,revised))
    assert n.renta_territorial.notna().sum()==13
    assert 'revision_evidencia' in n
    save(db,base,'Mantener pendiente')
    assert len(historial('a'*64,db))==2
    n,_=normalizar(aplicar_enlaces(raw,aplicar_revisiones(links,historial('a'*64,db))))
    assert n.renta_territorial.notna().sum()==12


@pytest.mark.parametrize('changes',[{'confirmado':False},{'responsable':''},{'explicacion':'sí'},
                                  {'evidencia':'sin enlace'},{'fecha':date.today()+timedelta(days=1)}])
def test_no_guarda_sin_evidencia_y_confirmacion(tmp_path,changes):
    _,base=sample();db=tmp_path/'revisiones.sqlite3'
    with pytest.raises(ValueError):save(db,base,**changes)
    assert historial('a'*64,db)==[]


def test_cambio_de_datos_invalida_revision(tmp_path):
    links,base=sample();db=tmp_path/'revisiones.sqlite3';save(db,base)
    changed=copy.deepcopy(links)
    next(x for x in changed if x['id']==base['id'])['seccion_censal']='2807901001'
    result=aplicar_revisiones(changed,historial('a'*64,db))
    assert next(x for x in result if x['id']==base['id'])['estado_social'].startswith('Pendiente: datos cambiados')


def test_cota_no_se_convierte_en_valor_exacto(tmp_path):
    links,_=sample();base=next(x for x in links if x['id']=='CEE_MAD_12');db=tmp_path/'revisiones.sqlite3'
    changed=dict(base,nota_ine='')
    with pytest.raises(ValueError):save(db,base,candidato=changed)
    save(db,base)
    result=aplicar_revisiones(links,historial('a'*64,db))
    p=ROOT/'datos_piloto/CEE_Madrid_15_reales.csv';raw=cargar_archivo(p.name,p.read_bytes())
    n,_=normalizar(aplicar_enlaces(raw,result))
    assert n.renta_territorial.notna().sum()==12
    n,_=normalizar(aplicar_enlaces(raw,result,usar_cotas=True))
    assert n.renta_territorial.notna().sum()==13


def test_seccion_consultada_por_codigo_se_reproduce_sin_red(monkeypatch):
    import urllib.request
    monkeypatch.setattr(urllib.request,'urlopen',lambda *a,**k:pytest.fail('Debe utilizar la respuesta oficial guardada'))
    result=incidencias.consultar_seccion('2807919045',2024,ROOT/'fuentes/social_respuestas')
    _,base=sample()
    assert result['renta_media_seccion_eur_persona']==base['renta_media_seccion_eur_persona']
    assert result['anio_renta']==2024


def test_interfaz_guarda_y_recupera_revision_sin_modificar_piloto(tmp_path,monkeypatch,archivo_real_importado):
    from streamlit.testing.v1 import AppTest
    monkeypatch.setattr(incidencias,'DB',tmp_path/'ui.sqlite3')
    app=AppTest.from_file(str(ROOT/'app.py')).run(timeout=30)
    next(b for b in app.button if b.label=='Abrir la herramienta').click().run(timeout=30)
    next(b for b in app.button if b.label=='Entrar a la herramienta').click().run(timeout=30)
    app.sidebar.selectbox[0].set_value('Resolver incidencias').run(timeout=30)
    assert not app.exception
    assert any('Qué debes comprobar' in str(x.value) for x in app.subheader)
    next(b for b in app.button if b.label=='Guardar resultado de la comprobación').click().run(timeout=30)
    assert any('No se ha guardado' in str(e.value) for e in app.error)
    assert historial('a'*64)==[]
    next(s for s in app.selectbox if s.label=='Decisión tras la comprobación').set_value('Aceptar enlace')
    next(x for x in app.text_input if x.label=='Persona que realiza la revisión').set_value('Revisor de prueba aislada')
    next(x for x in app.text_input if x.label=='Enlace de la fuente o evidencia consultada').set_value('https://www.sedecatastro.gob.es/')
    next(x for x in app.text_area if x.label=='Resultado y justificación').set_value('Comprobación simulada en pruebas; no valida la dirección real.')
    next(x for x in app.checkbox if x.label.startswith('He realizado la comprobación')).check()
    next(b for b in app.button if b.label=='Guardar resultado de la comprobación').click().run(timeout=30)
    assert not app.exception
    assert any('Comprobación guardada' in str(x.value) for x in app.success)
    # Una nueva sesión de la aplicación recupera la decisión de la base temporal.
    other=AppTest.from_file(str(ROOT/'app.py')).run(timeout=30)
    next(b for b in other.button if b.label=='Abrir la herramienta').click().run(timeout=30)
    next(b for b in other.button if b.label=='Entrar a la herramienta').click().run(timeout=30)
    assert not other.exception
    assert other.metric[3].value=='13'
