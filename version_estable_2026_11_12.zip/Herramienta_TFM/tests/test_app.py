from pathlib import Path
from streamlit.testing.v1 import AppTest
import pytest
import conjunto_guardado

pytestmark=pytest.mark.usefixtures('archivo_real_importado')


def test_pantalla_de_marca_abre_inicio_antes_del_analisis():
    app=AppTest.from_file(str(Path(__file__).parents[1]/'app.py')).run(timeout=30)
    assert not app.exception
    assert [b.label for b in app.button]==['Abrir la herramienta']
    assert len(app.sidebar.selectbox)==0
    assert len(app.metric)==0
    next(b for b in app.button if b.label=='Abrir la herramienta').click().run(timeout=30)
    assert not app.exception
    assert app.sidebar.selectbox[0].value=='Inicio'
    assert any(b.label=='Entrar a la herramienta' for b in app.button)
    assert len(app.metric)==0


def abrir_herramienta():
    app=AppTest.from_file(str(Path(__file__).parents[1]/'app.py')).run(timeout=30)
    next(b for b in app.button if b.label=='Abrir la herramienta').click().run(timeout=30)
    next(b for b in app.button if b.label=='Entrar a la herramienta').click().run(timeout=30)
    return app


def test_portada_y_regreso_a_la_herramienta():
    app=AppTest.from_file(str(Path(__file__).parents[1]/'app.py')).run(timeout=30)
    next(b for b in app.button if b.label=='Abrir la herramienta').click().run(timeout=30)
    assert not app.exception
    assert len(app.metric)==0
    assert any('Entender los edificios' in str(x.value) for x in app.markdown)
    next(b for b in app.button if b.label=='Entrar a la herramienta').click().run(timeout=30)
    assert not app.exception
    assert app.metric[0].value=='15'
    app.sidebar.selectbox[0].set_value('Inicio').run(timeout=30)
    assert not app.exception
    assert len(app.metric)==0
    next(b for b in app.button if b.label=='Entrar a la herramienta').click().run(timeout=30)
    assert app.metric[0].value=='15'


def test_arranque_y_modo_anual():
    app=abrir_herramienta()
    assert not app.exception
    next(r for r in app.sidebar.radio if r.label=='Magnitud para priorizar').set_value('anual').run(timeout=30)
    assert not app.exception


def test_archivo_importado_resiste_portada_y_cambios_de_modulo():
    app=abrir_herramienta()
    name,_=conjunto_guardado.recuperar()
    assert not app.exception
    assert app.metric[0].value=='15'
    app.sidebar.selectbox[0].set_value('Inicio').run(timeout=30)
    app.run(timeout=30)  # La limpieza de widgets debe terminar antes de reentrar.
    next(b for b in app.button if b.label=='Entrar a la herramienta').click().run(timeout=30)
    app.sidebar.selectbox[0].set_value('Entorno social · INE').run(timeout=30)
    app.sidebar.selectbox[0].set_value('Ranking exploratorio').run(timeout=30)
    assert not app.exception
    assert app.metric[0].value=='15'
    assert any(name in str(x.value) for x in app.sidebar.success)
    next(b for b in app.sidebar.button if b.label=='Cambiar o retirar archivo').click().run(timeout=30)
    assert not app.exception
    assert len(app.metric)==0
    assert len(app.sidebar.file_uploader)==1


def test_nueva_sesion_recupera_archivo_y_sin_opcion_piloto():
    first=abrir_herramienta()
    second=abrir_herramienta()
    assert first.metric[0].value==second.metric[0].value=='15'
    assert not any(r.label=='Conjunto de trabajo' for r in second.sidebar.radio)
    assert not second.exception


def test_sin_archivo_no_precarga_muestra():
    conjunto_guardado.retirar()
    app=abrir_herramienta()
    assert not app.exception
    assert len(app.metric)==0
    assert len(app.sidebar.file_uploader)==1


def test_explorador_carbono():
    app=abrir_herramienta()
    app.sidebar.selectbox[0].set_value('Alineamiento CRREM').run(timeout=30)
    next(r for r in app.radio if r.label=='Métrica').set_value('carbono').run(timeout=30)
    assert not app.exception


def test_diagnostico_muestra_recuperada():
    app=abrir_herramienta()
    app.sidebar.selectbox[0].set_value('Diagnóstico energético CEE / pre-CRREM').run(timeout=30)
    assert not app.exception
    assert app.metric[0].value == '15'


def test_modulo_crrem_independiente():
    app=abrir_herramienta()
    app.sidebar.selectbox[0].set_value('Alineamiento CRREM').run(timeout=30)
    assert not app.exception
    assert len(app.metric)==2
    assert any(len(df.value)==15 for df in app.dataframe)
    assert any('Todos los CEE' in str(h.value) for h in app.subheader)
    next(r for r in app.radio if r.label=='Visualización').set_value('Anual total').run(timeout=30)
    assert not app.exception
    next(r for r in app.radio if r.label=='Métrica').set_value('carbono').run(timeout=30)
    assert not app.exception


def test_crrem_estimacion_idae_y_formulario_sin_imputar():
    app=abrir_herramienta()
    app.sidebar.selectbox[0].set_value('Alineamiento CRREM').run(timeout=30)
    next(c for c in app.checkbox if 'estructura IDAE' in c.label).check().run(timeout=30)
    assert not app.exception
    assert len(app.metric)==2
    next(r for r in app.radio if r.label=='Modo de cálculo').set_value('Evaluación con entradas documentadas').run(timeout=30)
    assert not app.exception
    assert len(app.metric)==0
    next(b for b in app.button if b.label=='Calcular energía y carbono').click().run(timeout=30)
    assert not app.exception
    assert any('No evaluable' in str(e.value) for e in app.error)


def test_pesos_imposibles_y_social_sin_renta():
    app=abrir_herramienta()
    assert app.metric[0].value=='15'
    next(c for c in app.sidebar.checkbox if c.label=='Incorporar renta territorial INE').uncheck().run(timeout=30)
    assert not any('sintético' in str(x.value).lower() for x in app.info)
    next(s for s in app.selectbox if s.label=='Escenario para ordenar').set_value('escenario_3_con_contexto_social').run(timeout=30)
    assert not app.exception
    assert any('No se puede calcular' in str(w.value) for w in app.warning)
    next(s for s in app.sidebar.slider if s.label=='Energía (%)').set_value(90).run(timeout=30)
    assert not app.exception
    assert any('100 %' in str(x.value) for x in app.error)


def test_social_real_y_auditoria():
    app=abrir_herramienta()
    assert not app.exception
    assert app.metric[3].value=='12'
    next(s for s in app.selectbox if s.label=='Escenario para ordenar').set_value('escenario_3_con_contexto_social').run(timeout=30)
    assert not app.exception
    assert not any('No se puede calcular' in str(w.value) for w in app.warning)
    app.sidebar.selectbox[0].set_value('Entorno social · INE').run(timeout=30)
    assert not app.exception
    assert app.metric[0].value=='12 / 15'
    assert app.metric[1].value=='2'
    next(c for c in app.sidebar.checkbox if c.label=='Usar también cotas por secreto estadístico').check().run(timeout=30)
    assert not app.exception
    assert app.metric[0].value=='13 / 15'
