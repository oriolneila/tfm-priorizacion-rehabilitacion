"""Las pruebas de interfaz importan datos reales en almacenamiento temporal."""
from pathlib import Path
import json
import pandas as pd
import pytest
import conjunto_guardado
from motor import cargar_archivo,exportar_csv


@pytest.fixture
def archivo_real_importado(tmp_path,monkeypatch):
    monkeypatch.setattr(conjunto_guardado,'DB',tmp_path/'activo.sqlite3')
    root=Path(__file__).parents[1]/'datos_piloto'
    path=root/'CEE_Madrid_15_reales.csv'
    raw=cargar_archivo(path.name,path.read_bytes())
    location=pd.read_csv(root/'localizacion_CEE_15.csv',dtype=str,keep_default_na=False)
    raw=raw.merge(location.drop(columns='edif_muni'),on='id',how='left',validate='one_to_one',sort=False)
    links=pd.DataFrame(json.loads((root/'enlaces_sociales.json').read_text(encoding='utf8')))
    links=links.rename(columns={'renta_media_seccion_eur_persona':'renta_candidata_ine_eur_persona'})
    columns=['id','estado_social','seccion_censal','anio_renta','fuente_renta','renta_candidata_ine_eur_persona',
             'nota_ine','direccion_catastro','calidad_renta','motivo','metodo','fuente_localizacion']
    raw=raw.merge(links[[x for x in columns if x in links]],on='id',how='left',validate='one_to_one')
    conjunto_guardado.guardar('CEE_reales_importados.csv',exportar_csv(raw))
