"""Regresiones con respuestas oficiales congeladas de los 15 CEE reales."""
import json
import pandas as pd
import pytest
from social import ROOT,recuperar_piloto,enlazar_fila,aplicar_enlaces,interpretar_renta,descargar
from motor import cargar_archivo,normalizar,calidad,calcular_escenarios


def fixtures():
    links=json.loads((ROOT/'datos_piloto/enlaces_sociales.json').read_text(encoding='utf-8'))
    p=ROOT/'datos_piloto/CEE_Madrid_15_reales.csv'
    return cargar_archivo(p.name,p.read_bytes()),links


def test_localizacion_original_y_respuestas_reproducibles_sin_red(monkeypatch):
    import urllib.request
    monkeypatch.setattr(urllib.request,'urlopen',lambda *a,**k:pytest.fail('La reproducción no debe consultar la red'))
    loc=recuperar_piloto()
    _,saved=fixtures()
    normalized,_=normalizar(loc)
    for _,row in normalized.astype(object).where(normalized.notna(),'').iterrows():
        result=enlazar_fila(row,ROOT/'fuentes/social_respuestas')
        original=next(x for x in saved if x['id']==row.id_visual)
        assert result==original
    assert len(loc)==15


def test_ranking_solo_enlaces_conciliados_y_cotas_opcionales():
    raw,links=fixtures()
    enriched=aplicar_enlaces(raw,links)
    normalized,_=normalizar(enriched)
    score=calcular_escenarios(calidad(normalized))
    assert score.escenario_3_con_contexto_social.notna().sum()==12
    assert normalized.loc[normalized.id_visual.isin(['CEE_MAD_05','CEE_MAD_14','CEE_MAD_12']),'renta_territorial'].isna().all()
    bounded,_=normalizar(aplicar_enlaces(raw,links,usar_cotas=True))
    assert bounded.renta_territorial.notna().sum()==13
    assert all(x['anio_renta']==2024 for x in links)
    assert score.loc[score.punt_entorno_social.idxmax(),'id_visual']=='CEE_MAD_13'
    # Un cambio del orden del CSV no cambia el edificio al que se asigna la renta.
    reversed_result,_=normalizar(aplicar_enlaces(raw.iloc[::-1],links))
    pd.testing.assert_series_equal(normalized.set_index('id_visual').renta_territorial.sort_index(),reversed_result.set_index('id_visual').renta_territorial.sort_index())
    with pytest.raises(ValueError):aplicar_enlaces(raw,links+[links[0]])


def test_seccion_ambigua_no_se_elige_por_orden():
    with pytest.raises(ValueError):interpretar_renta([])
    with pytest.raises(ValueError):interpretar_renta([{},{}])


def test_respuestas_con_huella_verificada():
    for path in (ROOT/'fuentes/social_respuestas').glob('*.json'):
        record=json.loads(path.read_text(encoding='utf8'))
        assert descargar(record['url'],path.parent)==record
