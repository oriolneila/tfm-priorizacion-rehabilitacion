"""Cálculo energético/carbono reproducible, separado de la estimación CEE.

Alcance de producción: España residencial, 1,5 ºC, CO2 sin gases fluorados.
El núcleo algebraico también permite comprobar los ejemplos oficiales globales.
"""
from functools import lru_cache
import numpy as np
import pandas as pd
import openpyxl
from crrem import ROOT, TIPOS, trayectoria, primer_cruce, verificar_fuentes

CARRIERS=('electricidad_red','gas','gasoleo','calor_red','frio_red','biomasa','otros','renovable_autoconsumida')


def numero(value, label, positivo=False):
    if isinstance(value,(bool,np.bool_)) or value is None:
        raise ValueError(f'{label}: falta un número válido')
    try: value=float(value)
    except (ValueError,TypeError): raise ValueError(f'{label}: valor no numérico')
    if not np.isfinite(value) or value<0 or (positivo and value==0):
        raise ValueError(f'{label}: debe ser finito y {"positivo" if positivo else "no negativo"}')
    return value


def anio(value):
    value=numero(value,'Año')
    if value!=int(value) or not 2020<=value<=2050:
        raise ValueError('El año debe ser entero entre 2020 y 2050')
    return int(value)


def serie(value, years, label):
    if np.isscalar(value):
        return pd.Series(numero(value,label),index=years,dtype=float)
    value=pd.Series(value).copy()
    try: index=pd.to_numeric(value.index)
    except (ValueError,TypeError): raise ValueError(f'{label}: años no válidos')
    if any(index%1): raise ValueError(f'{label}: años fraccionarios')
    value.index=index.astype(int)
    if not value.index.is_unique or not set(years).issubset(value.index):
        raise ValueError(f'{label}: faltan años o hay duplicados; no se extrapola')
    value=pd.to_numeric(value.reindex(years),errors='coerce').astype(float)
    if not np.isfinite(value).all() or value.lt(0).any():
        raise ValueError(f'{label}: valores ausentes, negativos o no finitos')
    return value


@lru_cache(maxsize=1)
def _libro_factores():
    with open(ROOT/'fuentes/emission-factors-v2.05.xlsx','rb') as handle:
        book=openpyxl.load_workbook(handle,read_only=True,data_only=True)
        rows=list(book['Emission Factors'].values)
        book.close()
    return rows


def factores_espana(consumos,base,overrides=None):
    """Electricidad anual, combustibles constantes; térmicas requieren proveedor.

No usa valores con enlaces 2027 ni un factor universal biomasa/otros.
Cada override exige valor/serie y fuente; nunca sustituye electricidad location-based.
"""
    verificar_fuentes()
    base=anio(base); years=range(base,2051)
    rows=_libro_factores()
    matches=[r for r in rows if len(r)>2 and r[1]=='ES' and r[2]=='Spain']
    if len(matches)!=1: raise ValueError('Factor eléctrico ES ambiguo/ausente')
    header=rows[4]
    grid={int(y):matches[0][i] for i,y in enumerate(header) if isinstance(y,int) and 2020<=y<=2050}
    data={'electricidad_red':serie(grid,years,'Electricidad ES'),
          'renovable_autoconsumida':pd.Series(0.,index=years)}
    provenance={'electricidad_red':'CRREM v2.05; Emission Factors; Spain; location-based; años explícitos',
                'renovable_autoconsumida':'CRREM Blueprint: renovable autoconsumida, factor cero'}
    fixed={'gas':'Natural Gas','gasoleo':'Oil / Heating Oil'}
    overrides=overrides or {}
    if set(overrides)-set(CARRIERS): raise ValueError('Factor de vector desconocido')
    if set(overrides)&{'electricidad_red','renovable_autoconsumida'}:
        raise ValueError('No se sustituye el factor eléctrico oficial ni el cero de renovable')
    for carrier in CARRIERS:
        if carrier in data: continue
        if numero(consumos.get(carrier),carrier)==0:
            data[carrier]=pd.Series(0.,index=years)
            provenance[carrier]='No consumido: contribución cero; no implica factor físico cero'
        elif carrier in overrides:
            info=overrides[carrier]
            if not isinstance(info,dict) or not str(info.get('fuente','')).strip():
                raise ValueError(f'{carrier}: falta fuente del factor específico')
            data[carrier]=serie(info.get('valor'),years,carrier)
            provenance[carrier]=str(info['fuente'])
        elif carrier in fixed:
            candidates=[(i+1,r) for i,r in enumerate(rows[92:104],start=92) if r[0]==fixed[carrier]]
            if len(candidates)!=1: raise ValueError(f'Factor ausente: {carrier}')
            rownum,row=candidates[0]
            data[carrier]=pd.Series(numero(row[1],carrier),index=years)
            provenance[carrier]=f'CRREM v2.05; Emission Factors fila {rownum}; {row[3]}'
        else:
            raise ValueError(f'{carrier}: se requiere factor específico documentado, no un valor genérico')
    return pd.DataFrame(data,index=years),provenance


def proyectar(consumos,gia,factores,base,exportacion=0,reduccion=0):
    """Núcleo independiente: EUI, CO2 bruto/neto y crédito de exportación limitado."""
    base=anio(base); years=pd.Index(range(base,2051),name='anio')
    area=numero(gia,'GIA',positivo=True)
    if set(consumos)!=set(CARRIERS): raise ValueError('Se deben declarar todos los vectores; ausencia no es cero')
    energy={k:numero(v,k) for k,v in consumos.items()}
    exported=numero(exportacion,'Renovables exportadas')
    rate=numero(reduccion,'Reducción anual')
    if rate>=1: raise ValueError('Reducción anual debe ser menor que 100 %')
    scale=pd.Series((1-rate)**(years-base),index=years)
    amounts=pd.DataFrame({k:v*scale for k,v in energy.items()},index=years)
    factors=pd.DataFrame({k:serie(factores[k],years,f'Factor {k}') for k in CARRIERS},index=years)
    if factors['renovable_autoconsumida'].ne(0).any(): raise ValueError('Factor de renovable autoconsumida debe ser cero')
    emissions=amounts*factors
    out=pd.DataFrame(index=years)
    out['energia_kwh_anio']=amounts.sum(axis=1)
    out['eui_kwh_m2_anio']=out['energia_kwh_anio']/area
    out['co2_bruto_kg_anio']=emissions.sum(axis=1)
    out['credito_exportacion_kg_anio']=np.minimum(exported*factors.electricidad_red,emissions.electricidad_red)
    out['co2_neto_kg_anio']=out.co2_bruto_kg_anio-out.credito_exportacion_kg_anio
    out['ci_kg_m2_anio']=out.co2_neto_kg_anio/area
    for k in CARRIERS:
        out['kwh_'+k]=amounts[k]
        out['fe_'+k]=factors[k]
        out['kg_'+k]=emissions[k]
    if not np.isfinite(out.to_numpy()).all(): raise ValueError('Desbordamiento del cálculo')
    return out


def comparar(frame,curva_energia,curva_carbono,base,area):
    out=frame.copy()
    years=list(range(anio(base),2051))
    out['umbral_eui']=serie(curva_energia,years,'Trayectoria energética')
    out['umbral_ci']=serie(curva_carbono,years,'Trayectoria carbono')
    out['brecha_eui']=out.eui_kwh_m2_anio-out.umbral_eui
    out['brecha_ci']=out.ci_kg_m2_anio-out.umbral_ci
    out['umbral_kwh_anio']=out.umbral_eui*area
    out['umbral_kg_anio']=out.umbral_ci*area
    return out,{'energia':primer_cruce(out.eui_kwh_m2_anio,out.umbral_eui,base),
                'carbono':primer_cruce(out.ci_kg_m2_anio,out.umbral_ci,base)}


def validar_entrada(entry):
    if not isinstance(entry,dict): raise ValueError('La entrada debe ser un objeto')
    if entry.get('pais')!='Spain' or entry.get('tipo') not in TIPOS:
        raise ValueError('Alcance de esta versión: España residencial, uso único')
    if entry.get('origen') not in ('medido','estimado'):
        raise ValueError('Se requieren datos medidos o estimación documentada')
    for key in ('justificacion','fuente_superficie'):
        if not str(entry.get(key) or '').strip(): raise ValueError(f'Falta {key}')
    for key in ('perimetro_completo','gia_verificada','cobertura_completa','ocupacion_completa','unidades_compatibles'):
        if entry.get(key) is not True: raise ValueError(f'Datos insuficientes: {key}')
    if entry.get('meses')!=12: raise ValueError('Se requieren 12 meses de cobertura; no se extrapola')
    if entry.get('origen')=='estimado' and not str(entry.get('incertidumbre') or '').strip():
        raise ValueError('La estimación requiere explicar incertidumbre y validación')
    if numero(entry.get('emisiones_f_gases_kg_anio',0),'F-gases')>0:
        raise ValueError('Se requiere trayectoria GEI con F-gases; esta versión compara CO2 sin F-gases')
    if 'renovable_exportada_kwh' not in entry:
        raise ValueError('Debe declararse renovable exportada; indicar cero solo si se ha comprobado')
    return anio(entry.get('anio'))


def evaluar(entry,reduccion=0):
    base=validar_entrada(entry)
    factors,origin=factores_espana(entry['consumos_kwh'],base,entry.get('factores_especificos'))
    out=proyectar(entry['consumos_kwh'],entry['gia_m2'],factors,base,entry['renovable_exportada_kwh'],reduccion)
    out,cross=comparar(out,trayectoria(entry['tipo'],'energia'),trayectoria(entry['tipo'],'carbono'),base,numero(entry['gia_m2'],'GIA',positivo=True))
    return out,cross,origin


def agregar(resultados):
    """Ponderación por GIA sin pérdidas silenciosas de años o edificios."""
    if not resultados: raise ValueError('No hay edificios evaluados para agregar')
    indexes=[frame.index for frame,area in resultados]
    if any(not idx.equals(indexes[0]) for idx in indexes): raise ValueError('Los horizontes deben coincidir')
    areas=[numero(area,'GIA',positivo=True) for frame,area in resultados]
    total=sum(areas)
    names=['eui_kwh_m2_anio','ci_kg_m2_anio','umbral_eui','umbral_ci']
    out=pd.DataFrame(0.,index=indexes[0],columns=names)
    for (frame,_),area in zip(resultados,areas): out=out+frame[names]*(area/total)
    base=int(out.index.min())
    return out,{'energia':primer_cruce(out.eui_kwh_m2_anio,out.umbral_eui,base),
                'carbono':primer_cruce(out.ci_kg_m2_anio,out.umbral_ci,base)}
