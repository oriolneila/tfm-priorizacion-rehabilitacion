"""Inspección del enlace territorial y consultas oficiales explícitas."""
import json
import pandas as pd
import streamlit as st
from motor import normalizar,exportar_csv
from social import ROOT,INE,enlazar_fila


def mostrar_social(raw):
    st.write('La dimensión social utiliza la renta neta media anual por persona de la sección censal. Menor renta implica mayor prioridad relativa dentro de esta muestra; no identifica la renta ni la vulnerabilidad de cada hogar.')
    st.caption('CEE → referencia de parcela → punto representativo catastral → sección censal y renta ADRH. La dirección se extrae del campo del CEE y se contrasta con el domicilio de Catastro. Este enlace automático conserva incertidumbre espacial; no valida el edificio ni sus residentes.')
    st.markdown(f'[Fuente oficial de renta y cartografía del INE]({INE}) · [Servicio oficial de coordenadas de Catastro](https://ovc.catastro.meh.es/OVCServWeb/OVCWcfCallejero/COVCCoordenadas.svc/rest/help)')
    links=st.session_state.get('social_actual',[])
    normalized,_=normalizar(raw)
    if links:
        table=pd.DataFrame(links)
        table['incluido_ranking']=table.id.isin(normalized.loc[normalized.renta_territorial.gt(0),'id_visual'])
        usable=int(table.incluido_ranking.sum())
        a,b,c=st.columns(3)
        a.metric('Con renta social utilizable',f'{usable} / {len(raw)}')
        b.metric('Enlaces por revisar',int((~table.estado_social.isin(['Enlace automático por parcela','Enlace revisado manualmente','Excluido tras revisión'])).sum()))
        c.metric('Valores con nota INE',int(table.get('nota_ine',pd.Series(dtype=str)).fillna('').ne('').sum()))
        years=', '.join(str(int(x)) for x in sorted(table.anio_renta.dropna().unique())) if 'anio_renta' in table else 'sin datos'
        st.info(f'Año de renta: {years}. Se conserva separado del año del certificado. Se utiliza la cartografía de la propia edición ADRH consultada.')
        columns=['id','incluido_ranking','estado_social','renta_media_seccion_eur_persona','anio_renta','direccion_cee','direccion_catastro','seccion_censal','calidad_renta','motivo','nota_ine']
        st.dataframe(table[[x for x in columns if x in table]],hide_index=True,width='stretch',column_config={
            'id':'CEE','direccion_cee':'Dirección CEE','direccion_catastro':'Domicilio Catastro',
            'seccion_censal':'Sección censal','renta_media_seccion_eur_persona':st.column_config.NumberColumn('Renta publicada/candidata (€/persona·año)',format='%.2f'),
            'anio_renta':'Año renta','estado_social':'Estado del enlace','calidad_renta':'Calidad renta',
            'incluido_ranking':'Incluido en cálculo social','motivo':'Motivo de revisión','nota_ine':'Nota original INE'})
        st.caption('Las rentas candidatas se muestran para auditoría; solo «Incluido en cálculo social» determina su uso. Una cota publicada no es un valor individual exacto. Los CEE sin renta utilizable permanecen en los escenarios energéticos y no reciben puntuación social.')
        st.download_button('Descargar auditoría social',exportar_csv(table),'auditoria_social_INE.csv','text/csv')
        st.download_button('Descargar trazabilidad social',json.dumps(links,ensure_ascii=False,indent=2).encode(),'enlaces_sociales_INE.json')
    else:
        st.info('Este conjunto aún no tiene enlaces sociales. Se necesitan dirección y referencia catastral única. Si falta referencia, revisa la dirección y completa el CSV; no se elige automáticamente un portal parecido.')
    st.info('Para entender una incidencia y guardar su comprobación, elige «Resolver incidencias» en el menú lateral. Las revisiones aceptadas se incorporan al ranking y conservan su historial.')
    st.subheader('Consultar otro CEE del conjunto')
    st.caption('La consulta envía únicamente la referencia de parcela a Catastro y sus coordenadas al INE. Se guardan respuestas con fecha y huella para reproducir el resultado. No se envían consumos ni datos de residentes. No hay OCR de PDF: se leen los campos del CSV/ZIP CEE.')
    ids=list(range(len(normalized)))
    if not ids:return
    index=st.selectbox('CEE para consultar en las fuentes oficiales',ids,format_func=lambda i:str(normalized.iloc[i].id_visual))
    supplied=st.text_input('Referencia catastral para completar o corregir la consulta (opcional)',key='social_ref_'+str(normalized.iloc[index].id_visual))
    if st.button('Consultar Catastro e INE para este CEE'):
        row=normalized.iloc[index].astype(object).where(normalized.iloc[index].notna(),'')
        previous=str(row.referencia)
        if supplied.strip():row['referencia']=supplied.strip()
        with st.spinner('Consultando localización y renta oficiales…'):
            result=enlazar_fila(row,ROOT/'fuentes/social_respuestas')
        if supplied.strip():result['referencia_original_cee']=previous;result['correccion_usuario']=True
        key=st.session_state['social_clave_actual']
        updated=[x for x in st.session_state.get('social_base',links) if x['id']!=result['id']]+[result]
        st.session_state[key]=updated
        st.session_state['social_actual']=updated
        if result['estado_social']=='Enlace automático por parcela':st.success('Enlace obtenido. Se utilizará al volver a calcular el conjunto.')
        else:st.warning(result.get('motivo','Pendiente de revisión'))
        st.json(result)
