"""Comparador académico acotado. No convierte CEE ni certifica CRREM."""
from pathlib import Path
import hashlib
import json
import numpy as np
import pandas as pd
import openpyxl
from functools import lru_cache


@lru_cache(maxsize=128)
def _sha_archivo(path,size,modified):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

ROOT = Path(__file__).parent
TIPOS = ("Residential Single-Family", "Residential Multi-Family")
VECTORES = {"electricidad_red", "gas", "gasoleo", "calor_red", "frio_red", "biomasa", "otros", "renovable_autoconsumida"}


def verificar_fuentes():
    manifest = json.loads((ROOT / "fuentes/manifest.json").read_text(encoding="utf-8"))
    for item in manifest["archivos"]:
        path = ROOT / "fuentes" / item["archivo"]
        stat=path.stat()
        if _sha_archivo(str(path),stat.st_size,stat.st_mtime_ns) != item["sha256"]:
            raise ValueError(f"Fuente modificada: {path.name}")
    return manifest


def trayectoria(tipo, metrica):
    verificar_fuentes()
    if tipo not in TIPOS or metrica not in ("energia", "carbono"):
        raise ValueError("Tipología o métrica no admitida")
    sheet = "EUI Pathways kWh (sqm)" if metrica == "energia" else "CO2 Pathways (sqm)"
    with open(ROOT / "fuentes/pathways-v2.05.xlsx", "rb") as stream:
        book = openpyxl.load_workbook(stream, read_only=True, data_only=True)
        rows = list(book[sheet].values)
        book.close()
    matches = [r for r in rows[5:] if r[1] == "Spain" and r[3] == tipo]
    if len(matches) != 1 or tuple(rows[4][7:]) != tuple(range(2020, 2051)):
        raise ValueError("Estructura o selección de trayectoria ambigua")
    values = np.asarray(matches[0][7:], dtype=float)
    if not np.isfinite(values).all() or (values < 0).any():
        raise ValueError("Trayectoria incompleta o inválida")
    return pd.Series(values, index=range(2020, 2051), name="CRREM v2.05")


def primer_cruce(edificio, limite, base):
    years = list(range(base, 2051))
    if base not in range(2020, 2051) or not edificio.index.is_unique or not limite.index.is_unique:
        raise ValueError("Año base o índices inválidos")
    if not set(years).issubset(edificio.index) or not set(years).issubset(limite.index):
        raise ValueError("Faltan años: no se interpola ni extrapola")
    a, b = edificio.loc[years], limite.loc[years]
    if not np.isfinite(a).all() or not np.isfinite(b).all() or (a < 0).any() or (b < 0).any():
        raise ValueError("Valores no finitos, ausentes o negativos")
    crossed = a.index[a > b]
    return int(crossed[0]) if len(crossed) else None


def evaluar_energia(entrada, tipo, base, reduccion=0):
    """Admite solo periodo completo y GIA conciliada. No imputa cobertura."""
    if entrada.get("origen") not in ("medido", "estimado"):
        raise ValueError("CEE o procedencia desconocida: no evaluable")
    if not entrada.get("justificacion", "").strip():
        raise ValueError("Falta fuente y justificación de las entradas")
    for key in ("perimetro_completo", "gia_verificada", "cobertura_completa", "ocupacion_completa"):
        if entrada.get(key) is not True:
            raise ValueError(f"Datos insuficientes: {key}")
    if entrada.get("meses") != 12 or base not in range(2020, 2051):
        raise ValueError("Se requieren 12 meses y año base entre 2020 y 2050")
    if not np.isfinite(reduccion) or not 0 <= reduccion < 1:
        raise ValueError("Reducción anual inválida")
    area = float(entrada["gia_m2"])
    carriers = entrada["consumos_kwh"]
    if set(carriers) != VECTORES:
        raise ValueError("Deben declararse todos los vectores consumidos; exportaciones excluidas")
    if not carriers or any(not np.isfinite(v) or v < 0 for v in carriers.values()):
        raise ValueError("Consumos incompletos o inválidos")
    if not np.isfinite(area) or area <= 0:
        raise ValueError("GIA inválida")
    # El contrato incluye solo energía consumida, renovables autoconsumidas incluidas.
    intensity = sum(carriers.values()) / area
    years = np.arange(base, 2051)
    asset = pd.Series(intensity * (1-reduccion)**(years-base), index=years, name="Edificio (escenario)")
    curve = trayectoria(tipo, "energia").loc[base:]
    frame = pd.concat([curve, asset], axis=1)
    frame["energia_anual_kwh"] = frame[asset.name] * area
    frame["umbral_anual_kwh"] = frame[curve.name] * area
    return frame, primer_cruce(asset, curve, base)
