"""Un mismo conjunto real alimenta los tres módulos de la aplicación."""
import hashlib
import sqlite3
import streamlit as st
from motor import cargar_archivo
import conjunto_guardado


@st.cache_data(show_spinner=False)
def _leer_archivo(name,content):
    return cargar_archivo(name,content)


@st.cache_data(show_spinner=False)
def _leer_complemento(raw):
    from social import enlaces_importados
    return enlaces_importados(raw)


def _retirar_archivo():
    conjunto_guardado.retirar()
    st.session_state.pop('archivo_recordado',None)
    st.session_state.pop('archivo_comun',None)


def _abrir_incidencias():
    st.session_state['navegacion_principal']='Resolver incidencias'


def restaurar_datos():
    if not st.session_state.get('archivo_recordado'):
        try:st.session_state['archivo_recordado']=conjunto_guardado.recuperar()
        except (ValueError,OSError,sqlite3.Error) as exc:
            st.error(f'No se puede recuperar el archivo guardado: {exc}');st.stop()


def cargar_datos():
    st.sidebar.markdown('<div class="lateral-etiqueta">CONJUNTO ACTIVO</div>',unsafe_allow_html=True)
    resumen_archivo=st.sidebar.empty()
    restaurar_datos()
    archivo_ui=st.sidebar.expander('Archivo de trabajo',expanded=not bool(st.session_state.get('archivo_recordado')))
    if st.session_state.get('archivo_recordado'):
        name,content=st.session_state['archivo_recordado']
        archivo_ui.success('Archivo activo: '+name)
        archivo_ui.caption('Guardado en este equipo. Se recupera al volver a abrir la herramienta.')
        archivo_ui.button('Cambiar o retirar archivo',on_click=_retirar_archivo)
    else:
        upload=archivo_ui.file_uploader('Registro CEE Madrid o CSV propio',type=['csv','zip'],key='archivo_comun')
        if upload is None:
            st.info('Importa un CSV o ZIP para comenzar el análisis.');st.stop()
        name,content=upload.name,upload.getvalue()
        try:
            _leer_archivo(name,content)
            conjunto_guardado.guardar(name,content)
        except (ValueError,OSError,sqlite3.Error) as exc:
            st.error(f'No se ha podido importar y guardar el archivo: {exc}');st.stop()
        st.session_state['archivo_recordado']=(name,content)
        st.rerun()
    try:
        raw=_leer_archivo(name,content)
    except (ValueError,OSError,sqlite3.Error) as exc:
        st.error(f'No se ha podido leer el archivo: {exc}');st.stop()
    digest=hashlib.sha256(content).hexdigest()
    resumen_archivo.markdown(f'<div class="lateral-conjunto"><span></span><strong>{len(raw):,} certificados</strong></div>'.replace(',','.'),unsafe_allow_html=True)
    links=st.session_state.get('social_'+digest,_leer_complemento(raw))
    from incidencias import historial,aplicar_revisiones,completar_bases
    try:
        records=historial(digest)
        links=completar_bases(raw,links,[x['id'] for x in records])
        st.session_state['social_base']=links
        links=aplicar_revisiones(links,records)
    except (ValueError,OSError,sqlite3.Error) as exc:
        st.error(f'No se pueden recuperar las revisiones guardadas: {exc}');st.stop()
    st.session_state['social_actual']=links
    st.session_state['social_conjunto']=digest
    st.session_state['social_clave_actual']='social_'+digest
    social_ui=st.sidebar.expander('Datos sociales',expanded=False)
    use_social=social_ui.checkbox('Incorporar renta territorial INE',value=True)
    use_bounds=social_ui.checkbox('Usar también cotas por secreto estadístico',value=False)
    social_ui.caption('Renta del entorno censal, no de los residentes. Enlaces dudosos excluidos; las cotas son opcionales.')
    pending=sum(x['estado_social'] not in ('Enlace automático por parcela','Enlace revisado manualmente','Excluido tras revisión') or (bool(x.get('nota_ine')) and not x.get('revision_manual') and x['estado_social']!='Excluido tras revisión') for x in links)
    if pending:st.sidebar.button(f'Incidencias · {pending:,}'.replace(',','.'),on_click=_abrir_incidencias,
        help='Casos pendientes o con limitaciones. Abre la guía para comprobarlos y registrar el resultado.',width='stretch')
    if not use_social or use_bounds:
        st.sidebar.caption('Renta territorial desactivada' if not use_social else 'Cotas estadísticas incluidas')
    if links and use_social:
        from social import aplicar_enlaces
        try:raw=aplicar_enlaces(raw,links,usar_cotas=use_bounds)
        except ValueError as exc:
            st.error(f'No se puede incorporar la renta: {exc}');st.stop()
    from apariencia import conjunto
    conjunto(name,len(raw),digest)
    if links:st.caption('Complemento social leído del archivo importado. Conserva fuente, año, candidatos y notas; no es una nueva consulta en línea.')
    return raw, name, digest
