# CONTINUACIÓN DEL DOCUMENTO DE CONTINUIDAD DEL TFM

Este texto continúa exactamente desde el apartado 3.4 del resumen anterior. Debe añadirse a continuación, conservando la numeración. Incluye las decisiones tomadas hasta el 24 de octubre de 2026, los avances técnicos y el estado pendiente de la integración oficial de CRREM.

## 3.4. Última corrección de los tutores: complejidad de los indicadores

En una tutoría posterior, cuando ya se disponía de datos energéticos reales y de una primera herramienta, se propuso dar más profundidad al tratamiento y comparación de las variables.

La intención no era necesariamente incorporar decenas de indicadores nuevos, sino mejorar la interpretación de las magnitudes existentes.

Se trató específicamente la influencia de la superficie de los edificios.

A partir de esta corrección se decidió que la herramienta debe permitir analizar tanto indicadores normalizados por superficie como indicadores anuales absolutos.

### Decisión acordada

La herramienta debe permitir elegir entre:

Modo A. Indicadores por superficie

- Energía primaria no renovable: kWh/m²·año.
- Energía final: kWh/m²·año.
- Emisiones calculadas: kgCO₂e/m²·año.

Este modo compara el desempeño relativo de los edificios, independientemente de su tamaño.

Modo B. Indicadores anuales totales

- Energía primaria no renovable: kWh/año.
- Energía final: kWh/año.
- Emisiones calculadas: kgCO₂e/año.

Este modo permite estudiar la magnitud anual total atribuida al edificio.

### Fundamento técnico

Los indicadores habituales del certificado de eficiencia energética (CEE) ya están expresados por metro cuadrado y año.

Por tanto, no deben dividirse otra vez por la superficie.

Para obtener la magnitud anual total correspondiente al certificado:

\\[ E\_{\mathrm{anual}}=I_E\cdot A\_{\mathrm{CEE}} \\]

\\[ CO\_{2,\mathrm{anual}}=I\_{CO_2}\cdot A\_{\mathrm{CEE}} \\]

Donde:

- \\(I_E\\): intensidad energética certificada.
- \\(I\_{CO_2}\\): intensidad de emisiones calculada.
- \\(A\_{\mathrm{CEE}}\\): superficie de referencia del mismo certificado.

Precaución: estos valores anuales son resultados derivados de la certificación, no consumos operacionales medidos.

### Consecuencia para la priorización

Los dos modos responden a preguntas distintas:

- ¿Qué edificio tiene peor desempeño por unidad de superficie?
- ¿Qué edificio representa un mayor volumen anual de energía o emisiones?

Un edificio pequeño puede presentar una intensidad energética muy elevada y, aun así, tener un volumen anual total inferior al de un edificio grande relativamente eficiente.

No debe afirmarse que un ranking es mejor que otro sin establecer previamente el objetivo de priorización.

### Propuesta adicional pendiente de validar

Se planteó estudiar el potencial de ahorro energético y de reducción de emisiones.

Conceptualmente:

\\[ \Delta E\_{i,\mathrm{potencial}}= \max(0,I\_{i,\mathrm{actual}}-I\_{i,\mathrm{objetivo}}) \cdot A_i \\]

Pero este cálculo solo tendría significado como escenario si se justifica la intensidad objetivo y se comprueba que es técnicamente alcanzable.

Estado: todavía no existe un modelo validado de ahorro real tras rehabilitación. No debe confundirse el consumo actual con el ahorro potencial.

# 4. ENFOQUE ACTUAL DEL TFM

## 4.1. Tema vigente

Priorización de la rehabilitación sostenible del parque edificado mediante criterios energéticos, climáticos y sociales.

El trabajo pretende desarrollar una metodología reproducible de apoyo a la decisión, implementada en una herramienta digital.

El enfoque debe seguir siendo ambiental y urbano, no inmobiliario-financiero.

## 4.2. Pregunta de investigación provisional

> ¿Cómo puede una metodología de priorización integrar criterios energéticos, de descarbonización y de vulnerabilidad social para identificar necesidades de rehabilitación sostenible en el parque edificado de un entorno urbano?

La pregunta sigue siendo provisional, pero representa el último planteamiento aceptado.

## 4.3. Objetivo general

Desarrollar y evaluar una metodología reproducible e interpretable para priorizar la rehabilitación sostenible de edificios existentes, incorporando indicadores energéticos, climáticos y socioeconómicos territoriales, y aplicarla a un caso de estudio urbano en Madrid.

## 4.4. Objetivos específicos

Los objetivos de trabajo desarrollados hasta ahora son:

1. Identificar y obtener fuentes públicas de información sobre edificios existentes en Madrid.
2. Analizar la calidad, disponibilidad y compatibilidad de sus variables.
3. Construir una base de datos de edificios residenciales comparables.
4. Definir indicadores energéticos, climáticos y sociales.
5. Desarrollar una metodología de priorización transparente.
6. Analizar el efecto de utilizar indicadores por superficie frente a indicadores absolutos.
7. Estudiar la incorporación de trayectorias CRREM y sus requisitos de información.
8. Comparar distintos escenarios de priorización.
9. Evaluar sensibilidad, incertidumbre y estabilidad de los rankings.
10. Implementar el procedimiento en una herramienta digital interpretable.

Estado: estos objetivos describen el planteamiento de trabajo. No todos han sido completados ni necesariamente aprobados individualmente por la tutora.

## 4.5. Alcance

Se plantea un caso piloto en Madrid, preferentemente con edificios residenciales plurifamiliares existentes.

El ámbito territorial definitivo —municipio, distrito o zona— no está cerrado.

La metodología se orienta al estudio de edificios y de su contexto urbano, no a la selección de inversiones por rentabilidad.

Quedan fuera del núcleo de investigación:

- El diseño constructivo detallado de cada rehabilitación.
- La gestión y ejecución de las obras.
- La valoración financiera completa de los activos.
- Un análisis completo de ciclo de vida.
- La aplicación indiscriminada a todo el parque español.
- El desarrollo de una plataforma comercial.

Estas exclusiones no impiden discutir las limitaciones o posibles ampliaciones.

# 5. LAS TRES DIMENSIONES DE PRIORIZACIÓN

## 5.1. Dimensión energética

Es la dimensión mejor desarrollada en cuanto a disponibilidad de datos.

Los indicadores principales identificados son:

| Indicador                           | Unidad     | Fuente prevista          |
| ----------------------------------- | ---------- | ------------------------ |
| Energía primaria no renovable       | kWh/m²·año | CEE                      |
| Energía primaria no renovable anual | kWh/año    | Cálculo a partir del CEE |
| Energía final calculada             | kWh/m²·año | CEE, si está disponible  |
| Energía final anual                 | kWh/año    | Cálculo a partir del CEE |
| Demanda de calefacción              | kWh/m²·año | CEE                      |
| Demanda de refrigeración            | kWh/m²·año | CEE                      |
| Calificación energética             | A–G        | CEE                      |
| Vector de calefacción               | Categoría  | CEE                      |
| Vector de ACS                       | Categoría  | CEE                      |
| Vector de refrigeración             | Categoría  | CEE                      |

También se identificaron otros campos relacionados con compacidad, sistemas, instalaciones y contribución renovable.

### Decisiones metodológicas

La herramienta debe permitir comparar resultados por superficie y valores anuales totales.

No se debe utilizar la superficie como un criterio adicional de prioridad si ya se ha incorporado al calcular las magnitudes absolutas, salvo que exista una justificación independiente.

Es necesario controlar la redundancia entre variables.

Por ejemplo, energía primaria no renovable, energía final y emisiones están relacionadas. Incorporarlas con pesos independientes sin estudiar su correlación puede contabilizar varias veces aspectos similares del desempeño.

### Estado

Comprobado: existe información energética en el registro público madrileño.

Desarrollado: controles iniciales de calidad y una aplicación capaz de trabajar con esos datos.

Pendiente: decidir qué indicadores entrarán definitivamente en la puntuación y cuáles servirán solamente para explicar o contextualizar los resultados.

## 5.2. Dimensión climática y de descarbonización

Esta dimensión incluye dos niveles diferentes.

### Nivel 1. Emisiones calculadas del CEE

El registro energético permite estudiar:

- Intensidad de emisiones calculadas.
- Emisiones anuales derivadas de la superficie.
- Relación entre emisiones, instalaciones y vectores energéticos.
- Posible dependencia de combustibles fósiles.

Estos indicadores pueden utilizarse sin afirmar que existe una evaluación CRREM.

### Nivel 2. Alineamiento con trayectorias CRREM

Se pretende incorporar:

- Intensidad energética operacional.
- Intensidad de carbono operacional.
- Trayectorias CRREM de España.
- Diferencia entre la intensidad del edificio y la trayectoria.
- Año de desalineamiento energético.
- Año de desalineamiento de carbono.
- Visualización gráfica hasta 2050.
- Escenarios de mejora y sensibilidad.

Estado: la interfaz gráfica está desarrollada en la versión 0.3, pero la integración y validación de las trayectorias oficiales y del cálculo completo siguen pendientes.

## 5.3. Dimensión social

Se decidió mantenerla como una dimensión fundamental, incluso después de la propuesta de reducir el TFM exclusivamente a CRREM.

Fuentes candidatas:

- Instituto Nacional de Estadística (INE).
- Atlas de Distribución de Renta de los Hogares.
- Indicadores de vulnerabilidad territorial del Ayuntamiento de Madrid.
- Proyecto municipal IGUALA.
- Investigaciones sobre pobreza energética.
- Estudios territoriales sobre vulnerabilidad residencial.

El indicador principal más inmediato es la renta socioeconómica del entorno, preferiblemente a escala de sección censal.

Pueden estudiarse otros indicadores cuando exista disponibilidad y justificación.

### Precaución metodológica

La renta media de una sección censal no representa necesariamente la renta de los residentes de un edificio concreto.

No debe producirse una inferencia individual a partir de información territorial agregada.

La dimensión se denominará, cuando corresponda, vulnerabilidad socioeconómica territorial.

### Estado

Se identificaron fuentes públicas, pero todavía no se ha completado la unión de los edificios del registro CEE con sus secciones censales ni calculado la puntuación social definitiva.

# 6. METODOLOGÍA GENERAL DESARROLLADA

## 6.1. Estructura prevista

La metodología se organiza en:

Datos → depuración → indicadores → priorización → comparación → sensibilidad → herramienta.

Las fases incluyen:

1. Obtener datos públicos.
2. Seleccionar edificios residenciales comparables.
3. Depurar registros y controlar duplicados.
4. Identificar la unidad de análisis.
5. Vincular información energética, catastral y territorial.
6. Construir indicadores.
7. Definir reglas de normalización.
8. Determinar pesos y agregación.
9. Comparar escenarios.
10. Analizar cambios y estabilidad.
11. Mostrar e interpretar resultados en una aplicación.

## 6.2. Unidad de análisis

Propuesta preferente: edificio residencial plurifamiliar completo.

Debe evitarse mezclar indiscriminadamente:

- Viviendas individuales dentro de bloques.
- Edificios plurifamiliares completos.
- Viviendas unifamiliares.
- Certificados de edificios nuevos.
- Certificados de edificios existentes.
- Registros de edificios rehabilitados o modificados de distinta manera.

Un certificado no equivale necesariamente a un edificio único.

## 6.3. Escenarios inicialmente definidos

La metodología planteada considera:

Escenario 1: desempeño energético.

Escenario 2: desempeño energético más descarbonización.

Escenario 3: desempeño energético, descarbonización y vulnerabilidad socioeconómica.

El objetivo no es simplemente producir tres listas, sino observar cómo cambian las prioridades al incorporar nuevas dimensiones.

### Ampliación propuesta tras la última tutoría

Cada escenario podría compararse utilizando:

- Indicadores relativos por m².
- Indicadores anuales absolutos.

Así se puede comprobar si cambia la prioridad al buscar corregir los peores desempeños o reducir la mayor magnitud ambiental anual.

### Pendiente

La estructura final de escenarios debe concretarse para evitar un número excesivo de combinaciones.

También está pendiente determinar si CRREM sustituirá a algún indicador climático del escenario 2 o se analizará inicialmente de forma independiente.

## 6.4. Modelo multicriterio

Todavía no se ha cerrado un método definitivo.

Se ha propuesto una estructura jerárquica:

- Dimensión energética.
- Dimensión climática.
- Dimensión social.

Cada dimensión puede incluir uno o varios indicadores.

Posteriormente se obtendría una valoración global mediante una regla de agregación justificada.

### Requisitos acordados

El método debe ser:

- Reproducible.
- Interpretable.
- Adecuado a la calidad de los datos.
- Transparente respecto a las ponderaciones.
- Capaz de tratar datos faltantes.
- Susceptible de análisis de sensibilidad.

Se ha planteado utilizar una agregación sencilla como referencia y estudiar métodos multicriterio más avanzados solo si aportan valor demostrable.

### Validación prevista

Se podrán analizar:

- Correlaciones entre indicadores.
- Variación de posiciones.
- Coincidencia entre los edificios prioritarios.
- Sensibilidad a los pesos.
- Estabilidad del ranking.
- Influencia de datos estimados.
- Comparación entre indicadores relativos y absolutos.

No existen todavía resultados definitivos de estas comparaciones.

# 7. DATOS PÚBLICOS INVESTIGADOS EN MADRID

## 7.1. Registro de Certificados de Eficiencia Energética

Fuente principal: Comunidad de Madrid.

Portal:

[https://datos.comunidad.madrid/dataset/registro_certificados_eficiencia_energetica](https://datos.comunidad.madrid/dataset/registro_certificados_eficiencia_energetica?utm_source=chatgpt.com)

Se identificaron descargas masivas separadas por periodos, incluidos recursos anteriores a 2024 y archivos de 2024, 2025 y 2026.

El usuario descargó y adjuntó el archivo:

`registro_certificados_eficiencia_energetica_2025.zip`

Este archivo constituye la fuente de los análisis cuantitativos comunicados en la conversación.

### Variables identificadas

Entre las variables del diccionario público figuran:

| Campo               | Descripción                                 |
| ------------------- | ------------------------------------------- |
| `edif_direc`        | Dirección                                   |
| `edif_muni`         | Municipio                                   |
| `edif_refcat`       | Referencia catastral                        |
| `edif_tipo`         | Tipo o alcance del certificado              |
| `edif_año`          | Año de construcción                         |
| `edif_superf`       | Superficie habitable                        |
| `edif_fecha`        | Fecha del certificado                       |
| `edif_zonaclim`     | Zona climática                              |
| `edif_compac`       | Compacidad                                  |
| `norenov_global`    | Energía primaria no renovable               |
| `norenov_co2global` | Emisiones calculadas                        |
| `cal_norenovglobal` | Calificación energética de energía primaria |
| `cal_co2global`     | Calificación de emisiones                   |
| `final_global`      | Energía final calculada                     |
| `final_calef`       | Energía final de calefacción                |
| `final_refrig`      | Energía final de refrigeración              |
| `final_acs`         | Energía final de ACS                        |
| `calefac_vector`    | Vector energético de calefacción            |
| `refrig_vector`     | Vector energético de refrigeración          |
| `acs_vector`        | Vector energético de ACS                    |

También existen campos relativos a demandas energéticas, instalaciones y renovables.

Precaución: el significado exacto, la granularidad y la relación entre los campos `final_global` y los valores por servicio deben verificarse en el esquema del CSV y en el diccionario oficial. No debe interpretarse `final_global` automáticamente como consumo operacional total del edificio.

## 7.2. Dirección General del Catastro

Fuente:

[https://www.sedecatastro.gob.es/](https://www.sedecatastro.gob.es/?utm_source=chatgpt.com)

Se identificaron:

- Consultas por referencia catastral.
- Datos descriptivos no protegidos.
- Cartografía de parcelas y edificios.
- Información de usos.
- Superficies.
- Antigüedad y características constructivas.
- Servicios de descarga y consulta cartográfica.

### Finalidad

- Identificar edificios únicos.
- Complementar características físicas.
- Obtener o contrastar geometrías.
- Geolocalizar edificios.
- Relacionar certificados con edificios.
- Vincular edificios con información territorial del INE.
- Estudiar superficies de referencia compatibles con el cálculo energético.

### Problema pendiente

Una referencia catastral puede estar asociada a varias unidades y certificados.

La relación entre certificado, vivienda, construcción, parcela y edificio no es necesariamente uno a uno.

No se ha completado una depuración catastral que permita afirmar que todos los registros seleccionados representan edificios únicos.

## 7.3. Instituto Nacional de Estadística

Fuente:

[https://www.ine.es/](https://www.ine.es/?utm_source=chatgpt.com)

Se identificó el Atlas de Distribución de Renta de los Hogares, con datos a diferentes escalas territoriales, incluida la sección censal.

Se trabajó con la disponibilidad de datos de renta de 2023, publicados posteriormente.

### Uso previsto

Caracterizar el contexto socioeconómico de los edificios.

### Problemas técnicos pendientes

- Obtener geometrías censales compatibles.
- Relacionar cada edificio con la sección correspondiente.
- Comprobar el año de las delimitaciones territoriales.
- Seleccionar indicadores sociales definitivos.
- Evitar atribuciones individuales a partir de datos agregados.

## 7.4. Ayuntamiento y Geoportal de Madrid

Se identificaron fuentes relacionadas con:

- Edificaciones y construcciones.
- Cartografía urbana.
- Secciones censales.
- Distritos y barrios.
- Índices de vulnerabilidad.
- Potencial solar de cubiertas.
- Registros ITE e IEE.
- Consumos energéticos de edificios municipales.

Portales de referencia:

[https://datos.madrid.es/](https://datos.madrid.es/?utm_source=chatgpt.com)

[https://geoportal.madrid.es/](https://geoportal.madrid.es/?utm_source=chatgpt.com)

### Precaución

Algunas fuentes corresponden al municipio de Madrid, mientras que el CEE de la Comunidad cubre también otros municipios.

La selección geográfica debe respetar esa diferencia.

## 7.5. Vulnerabilidad territorial IGUALA

Se identificó el proyecto municipal IGUALA, con indicadores de vulnerabilidad por barrios y distritos y cobertura histórica.

Se planteó utilizarlo como información complementaria o fuente de contraste.

Pendiente: comprobar si conviene utilizar indicadores individuales o un índice agregado, evitando duplicar criterios sociales.

## 7.6. Consumos reales de edificios municipales

Se identificó una base municipal de consumos energéticos mensuales.

Puede resultar útil para practicar procedimientos de agregación de consumos medidos.

Sin embargo, no equivale a una base de consumos operacionales residenciales.

No debe utilizarse para validar directamente las predicciones de edificios residenciales sin justificar la comparabilidad de los usos.

## 7.7. Potencial solar

El Geoportal municipal dispone de información sobre potencial solar de cubiertas.

Se consideró como una fuente complementaria para futuras extensiones, no como una variable obligatoria del modelo actual.

# 8. AUDITORÍA REAL DEL ARCHIVO CEE MADRID 2025

Este apartado recoge los resultados cuantitativos comunicados después de procesar el ZIP aportado por el usuario.

Son resultados de una auditoría previa del proyecto. Para incorporarlos definitivamente a la memoria deben reproducirse ejecutando los scripts sobre el archivo original.

## 8.1. Características generales

Se informó de:

| Concepto                                         | Resultado |
| ------------------------------------------------ | --------- |
| Registros totales                                | 110.650   |
| Columnas                                         | 86        |
| Certificados de bloques de viviendas completos   | 13.455    |
| Certificados de viviendas individuales en bloque | 58.592    |
| Certificados de viviendas unifamiliares          | 31.291    |
| Bloques completos existentes seleccionados       | 12.930    |

Importante: 13.455 y 12.930 no son cifras contradictorias si la segunda aplica el filtro adicional de edificio existente.

Deben conservarse las condiciones exactas de cada selección.

## 8.2. Filtros energéticos

La auditoría preliminar comunicó inicialmente 10.196 registros como aptos para un primer control técnico.

Posteriormente se refinó el procedimiento y se comunicaron estos resultados:

| Fase                                                    | Registros |
| ------------------------------------------------------- | --------- |
| Archivo completo                                        | 110.650   |
| Bloques completos existentes                            | 12.930    |
| Coherencia básica entre energía final total y servicios | 12.754    |
| Filtro ampliado de energía, superficie y vectores       | 10.144    |

El valor de referencia más reciente es 10.144, porque procede del filtro ampliado descrito como reproducible.

No obstante, deben conservarse las reglas exactas del script para poder comprobar el resultado.

## 8.3. Duplicidades catastrales

Se informó de 694 referencias catastrales repetidas, agrupando 1.618 registros dentro del subconjunto de bloques existentes.

Esto demuestra que el registro no puede tratarse directamente como una lista de edificios únicos.

Debe revisarse, entre otras cuestiones:

- Certificados emitidos en distintos años.
- Certificados diferentes para un mismo identificador.
- Alcance de certificación.
- Referencias múltiples.
- Registros que no puedan asociarse de manera inequívoca a un edificio.

## 8.4. Datos incompletos

Se detectaron 2.585 certificados de bloques existentes con consumo final positivo de refrigeración, pero sin vector energético identificado para ese servicio.

Esta situación impide asignar automáticamente toda esa energía a una fuente concreta.

No sería correcto suponer que es electricidad únicamente porque la refrigeración suele emplearla.

## 8.5. Valores anómalos

También se identificaron:

- Intensidades energéticas extremadamente bajas o altas.
- Campos ausentes.
- Posibles inconsistencias.
- Problemas al interpretar campos vacíos.
- Diferencias entre sumas de servicios e indicadores globales.

Una corrección en el tratamiento de valores vacíos permitió, según lo comunicado, obtener consistentemente los 10.144 candidatos tanto en la auditoría como en el módulo de la herramienta.

## 8.6. Conclusión que sí permite la auditoría

El registro contiene una cantidad importante de certificados de bloques residenciales existentes con información energética aprovechable para un análisis preliminar.

Lo que todavía no permite afirmar:

- Que existan 10.144 edificios únicos.
- Que todos tengan consumos operacionales calculables.
- Que todos tengan superficie compatible con CRREM.
- Que todos puedan relacionarse con el INE.
- Que todos puedan recibir un año CRREM de desalineamiento válido.

# 9. EVOLUCIÓN DE LA HERRAMIENTA DIGITAL

La herramienta se ha desarrollado como una aplicación en Python con interfaz Streamlit.

Su finalidad es permitir que el usuario cargue datos de edificios, compruebe indicadores, compare criterios de prioridad y visualice los resultados.

No se trata todavía de una plataforma comercial ni de una herramienta validada para tomar decisiones reales de inversión o rehabilitación.

## 9.1. Versión 0.1: prototipo inicial

Archivo generado:

`Herramienta_TFM_Priorizacion_MVP_v01.zip`

### Funciones desarrolladas

- Importación de archivos CSV.
- Lectura de variables del registro energético madrileño.
- Comprobaciones de calidad.
- Identificación preliminar de duplicados.
- Detección de referencias catastrales múltiples.
- Comparación de escenarios.
- Visualización de rankings.
- Modificación de ponderaciones.
- Exportación de resultados.
- Uso de datos sintéticos de ejemplo.

Se comunicó que el motor había superado seis pruebas automatizadas.

### Limitaciones

Los escenarios iniciales utilizaban energía, emisiones y datos sociales disponibles o incorporados por el usuario.

No existía una evaluación CRREM.

El prototipo no había sido validado sobre una base completa de edificios únicos ni mediante una comparación externa.

## 9.2. Versión 0.2: diagnóstico energético y pre-CRREM

Archivo generado:

`Herramienta_TFM_v02_preCRREM.zip`

### Desarrollo realizado

Se incorporó un módulo de revisión energética a partir de los campos reales del CEE.

Entre sus funciones:

- Revisar energía final global y por servicios.
- Controlar coherencia aritmética.
- Revisar la presencia de vectores energéticos.
- Identificar valores atípicos.
- Aplicar filtros sobre superficie y variables necesarias.
- Exportar subconjuntos de registros.
- Distinguir los indicadores calculados del CEE de las estimaciones operacionales.
- Mostrar advertencias cuando los datos no fueran suficientes.

Se comunicaron 11 pruebas automatizadas superadas.

### Resultado técnico

Se preparó una selección de 10.144 certificados candidatos para análisis energético preliminar, sin identificadores directos en el archivo distribuido.

La aplicación todavía no debía utilizar estos datos para presentar años CRREM de desalineamiento.

## 9.3. Versión 0.3: comparación de superficies y gráfica CRREM

Archivo generado:

`Herramienta_TFM_v03_Grafica_CRREM.zip`

También se generó una imagen de vista previa:

`Vista_previa_grafica_TRAYECTORIA_FICTICIA.png`

### Modificación 1. Indicadores relativos y absolutos

Se añadió la funcionalidad para alternar entre:

Por superficie

- kWh/m²·año.
- kgCO₂e/m²·año.

Anual total

- kWh/año.
- kgCO₂e/año.

El objetivo es que el ranking pueda cambiar según el criterio seleccionado.

Se añadió una prueba con dos edificios sintéticos para comprobar que el orden efectivamente puede invertirse al pasar de intensidades a magnitudes totales.

### Modificación 2. Nueva pestaña «Alineamiento CRREM»

Se desarrolló una pantalla inspirada en el explorador de trayectorias de CRREM mostrado por el usuario.

La intención es visualizar:

- Trayectoria CRREM.
- Trayectoria del edificio.
- Intensidad actual.
- Escenario de evolución.
- Punto de cruce.
- Año de desalineamiento.
- Métrica energética o de carbono.
- Calidad y procedencia de los datos.

La interfaz permite seleccionar energía o carbono y representar trayectorias anuales.

### Representación gráfica prevista

- Línea verde: trayectoria objetivo CRREM.
- Línea azul discontinua: evolución del edificio.
- Marcador destacado: año de desalineamiento.
- Eje horizontal: años, hasta 2050.
- Eje vertical: intensidad energética o de carbono.

Se planteó permitir cambios en las hipótesis de mejora anual y visualizar cómo afectan al momento de desalineamiento.

### Precaución fundamental

La imagen de vista previa de la versión 0.3 utilizaba datos ficticios.

No constituye una evaluación CRREM de un edificio madrileño.

### Pruebas

Se comunicaron 18 pruebas automatizadas superadas.

Estas pruebas incluyeron controles del módulo anterior y de la nueva lógica de cruce entre trayectorias.

Superar pruebas programadas no equivale a validar el modelo frente a los cálculos oficiales de CRREM.

## 9.4. Estado actual de la versión final

El 24 de octubre de 2026 el usuario solicitó expresamente:

> «Incorpora CRREM real, vamos a hacer una versión final».

Se inició la preparación de ese trabajo, pero no consta todavía la entrega de una versión final con las trayectorias oficiales integradas y verificadas.

Por tanto:

Última versión entregada y reconocible: v0.3.

Versión final con CRREM real: pendiente.

No se debe afirmar en el nuevo chat que CRREM oficial ya funciona, salvo que se localice y compruebe una actualización posterior del código.

# 10. CRREM: PAPEL EN EL TFM Y PROBLEMA TÉCNICO

## 10.1. Terminología correcta

La denominación es CRREM, no CREEM ni CREAM.

Significa Carbon Risk Real Estate Monitor.

Aunque procede de un marco relacionado con el sector inmobiliario, en este TFM se emplea para estudiar trayectorias energéticas y de descarbonización de edificios existentes.

No debe transformar el trabajo en un estudio financiero de activos.

## 10.2. Papel de CRREM

CRREM aporta una referencia temporal con la que comparar el desempeño energético y climático de edificios.

Sus trayectorias permiten estudiar cuándo una determinada intensidad supera el límite correspondiente a un año.

El concepto principal es el Misalignment Year, o año de desalineamiento.

Debe distinguirse entre:

- Año de desalineamiento energético.
- Año de desalineamiento de carbono.

Pueden ser diferentes.

## 10.3. Diferencia entre EPBD y CRREM

Esta distinción ya se discutió y debe conservarse.

EPBD: marco regulatorio europeo sobre eficiencia energética y evolución del parque edificado.

CRREM: metodología y trayectorias de referencia que permiten analizar el alineamiento energético y de carbono de edificios.

CRREM no debe presentarse como una obligación legal individual impuesta directamente por la EPBD.

Tampoco debe afirmarse que una evaluación CRREM sustituye el cumplimiento normativo de la EPBD.

## 10.4. Documentación oficial identificada

Se trabajó con los recursos oficiales publicados en:

[https://crrem.org/learn/](https://crrem.org/learn/?utm_source=chatgpt.com)

Y la biblioteca:

[https://crrem.org/library/](https://crrem.org/library/?utm_source=chatgpt.com)

Las referencias técnicas mencionadas durante la conversación fueron:

- CRREM Pathways & Datasets v2.05, de 30 de abril de 2026.
- CRREM Assessment Guide v1.03, de mayo de 2026.
- Documentación técnica complementaria de CRREM.
- Factores de emisión y datos necesarios para sus trayectorias.

Pendiente: descargar e inspeccionar directamente los archivos concretos que se utilizarán en el cálculo final, verificar sus nombres, estructura, versión, cobertura geográfica, tipologías y condiciones de uso.

El nuevo chat deberá congelar una versión documental y de datos para que el análisis sea reproducible.

## 10.5. Qué necesita CRREM

Para comparar un edificio con las trayectorias se necesita, entre otros aspectos:

- País y tipología compatibles con el conjunto oficial.
- Año base.
- Consumo energético operacional.
- Desglose por fuente de energía.
- Cobertura adecuada de los usos energéticos del edificio.
- Superficie compatible con la metodología.
- Factores de emisión correspondientes.
- Trayectorias oficiales de energía y carbono.
- Reglas de proyección y cálculo coherentes con la guía.

CRREM permite emplear datos modelizados o estimados bajo determinadas condiciones, pero deben identificarse claramente y justificarse.

La utilización de datos estimados no convierte automáticamente cualquier indicador del CEE en una entrada válida de CRREM.

# 11. PROBLEMA CENTRAL: CONVERTIR LOS DATOS DEL CEE A ENTRADAS COMPATIBLES CON CRREM

## 11.1. Por qué no podemos hacer una conversión directa

Los certificados energéticos españoles utilizan condiciones normalizadas de evaluación y producen indicadores calculados.

Entre ellos:

- Energía primaria no renovable.
- Energía final calculada para determinados servicios.
- Emisiones calculadas.
- Demandas energéticas.
- Calificaciones energéticas.

CRREM necesita intensidades basadas en un perímetro operacional definido.

La energía primaria no renovable del CEE no es lo mismo que el consumo final operacional de CRREM.

Por tanto, no se debe:

- Utilizar directamente `norenov_global` como EUI CRREM.
- Convertirlo con un único coeficiente genérico sin justificación.
- Utilizar directamente las emisiones certificadas como emisiones operacionales CRREM.
- Suponer que los consumos del certificado incluyen todos los usos reales del edificio.
- Utilizar sin comprobación la superficie habitable como superficie CRREM.

## 11.2. Hallazgo importante del registro madrileño

La auditoría identificó campos de energía final:

- `final_global`.
- `final_calef`.
- `final_refrig`.
- `final_acs`.

También campos de vectores energéticos:

- `calefac_vector`.
- `refrig_vector`.
- `acs_vector`.

Esto abre la posibilidad de construir una estimación energética mejor fundamentada que una conversión desde energía primaria.

No obstante, deben revisarse las definiciones exactas y su relación para evitar duplicidades.

## 11.3. Solución metodológica propuesta

Se planteó desarrollar un estimador físico-estadístico de consumo energético operacional a partir de:

1. Energía final calculada en el CEE.
2. Desglose por servicio.
3. Vectores energéticos.
4. Características del edificio.
5. Zona climática.
6. Estadísticas residenciales de referencia.
7. Hipótesis explícitas de uso.
8. Superficie compatible.
9. Comprobaciones de incertidumbre.

El objetivo no es reproducir consumos medidos inexistentes, sino generar una estimación suficientemente documentada para estudiar su compatibilidad con CRREM.

## 11.4. Esquema general de estimación

Se propuso una ecuación metodológica de referencia:

\\[ E\_{\mathrm{estimada},v} = \sum_s E\_{\mathrm{CEE},s,v} \cdot f\_{\mathrm{uso},s} \cdot f\_{\mathrm{clima},s} + E\_{\mathrm{otros},v} \\]

Donde:

- \\(E\_{\mathrm{estimada},v}\\): energía anual estimada para el vector \\(v\\).
- \\(E\_{\mathrm{CEE},s,v}\\): energía final de un servicio y vector según el CEE.
- \\(f\_{\mathrm{uso},s}\\): corrección justificada por condiciones de utilización.
- \\(f\_{\mathrm{clima},s}\\): ajuste climático cuando proceda.
- \\(E\_{\mathrm{otros},v}\\): estimación de usos no cubiertos.
- \\(s\\): servicio energético.
- \\(v\\): vector energético.

Esta ecuación es una propuesta metodológica del TFM, no una fórmula oficial CRREM.

Sus factores todavía no han sido calibrados.

No deben introducirse valores arbitrarios para hacer funcionar la herramienta.

## 11.5. Evitar la doble corrección climática

La zona climática ya interviene en el procedimiento de certificación.

No sería correcto aplicar después otra penalización general por tratarse de una zona fría o cálida.

Un ajuste mediante grados-día u otro procedimiento climático solo estaría justificado para trasladar una estimación entre condiciones meteorológicas claramente definidas.

Ese procedimiento debe documentarse y validarse.

## 11.6. Usos energéticos no incluidos en el CEE

Un punto relevante es que el CEE residencial puede no abarcar todos los usos que necesita una evaluación operacional.

Se identificaron como posibles usos complementarios:

- Electrodomésticos.
- Cocina.
- Otros consumos eléctricos de los hogares.
- Servicios comunes, según el alcance de la certificación.
- Otros consumos incluidos en el perímetro CRREM aplicable.

No deben añadirse automáticamente sin comprobar qué usos estaban ya incluidos.

## 11.7. Fuente estadística propuesta: IDAE SPAHOUSEC III

Se identificó el estudio SPAHOUSEC III, publicado por el IDAE en 2026, como fuente de referencia para consumos de los hogares españoles.

Portal:

[https://www.idae.es/](https://www.idae.es/?utm_source=chatgpt.com)

Se propuso utilizar sus estadísticas para:

- Contrastar órdenes de magnitud de consumo.
- Estimar usos no cubiertos.
- Estudiar diferencias entre vectores energéticos.
- Caracterizar consumos residenciales.
- Identificar incertidumbres derivadas del uso del edificio.

Pendiente: extraer las tablas originales concretas necesarias, revisar sus unidades y población de referencia, y justificar la transferencia de valores a edificios plurifamiliares madrileños.

Los promedios de hogares no deben asignarse automáticamente a un edificio concreto sin conocer su número de viviendas u otra información necesaria.

## 11.8. Superficies: uno de los principales problemas

El CEE utiliza una superficie de referencia asociada al inmueble certificado.

CRREM utiliza su propia definición de superficie, identificada en la documentación consultada como superficie interior bruta o Gross Internal Area.

Las magnitudes no deben suponerse idénticas.

Por tanto, se planteó estudiar información catastral para obtener o aproximar superficies compatibles.

No está aprobado ningún factor fijo de conversión entre superficie habitable y GIA.

Si se estima la superficie, debe indicarse:

- Valor original.
- Fuente.
- Regla de conversión.
- Justificación.
- Incertidumbre.
- Efecto sobre los indicadores.

## 11.9. Cálculo de intensidad energética

Una vez estimados los consumos finales por fuente y comprobado su perímetro:

\\[ EUI_i = \frac{\sum_v E\_{i,v}} {A\_{i,\mathrm{CRREM}}} \\]

Donde:

- \\(E\_{i,v}\\): energía anual del edificio \\(i\\) consumida mediante el vector \\(v\\).
- \\(A\_{i,\mathrm{CRREM}}\\): superficie compatible con la metodología CRREM.

Unidad:

kWh/m²·año.

## 11.10. Cálculo de intensidad de carbono

Conceptualmente:

\\[ CI_i(t)= \frac{ \sum_v E\_{i,v}(t)\cdot FE_v(t) }{ A\_{i,\mathrm{CRREM}} } \\]

Donde:

- \\(CI_i(t)\\): intensidad de carbono del edificio en el año \\(t\\).
- \\(E\_{i,v}(t)\\): energía por vector.
- \\(FE_v(t)\\): factor de emisión correspondiente.
- \\(A\_{i,\mathrm{CRREM}}\\): superficie de referencia.

La aplicación debe respetar los factores y reglas oficiales CRREM pertinentes, incluidos los tratamientos aplicables a electricidad, combustibles y renovables.

Estas ecuaciones son expresiones conceptuales de cálculo; la implementación oficial debe verificarse contra la documentación técnica y los ejemplos de CRREM.

# 12. GRÁFICA DE ALINEAMIENTO CRREM: DECISIÓN VISUAL CERRADA

## 12.1. Referencia visual aportada por el usuario

El usuario compartió una captura del explorador de trayectorias CRREM.

La imagen mostraba:

- Selectores de país, tipología y métrica.
- Una trayectoria de descarbonización descendente.
- Una línea correspondiente al edificio.
- El punto de cruce.
- Una línea vertical hasta el eje temporal.
- El año de desalineamiento.
- Un control de intensidad inicial.
- Un control de reducción anual.
- Un mensaje explicativo del resultado.

Decisión expresa: la herramienta del TFM debe incorporar una gráfica de este tipo.

No basta con mostrar un número de CRREM en una tabla.

## 12.2. Componentes deseados

La última pestaña de la herramienta debería contener:

### Configuración

- Edificio seleccionado.
- País: España.
- Tipología aplicable.
- Métrica: energía o carbono.
- Año base.
- Fuente del dato: medido, estimado o exploratorio.
- Escenario de mejora.
- Superficie utilizada.

### Gráfica

- Trayectoria oficial CRREM.
- Evolución estimada del edificio.
- Valor inicial.
- Año de cruce, cuando sea calculable.
- Leyenda.
- Unidades.
- Horizonte temporal.
- Identificación de la versión CRREM.

### Resultados

- Intensidad energética.
- Intensidad de carbono.
- Año de desalineamiento energético.
- Año de desalineamiento de carbono.
- Condición de compatibilidad.
- Calidad de las entradas.
- Advertencias metodológicas.

## 12.3. Escenarios de evolución

Se propuso utilizar, como escenario simplificado de reducción de intensidad:

\\[ I_t=I_0(1-r)^{t-t_0} \\]

Donde:

- \\(I_0\\): intensidad inicial.
- \\(r\\): reducción anual asumida.
- \\(t_0\\): año base.
- \\(t\\): año de proyección.

Este modelo puede ser útil para estudiar escenarios.

No debe presentarse automáticamente como el escenario oficial CRREM.

Hay una distinción importante:

- En una proyección de referencia sin actuaciones, la intensidad energética del edificio puede mantenerse constante.
- La intensidad de carbono puede variar aunque no se reduzca el consumo, por la evolución de los factores de emisión.
- Las mejoras introducidas mediante un deslizador representan hipótesis del usuario.

Por tanto, la futura versión final deberá evitar aplicar indiscriminadamente la misma tasa de reducción a energía y carbono.

## 12.4. Cálculo del año de desalineamiento

Conceptualmente, se identifica el primer año del horizonte analizado en el que la intensidad proyectada del edificio supera la trayectoria correspondiente.

\\[ I\_{\mathrm{edificio}}(t)> I\_{\mathrm{CRREM}}(t) \\]

Sin embargo, la implementación debe verificar:

- Cómo define CRREM el año de desalineamiento.
- Qué ocurre si el edificio ya está desalineado en el año base.
- Qué ocurre si nunca supera la trayectoria en el horizonte estudiado.
- Qué ocurre cuando faltan años.
- Cómo se tratan los factores de emisión futuros.
- Qué reglas de proyección son aplicables.
- Cómo se gestionan los cambios de tipología o perímetro.

No debe asignarse un año de desalineamiento extrapolando trayectorias oficiales que no cubren el periodo utilizado.

## 12.5. Índice de alineamiento propuesto

También se propuso un cociente complementario:

\\[ R_i(t)= \frac{ I\_{\mathrm{edificio},i}(t) }{ I\_{\mathrm{CRREM}}(t) } \\]

Interpretación propuesta:

- \\(R<1\\): intensidad inferior al umbral.
- \\(R=1\\): coincidencia con el umbral.
- \\(R>1\\): intensidad superior al umbral.

Este cociente puede facilitar la lectura visual.

No debe denominarse índice oficial CRREM si no existe esa denominación en la documentación original. Se trataría de un indicador complementario definido por la herramienta.

## 12.6. Comparación por superficie y anual total dentro de CRREM

Se decidió que la herramienta pueda mostrar magnitudes absolutas y relativas.

Sin embargo, el alineamiento CRREM se interpreta principalmente mediante intensidades.

La multiplicación por superficie resulta útil para expresar volúmenes anuales, pero no debería sustituir la definición original de la trayectoria.

Decisión conceptual: distinguir entre:

- Desempeño por superficie.
- Impacto anual absoluto.
- Alineamiento temporal CRREM.

Son tres lecturas distintas del edificio.

# 13. VALIDACIÓN Y TRATAMIENTO DE LA INCERTIDUMBRE

## 13.1. Por qué es necesario

El TFM no debe limitarse a producir resultados numéricos.

Debe demostrar que las prioridades obtenidas no dependen exclusivamente de elecciones arbitrarias o de datos insuficientes.

Los principales factores de incertidumbre identificados son:

- Valores ausentes en los CEE.
- Referencias catastrales duplicadas.
- Diferencias entre certificados de viviendas y edificios completos.
- Consumos calculados frente a consumos reales.
- Desglose energético incompleto.
- Superficies con definiciones diferentes.
- Estimación de usos no cubiertos.
- Elección de factores de emisión.
- Año y versión de las trayectorias CRREM.
- Asignación de indicadores sociales.
- Pesos del modelo multicriterio.

## 13.2. Niveles de calidad propuestos

Se planteó una clasificación interna para la herramienta:

| Nivel | Datos disponibles                                                      | Tratamiento                                      |
| ----- | ---------------------------------------------------------------------- | ------------------------------------------------ |
| A     | Consumos operacionales medidos, completos y compatibles                | Evaluación con datos medidos                     |
| B     | Consumos estimados mediante CEE y fuentes complementarias justificadas | Evaluación estimada, con incertidumbre           |
| C     | Datos energéticos incompletos o incompatibles                          | Análisis exploratorio, sin año CRREM concluyente |

Esta clasificación es una propuesta propia del TFM, no una clasificación oficial de CRREM.

Los niveles deberán definirse mediante reglas comprobables antes de implementarlos como etiquetas definitivas.

## 13.3. Validación de consumos estimados

Se propuso buscar una pequeña muestra de edificios residenciales con consumos reales.

El procedimiento podría incluir:

1. Estimar su consumo mediante los datos que se utilizarán en la herramienta.
2. Comparar los resultados con el consumo medido.
3. Calcular errores relativos y absolutos.
4. Analizar diferencias por tipología, instalaciones y zona climática.
5. Comprobar cómo se trasladan esos errores al ranking.

Estado: no se dispone todavía de una muestra validada de consumos operacionales residenciales.

No deben presentarse métricas de error ni precisión predictiva sin realizar este análisis.

## 13.4. Sensibilidad del alineamiento CRREM

Se propone estudiar cómo cambia el resultado cuando varían:

- Consumo energético inicial.
- Reparto por fuentes.
- Superficie de referencia.
- Usos energéticos complementarios.
- Factores de corrección.
- Escenarios de mejora.

Puede ser útil representar un intervalo de posibles trayectorias del edificio.

Sin embargo, ese intervalo deberá proceder de hipótesis documentadas y no de porcentajes elegidos arbitrariamente.

## 13.5. Sensibilidad del ranking

Una vez completados los indicadores, se estudiará:

- Correlación de Spearman o Kendall entre rankings, si resulta adecuada.
- Coincidencia de edificios en el grupo prioritario.
- Variaciones de posiciones.
- Estabilidad ante modificaciones de pesos.
- Sensibilidad a valores faltantes.
- Diferencias entre criterios relativos y absolutos.

No existe todavía una selección definitiva de todas las pruebas estadísticas.

# 14. EXPERIENCIAS Y CASOS REALES INVESTIGADOS

## 14.1. Caso 01: calle Tres Peces 9, Madrid

Se preparó una ficha documental de un edificio residencial situado en Lavapiés.

La información se obtuvo de documentación pública relacionada con una rehabilitación de EMVS Madrid y el proyecto SunHorizon.

### Datos comunicados

| Característica                  | Dato                              |
| ------------------------------- | --------------------------------- |
| Dirección                       | Calle Tres Peces 9, Madrid        |
| Año de construcción             | 1948                              |
| Tipología                       | Residencial plurifamiliar         |
| Viviendas                       | 9 según determinada documentación |
| Locales                         | 2                                 |
| Plantas                         | 5                                 |
| Superficie construida publicada | 1.072,16 m²                       |
| Intervención                    | Aproximadamente 2019–2021         |

Se identificó una discrepancia documental sobre el número de viviendas, ya que otra fuente mencionaba diez.

### Indicadores energéticos publicados

| Indicador                     | Antes              | Después           |
| ----------------------------- | ------------------ | ----------------- |
| Energía primaria no renovable | 272,5 kWh/m²·año   | 16,4 kWh/m²·año   |
| Emisiones calculadas          | 56,6 kgCO₂e/m²·año | 2,8 kgCO₂e/m²·año |

Se comunicaron reducciones aritméticas aproximadas del 93,98 % y del 95,05 %, respectivamente.

Precaución: estas reducciones proceden de indicadores publicados de certificación. No deben interpretarse automáticamente como ahorros operacionales medidos.

### Utilidad para el TFM

Este edificio es un caso documental interesante para:

- Demostrar cómo se organiza una ficha.
- Comparar indicadores antes y después.
- Estudiar qué información puede encontrarse públicamente.
- Analizar las limitaciones de fuentes y superficies.

### Limitación principal

El edificio ya fue rehabilitado.

No sirve para presentarlo como un inmueble actualmente pendiente de intervención.

## 14.2. Caso 02: carretera de Húmera 61, Pozuelo de Alarcón

Se elaboró una segunda ficha a partir de un certificado energético localizado públicamente y documentación complementaria.

### Datos comunicados

| Característica                   | Dato                             |
| -------------------------------- | -------------------------------- |
| Municipio                        | Pozuelo de Alarcón               |
| Dirección                        | Carretera de Húmera 61           |
| Tipología                        | Vivienda unifamiliar             |
| Año de construcción              | 1973                             |
| Fecha del certificado            | 9 de julio de 2024               |
| Superficie habitable certificada | 305 m²                           |
| Energía primaria no renovable    | 227,5 kWh/m²·año                 |
| Emisiones calculadas             | 47,5 kgCO₂/m²·año                |
| Calificación                     | E                                |
| Calefacción y ACS                | Gas natural, según documentación |

Se identificó una referencia catastral coincidente con información complementaria, pero la comprobación catastral directa quedó pendiente.

### Limitaciones

- No está verificado que la vivienda permanezca sin rehabilitar.
- No es un edificio plurifamiliar.
- No dispone de consumos operacionales completos.
- No se ha completado la unión con la sección censal.
- No permite una evaluación CRREM completa con la información recuperada.

### Papel actual

Es un ejemplo para probar la importación de datos y la documentación de fuentes, no una muestra representativa de bloques residenciales.

## 14.3. Relación entre los casos individuales y el estudio principal

Estos dos ejemplos fueron útiles antes de descargar el registro masivo de certificados.

Después de obtener el archivo 2025, la estrategia cambió.

El caso principal del TFM debería construirse a partir de una muestra seleccionada sistemáticamente del registro público, no depender exclusivamente de edificios con documentación individual excepcional.

Los ejemplos de Tres Peces y Húmera podrían mantenerse como ejercicios auxiliares, pero no deben confundirse con los resultados del análisis estadístico principal.

# 15. REVISIÓN BIBLIOGRÁFICA Y MARCO NORMATIVO

## 15.1. EPBD

Se trabajó con la Directiva (UE) 2024/1275, relativa a la eficiencia energética de los edificios.

Aspectos importantes para el TFM:

- Descarbonización del parque edificado.
- Mejora del desempeño energético.
- Renovación de edificios.
- Planificación de la renovación.
- Evolución del parque residencial.
- Relación con los objetivos climáticos europeos.

Se analizó la diferencia entre los objetivos nacionales de reducción de consumo del parque residencial y las obligaciones específicas aplicables a otras categorías de edificios.

Conclusión conceptual mantenida: la EPBD proporciona el marco regulatorio y estratégico, pero no constituye por sí misma una puntuación de prioridad de cada edificio.

Se identificó una versión consolidada de la directiva en 2026.

Pendiente: comprobar su redacción vigente y la situación precisa de transposición española antes de finalizar el capítulo normativo.

Fuente oficial:

[https://eur-lex.europa.eu/eli/dir/2024/1275/oj](https://eur-lex.europa.eu/eli/dir/2024/1275/oj?utm_source=chatgpt.com)

## 15.2. Normativa española

Se estudiaron como referencias relevantes:

- Certificación de eficiencia energética de edificios.
- Real Decreto 390/2021.
- Estrategias de rehabilitación del parque edificado.
- Políticas públicas de descarbonización.
- Planificación energética y climática.
- Estrategia Nacional contra la Pobreza Energética 2026–2030.
- Instrumentos vinculados a rehabilitación residencial.

También se identificó documentación de planificación nacional relacionada con la renovación de edificios.

Pendiente: verificar la versión y el estado de tramitación de cada documento estratégico antes de presentarlo como norma aprobada.

## 15.3. CRREM

Se revisó su función como marco de trayectorias energéticas y de carbono.

Su principal aportación para el TFM es incorporar una dimensión temporal a la evaluación ambiental.

También se identificaron sus limitaciones:

- Dependencia de la calidad de los datos.
- Necesidad de definir correctamente el perímetro.
- Diferencias entre datos operacionales y certificación.
- Sensibilidad a superficies.
- Influencia de factores de emisión.
- Dependencia de los escenarios empleados.

## 15.4. Justicia energética y vulnerabilidad social

Se investigaron:

- Pobreza energética.
- Vulnerabilidad residencial.
- Justicia energética.
- Relación entre eficiencia energética e ingresos.
- Barreras de acceso a la rehabilitación.
- Distribución territorial de necesidades.
- Diferencia entre consumos bajos por eficiencia y consumos bajos por privación.

Una cuestión especialmente relevante es que un hogar con dificultades económicas puede consumir poca energía porque no alcanza las condiciones de confort necesarias.

Por ello, un consumo bajo no siempre indica ausencia de necesidad de rehabilitación.

Este razonamiento puede formar parte de la discusión del TFM.

## 15.5. Investigaciones anteriores relacionadas

Se identificaron antecedentes próximos al tema, entre ellos:

- RETABIT.
- Investigaciones sobre vulnerabilidad energética y rehabilitación en Sevilla.
- Estudios de priorización geoespacial.
- Investigaciones sobre análisis multicriterio de edificios.
- Experiencias relacionadas con datos energéticos y sociales urbanos.
- Investigaciones sobre discrepancias entre consumo calculado y medido.

Advertencia: no debe afirmarse que este TFM es el primero en combinar información energética y social o en desarrollar herramientas GIS de priorización.

Existen antecedentes.

La originalidad debe formularse de forma más concreta, por ejemplo mediante la comparación reproducible de diferentes criterios, la influencia de las magnitudes absolutas y relativas, el tratamiento de incertidumbre y la incorporación temporal de CRREM.

Estas aportaciones son hipótesis de contribución, todavía no resultados demostrados.

## 15.6. GHG Protocol

Se consideró como referencia conceptual para límites de contabilización de emisiones y la distinción entre distintas fuentes de emisiones.

No quedó definido como un indicador autónomo de priorización.

## 15.7. Otros recursos

Se localizaron:

- Informes de organismos europeos.
- Estudios del IDAE.
- Estadísticas del INE.
- Datos abiertos madrileños.
- Documentación de la Comisión Europea.
- Investigaciones sobre el parque residencial español.
- Estudios sectoriales sobre rehabilitación y emisiones.

Los documentos bibliográficos extensos preparados durante el proyecto contienen más referencias y análisis.

El nuevo chat debería revisar los dossiers anteriores antes de ampliar otra vez la investigación.

# 16. DOCUMENTOS ACADÉMICOS PRODUCIDOS

## 16.1. Plantilla principal del TFM

Archivo del usuario:

`TFM_Plantilla_Oriol_Neila_Torrico.docx`

Fue creado a partir de un prompt preparado para Claude.

Incluye:

- Portada.
- Datos académicos.
- Resumen.
- Abstract.
- Palabras clave.
- Agradecimientos.
- Índice.
- Índice de figuras.
- Índice de tablas.
- Abreviaturas.
- Capítulos.
- Bibliografía.
- Anexos.
- Registro de IA.

## 16.2. Primer borrador redactado

Archivo generado:

`TFM_Oriol_Neila_Torrico_Borrador_01_revisado.docx`

Se completaron parcialmente:

- Introducción.
- Revisión bibliográfica.
- Metodología prevista.
- Bibliografía.
- Anexos metodológicos.

Se dejó pendiente el contenido dependiente de resultados empíricos.

## 16.3. Segundo borrador

Archivo generado:

`TFM_Oriol_Neila_Torrico_Borrador_02_revision_capitulos_1_y_2.docx`

Fue presentado como una revisión y ampliación de los capítulos 1 y 2.

Se reforzaron:

- Justificación ambiental.
- Diferencia entre priorizar edificios y diseñar intervenciones.
- Papel de la EPBD.
- Requisitos CRREM.
- Vulnerabilidad social.
- Estado de la cuestión.
- Antecedentes comparables.

Estado: es la última versión académica identificada en esta conversación.

No consta una actualización posterior de la memoria con los resultados definitivos de la auditoría del CEE ni con la nueva decisión relativa a las superficies.

El próximo borrador deberá incorporar esos avances y revisar la formulación de los indicadores.

## 16.4. Dossier de investigación

Se generaron los archivos:

`Dossier_investigacion_TFM_rehabilitacion_sostenible_2026.docx`

`Dossier_investigacion_TFM_rehabilitacion_sostenible_2026_ampliado.docx`

`Dossier_TFM_INVESTIGACION_PROFUNDA_2026_Integral.docx`

El último fue presentado como un dossier extenso de aproximadamente 64 páginas y 25.000 palabras.

Su finalidad es servir como base documental, no como memoria final.

Contiene análisis de normativa, literatura, fuentes y metodología.

## 16.5. Documentos de los casos reales

Caso Tres Peces:

`Caso_estudio_real_Tres_Peces_9_Madrid_TFM.docx`

`Entradas_herramienta_Tres_Peces_9_fuentes.csv`

Caso Húmera:

`Caso_piloto_02_Humera_61_datos_publicos.docx`

`Datos_entrada_Humera_61_TFM.csv`

## 16.6. Auditoría y archivos reproducibles

Archivos entregados:

`Auditoria_CEE_Madrid_2025_reproducible.zip`

`bloques_cee_preparados_SIN_IDENTIFICADORES.csv`

`INFORME_AUDITORIA_Y_PRECRREM.md`

Y muestras CSV destinadas a pruebas.

### Nota importante sobre la disponibilidad

Estos archivos se generaron en conversaciones anteriores.

Sus nombres no garantizan que estén disponibles automáticamente en el nuevo chat.

Deben recuperarse desde los adjuntos de la conversación, el proyecto o una nueva carga del usuario.

No deben inventarse enlaces de descarga ni afirmarse que se han examinado sin abrirlos realmente.

# 17. ESTRUCTURA ACTUAL DE LA MEMORIA DEL TFM

Se acordó mantener seis capítulos principales.

## 1. Introducción

1.1. Contexto y problemática de la rehabilitación sostenible del parque edificado. 1.2. Justificación e interés ambiental y social. 1.3. Pregunta de investigación. 1.4. Objetivo general y objetivos específicos. 1.5. Alcance, delimitación y estructura.

## 2. Revisión bibliográfica y estado de la cuestión

2.1. Rehabilitación energética y descarbonización. 2.2. Marco normativo y estratégico. 2.3. Indicadores de desempeño energético. 2.4. Trayectorias de descarbonización y CRREM. 2.5. Vulnerabilidad social y justicia energética. 2.6. Métodos de priorización multicriterio. 2.7. Inteligencia artificial y herramientas digitales. 2.8. Síntesis de antecedentes y oportunidades de investigación.

## 3. Metodología

3.1. Diseño de investigación. 3.2. Delimitación del caso de estudio. 3.3. Fuentes de información. 3.4. Preparación, depuración e integración de datos. 3.5. Indicadores de priorización. 3.6. Procedimiento multicriterio. 3.7. Validación y sensibilidad. 3.8. Herramienta e inteligencia artificial.

Modificación que conviene introducir: desarrollar expresamente la comparación entre indicadores por superficie y anuales totales, así como el procedimiento de estimación y alineamiento CRREM.

Puede hacerse dentro de los apartados existentes sin añadir demasiados niveles al índice.

## 4. Resultados

4.1. Caracterización del conjunto de datos. 4.2. Caracterización energética. 4.3. Evaluación de descarbonización. 4.4. Caracterización socioeconómica. 4.5. Priorización y comparación de escenarios. 4.6. Sensibilidad y estabilidad. 4.7. Funcionamiento de la herramienta.

Estado: la auditoría energética empieza a proporcionar resultados reales para el apartado 4.1, sujetos a reproducción.

Los rankings y resultados CRREM definitivos siguen pendientes.

## 5. Discusión

5.1. Interpretación de prioridades. 5.2. Efectos de incorporar dimensiones climáticas y sociales. 5.3. Relación con otros estudios. 5.4. Limitaciones e incertidumbre. 5.5. Aplicabilidad y transferencia.

## 6. Conclusiones y recomendaciones

6.1. Respuesta a la pregunta. 6.2. Principales conclusiones. 6.3. Recomendaciones. 6.4. Líneas futuras.

No deben redactarse conclusiones definitivas antes de completar el análisis.

## Anexos

Se prepararon los siguientes:

- Inventario y diccionario de variables.
- Fuentes de datos.
- Cálculos e indicadores.
- Resultados complementarios.
- Documentación técnica y reproducibilidad.
- Registro de herramientas de IA.

# 18. GITHUB, STREAMLIT Y PUBLICACIÓN DE LA HERRAMIENTA

## 18.1. Decisión sobre el acceso

El usuario expresó su preferencia por acceder a la herramienta mediante una URL en lugar de descargar y ejecutar un ZIP.

Se eligió como solución propuesta:

GitHub + Streamlit Community Cloud.

GitHub guardaría el código y Streamlit ejecutaría la aplicación online.

## 18.2. Cuenta de GitHub

El usuario confirmó expresamente que había creado su cuenta de GitHub.

Se le explicó cómo crear un repositorio llamado:

`tfm-priorizacion-rehabilitacion`

Sin embargo, no consta en el historial una URL concreta del repositorio creado ni la confirmación de que los archivos se subieron correctamente.

## 18.3. Publicación online

Se explicó el despliegue desde:

[https://share.streamlit.io/](https://share.streamlit.io/?utm_source=chatgpt.com)

También se intentó derivar la tarea a un entorno capaz de interactuar con el navegador.

No existe constancia verificable en esta conversación de una URL de Streamlit publicada y operativa.

Por tanto, el nuevo chat debe comprobar:

1. Si existe el repositorio.
2. Si el código de la versión 0.3 está subido.
3. Si la aplicación está desplegada.
4. Qué versión funciona online.
5. Si existen errores de dependencias.
6. Si los archivos oficiales CRREM pueden incorporarse correctamente.
7. Si los datos utilizados en la demostración están anonimizados.

No debe inventarse una URL.

## 18.4. Principio de privacidad

Se acordó utilizar datos sintéticos o públicos durante las primeras pruebas.

No deben publicarse:

- Contraseñas.
- Claves API.
- Archivos privados.
- Datos personales innecesarios.
- Información individual que no sea necesaria para el proyecto.

La reproducibilidad debe equilibrarse con la minimización de datos.

# 19. PAPEL DE LA INTELIGENCIA ARTIFICIAL

## 19.1. Decisión actual

El título original incluía explícitamente la inteligencia artificial.

Posteriormente se decidió que la IA no debía introducirse de forma artificial ni convertirse en una caja negra que decidiera el ranking sin justificación.

El núcleo actual se basa en:

- Datos públicos.
- Indicadores ambientales y sociales.
- Reglas reproducibles.
- Métodos de decisión.
- Aplicación digital.
- Validación.

## 19.2. Funciones de IA consideradas

Se han discutido posibles usos de IA para:

- Apoyo al procesamiento de datos.
- Identificación de inconsistencias.
- Interpretación de resultados.
- Análisis exploratorio.
- Desarrollo del código.
- Generación de documentación.
- Asistencia en la revisión bibliográfica.
- Elaboración de borradores.

No existe una decisión cerrada de entrenar un modelo predictivo o supervisado.

Tampoco se ha definido una variable objetivo externa que justifique entrenar un modelo supervisado para decidir prioridades.

## 19.3. Registro de uso de IA

La guía docente exige declarar el uso de herramientas de IA.

La memoria contiene un anexo destinado a registrar:

- Herramienta.
- Modelo o versión, cuando se conozca.
- Fecha.
- Finalidad.
- Tarea realizada.
- Información proporcionada.
- Resultado.
- Validación humana.
- Limitaciones.

### Actividades de IA que deben documentarse

Durante este proyecto se han utilizado asistentes para:

- Definir el planteamiento académico.
- Revisar bibliografía.
- Diseñar la metodología.
- Elaborar borradores.
- Preparar la plantilla.
- Ayudar con presentaciones.
- Crear y modificar código.
- Diseñar pruebas.
- Analizar datos.
- Preparar informes y documentos.

También se utilizó Canva con apoyo de ChatGPT para la presentación inicial.

La declaración debe describir usos reales y no atribuir a la IA tareas que no se hayan realizado.

# 20. PRESENTACIONES Y TUTORÍAS

Se preparó una presentación inicial en Canva para explicar:

- Contexto del problema.
- Pregunta y objetivos.
- Índice provisional.
- Tres dimensiones de sostenibilidad.
- Metodología prevista.
- Caso Madrid.
- Resultados esperados.
- Alcance.

Se trabajó sobre una presentación de nueve diapositivas.

También se generó un PDF con el guion oral de la primera sesión.

Archivo:

`Guion_presentacion_TFM_Sesion_1.pdf`

La presentación inicial precede a los avances recientes.

Debe considerarse desactualizada respecto a la versión 0.3 de la herramienta y a la corrección de los tutores sobre indicadores por superficie y anuales totales.

### Material para la próxima tutoría

Resultaría conveniente preparar una presentación breve con:

- Auditoría real de certificados Madrid 2025.
- Proceso de filtrado.
- Principales problemas de calidad.
- Herramienta v0.3.
- Comparación por m² y anual total.
- Gráfica CRREM.
- Explicación de la conversión CEE–CRREM.
- Limitaciones actuales.
- Próximas verificaciones.

No debe presentarse la gráfica sintética como un resultado de un edificio real.

# 21. ESTADO REAL DEL PROYECTO: QUÉ ESTÁ CERRADO Y QUÉ NO

## 21.1. Decisiones cerradas

| Tema                        | Decisión                                                           |
| --------------------------- | ------------------------------------------------------------------ |
| Enfoque                     | Rehabilitación sostenible del parque edificado                     |
| Perspectiva                 | Ambiental, energética, climática y social                          |
| Título                      | Título provisional ya acordado                                     |
| Caso geográfico             | Madrid como ámbito de referencia                                   |
| Fuente energética principal | Registro de CEE de la Comunidad de Madrid                          |
| Herramienta                 | Aplicación Python/Streamlit                                        |
| Comparación de magnitudes   | Por m² y anuales totales                                           |
| CRREM                       | Debe aparecer como apartado específico con gráfica de trayectorias |
| Presentación CRREM          | Inspirada en el explorador mostrado por el usuario                 |
| Datos no disponibles        | No deben inventarse                                                |
| Valores CEE                 | No equivalen automáticamente a consumos reales                     |
| IA                          | Debe tener una función justificable y declararse                   |
| Reproducibilidad            | Requisito fundamental                                              |

## 21.2. Propuestas de trabajo, todavía no cerradas

| Tema                  | Propuesta                                              |
| --------------------- | ------------------------------------------------------ |
| Tipología principal   | Residencial plurifamiliar                              |
| Ámbito específico     | Municipio o distrito seleccionado según disponibilidad |
| Indicadores sociales  | Renta y otros indicadores territoriales                |
| Método multicriterio  | Agregación transparente con análisis de sensibilidad   |
| Modelo energético     | Estimación física-estadística basada en CEE            |
| Usos no cubiertos     | Completar mediante estadísticas justificadas del IDAE  |
| Calidad de datos      | Clasificación A/B/C                                    |
| Índice complementario | Cociente intensidad del edificio / trayectoria CRREM   |
| Potencial de ahorro   | Escenarios frente a un objetivo energético definido    |
| IA adicional          | Solo si aporta capacidad verificable                   |
| Validación energética | Muestra de consumos medidos comparables                |

## 21.3. Información que debe verificarse

| Aspecto                                   | Situación              |
| ----------------------------------------- | ---------------------- |
| Número de edificios únicos                | No determinado         |
| Correspondencia con Catastro              | Pendiente              |
| Sección censal de cada edificio           | Pendiente              |
| Variables sociales integradas             | Pendiente              |
| Pesos multicriterio definitivos           | Pendiente              |
| Compatibilidad CEE–CRREM                  | Parcialmente estudiada |
| Superficies CRREM compatibles             | Pendiente              |
| Usos energéticos complementarios          | Pendiente              |
| Factores de emisión oficiales cargados    | No confirmado          |
| Trayectorias CRREM oficiales integradas   | No confirmado          |
| Años reales de desalineamiento calculados | No demostrados         |
| Validación frente a consumos medidos      | Pendiente              |
| Ranking definitivo                        | Pendiente              |
| Versión final de la herramienta           | Pendiente              |
| Publicación online                        | No verificada          |

# 22. PRINCIPALES RIESGOS METODOLÓGICOS

## 22.1. Confundir certificado y edificio

El registro puede incluir varios certificados para un mismo inmueble.

También hay certificados que corresponden a unidades individuales.

Si no se resuelve, la muestra podría contar varias veces algunos edificios.

## 22.2. Confundir intensidad y magnitud total

Los indicadores por m² miden desempeño relativo.

Las magnitudes anuales calculadas incorporan la superficie.

No representan exactamente la misma prioridad ambiental.

La herramienta debe explicar qué significa cada ranking.

## 22.3. Duplicar indicadores correlacionados

Energía primaria, energía final y emisiones están relacionadas.

Debe comprobarse su dependencia antes de incluirlas con pesos independientes.

## 22.4. Convertir energía primaria en consumo operacional sin justificación

Este riesgo afecta directamente a CRREM.

Debe evitarse cualquier conversión no documentada.

## 22.5. Completar usos energéticos mediante supuestos arbitrarios

Los usos faltantes solo deben estimarse cuando exista una fuente y un procedimiento justificable.

## 22.6. Utilizar superficies incompatibles

La elección de la superficie influye en los indicadores energéticos y de carbono.

Debe documentarse la definición utilizada.

## 22.7. Calcular un año CRREM con una trayectoria inventada

Los años deben calcularse únicamente mediante datos oficiales y proyecciones justificadas.

Las trayectorias sintéticas sirven para probar la programación, no para producir resultados académicos.

## 22.8. Confundir un modelo de demostración con uno validado

La herramienta puede funcionar técnicamente y producir una gráfica correcta sin que sus resultados sean científicamente fiables.

La validación constituye una fase independiente.

## 22.9. Interpretar renta territorial como renta individual

La asignación de indicadores sociales no debe producir conclusiones sobre personas concretas.

## 22.10. Afirmar que ya existe una metodología original demostrada

La contribución académica debe compararse con antecedentes y respaldarse mediante resultados.

No basta con combinar varios indicadores en una aplicación.

# 23. PRÓXIMOS PASOS: ORDEN DE TRABAJO RECOMENDADO

Esta sección es la más importante para continuar el proyecto sin volver a etapas ya superadas.

## Fase 1. Recuperar y revisar el código de la versión 0.3

Prioridad inmediata.

Localizar:

`Herramienta_TFM_v03_Grafica_CRREM.zip`

Comprobar:

- Archivo principal de Streamlit.
- Dependencias.
- Módulo de priorización.
- Módulo energético.
- Importación de CSV.
- Selector por superficie / anual total.
- Pestaña CRREM.
- Funciones de cálculo de cruce.
- Pruebas automatizadas.

Ejecutar las pruebas existentes.

No modificar el programa a ciegas ni reescribirlo completamente si funciona.

## Fase 2. Obtener los datos oficiales CRREM

Prioridad inmediata.

Descargar desde la biblioteca oficial:

- Trayectorias v2.05.
- Trayectorias de España.
- Tipología residencial aplicable.
- Intensidades energéticas.
- Intensidades de carbono.
- Factores de emisión necesarios.
- Guía y documentación técnica.
- Ejemplos oficiales de cálculo, si están disponibles.

Comprobar:

- Estructura de los archivos.
- Nombres de columnas.
- Unidades.
- Años.
- Definición de superficies.
- Tipologías.
- Reglas de cálculo.
- Versiones.

No inventar valores de trayectorias.

## Fase 3. Integrar las trayectorias oficiales en la gráfica

Objetivo: conseguir que la línea verde del gráfico proceda de los datos oficiales correspondientes a España y a la tipología seleccionada.

Añadir:

- Selector de métrica energética o de carbono.
- Identificación de versión.
- Leyenda de datos oficiales.
- Control de años disponibles.
- Gestión de valores faltantes.
- Aviso si la trayectoria no está completa.

El resultado de esta fase sería una visualización oficial de la trayectoria.

Todavía no implicaría que los edificios reales puedan evaluarse automáticamente.

## Fase 4. Resolver el estimador CEE–CRREM

Esta es la mayor dificultad técnica pendiente.

Trabajar con los campos reales del registro CEE para:

1. Identificar energía final por servicios.
2. Comprobar vectores energéticos.
3. Reconstruir consumos finales por vector.
4. Estudiar usos operacionales no cubiertos.
5. Obtener parámetros de fuentes oficiales.
6. Revisar superficies.
7. Definir escenarios energéticos.
8. Registrar incertidumbres.

El modelo deberá producir:

- Consumo estimado por fuente.
- Intensidad energética estimada.
- Intensidad de carbono estimada.
- Identificación de hipótesis.
- Calidad de las entradas.
- Motivos de exclusión.

No debe calcular años CRREM si faltan las condiciones necesarias.

## Fase 5. Validar el cálculo CRREM

Comparar el programa con los ejemplos oficiales disponibles.

Verificar especialmente:

- Intensidad energética.
- Intensidad de carbono.
- Factores eléctricos futuros.
- Desalineamiento energético.
- Desalineamiento de carbono.
- Comportamiento cuando ya existe desalineamiento.
- Comportamiento sin cruce antes de 2050.
- Casos con datos incompletos.

Añadir pruebas automatizadas de esos casos.

## Fase 6. Conectar edificios reales con el módulo

Seleccionar registros residenciales completos y comprobar si contienen información suficiente.

No es necesario que todos los certificados puedan utilizar CRREM.

Puede mostrarse la gráfica para un subconjunto con mejor calidad.

La herramienta debe distinguir:

- Alineamiento calculable.
- Alineamiento condicionado por estimaciones.
- Datos insuficientes.

## Fase 7. Identificar edificios únicos y añadir Catastro

Resolver:

- Referencias duplicadas.
- Edificios frente a unidades individuales.
- Correspondencia catastral.
- Geometrías.
- Superficies.
- Ubicación.

Determinar una muestra definitiva.

## Fase 8. Incorporar información social

Vincular los edificios con:

- Secciones censales.
- Renta territorial.
- Posibles indicadores complementarios.

Documentar fuentes, años y calidad espacial.

## Fase 9. Finalizar los escenarios multicriterio

Comparar:

- Energía relativa.
- Energía absoluta.
- Emisiones relativas.
- Emisiones absolutas.
- Indicadores CRREM cuando sean válidos.
- Vulnerabilidad territorial.

Definir cuáles son criterios de prioridad y cuáles son información explicativa.

Evitar sobreponderar la misma característica.

## Fase 10. Analizar resultados y robustez

Calcular:

- Rankings.
- Diferencias entre escenarios.
- Cambios de posición.
- Correlaciones.
- Conjuntos prioritarios.
- Sensibilidad a pesos.
- Sensibilidad a estimaciones.
- Cobertura de datos.

## Fase 11. Actualizar la memoria del TFM

Incorporar en el capítulo metodológico:

- Origen del registro real.
- Filtros.
- Definición de superficies.
- Comparación relativa/absoluta.
- Método de estimación energética.
- Integración CRREM.
- Ponderaciones.
- Sensibilidad.
- Validación.

Incorporar en resultados únicamente los cálculos efectivamente realizados.

## Fase 12. Publicar la versión final

Comprobar el repositorio GitHub y el despliegue de Streamlit.

Publicar después de superar pruebas y revisar datos sensibles.

La entrega final debería incluir:

- Herramienta.
- Código fuente.
- Requisitos de instalación.
- Archivos de configuración y datos permitidos.
- Documentación.
- Pruebas.
- Información sobre CRREM y licencias aplicables.
- Registro de herramientas IA.
- URL de acceso, cuando esté disponible.

# 24. QUÉ NO DEBE HACER EL NUEVO CHAT

Para evitar retrocesos, estas instrucciones son importantes:

No debe volver a proponer eliminar CRREM. Es una dimensión expresamente mantenida y se ha pedido desarrollar su gráfica.

No debe convertir el TFM en un estudio inmobiliario. La orientación ambiental y social está consolidada.

No debe volver a empezar una herramienta desde cero sin inspeccionar la v0.3.

No debe rellenar la gráfica con trayectorias ficticias presentándolas como CRREM España.

No debe utilizar directamente energía primaria no renovable como consumo operacional.

No debe afirmar que 10.144 certificados equivalen a 10.144 edificios únicos.

No debe atribuir los resultados de certificación a consumos medidos.

No debe eliminar la dimensión social simplemente porque todavía falte el cruce con el INE.

No debe seleccionar ponderaciones definitivas sin justificación.

No debe inventar cifras de ahorro potencial.

No debe presentar como terminada la versión final de la aplicación.

No debe incorporar conclusiones empíricas al TFM antes de completar los análisis.

# 25. ESTADO DEL TRABAJO A 24 DE OCTUBRE DE 2026

| Componente                       | Estado                                    |
| -------------------------------- | ----------------------------------------- |
| Tema y enfoque                   | Acordados                                 |
| Título                           | Provisional aceptado                      |
| Pregunta y objetivos             | Formulados; sujetos a ajustes             |
| Revisión bibliográfica           | Avanzada                                  |
| Memoria Word                     | Borrador 02                               |
| Fuentes públicas                 | Identificadas                             |
| ZIP oficial CEE Madrid 2025      | Aportado por el usuario                   |
| Auditoría energética             | Realizada inicialmente; debe reproducirse |
| Base de certificados filtrados   | Preparada                                 |
| Edificios únicos                 | Pendiente                                 |
| Catastro integrado               | Pendiente                                 |
| INE integrado                    | Pendiente                                 |
| Herramienta v0.1                 | Desarrollada                              |
| Herramienta v0.2                 | Desarrollada                              |
| Herramienta v0.3                 | Desarrollada                              |
| Selector por m² / anual          | Incorporado en v0.3                       |
| Gráfica tipo CRREM               | Incorporada en v0.3                       |
| Trayectorias oficiales CRREM     | Pendientes de integración verificada      |
| Estimación operacional desde CEE | Pendiente de completar y validar          |
| Años CRREM reales                | Pendientes                                |
| Modelo multicriterio definitivo  | Pendiente                                 |
| Rankings definitivos             | Pendientes                                |
| Validación y robustez            | Pendientes                                |
| Publicación Streamlit            | No verificada                             |
| Versión final                    | No entregada                              |

# 26. INSTRUCCIÓN INMEDIATA PARA CONTINUAR

La última petición de trabajo del usuario fue incorporar CRREM real y preparar una versión final de la herramienta.

Por tanto, la siguiente tarea debe ser:

> Recuperar la herramienta v0.3 y los datos de la auditoría del registro CEE Madrid 2025. Descargar y verificar las trayectorias CRREM v2.05 aplicables a España y al uso residencial, junto con su documentación técnica. Integrar las trayectorias reales en la última pestaña de la aplicación y completar un procedimiento de estimación energética a partir de los CEE, respetando los perímetros energéticos, los vectores, las superficies y los factores de emisión. Validar los cálculos y distinguir resultados medidos, estimados y exploratorios. Mantener la comparación por m² y anual total. Entregar el código reproducible, las pruebas y la versión actualizada, sin inventar años de desalineamiento ni declarar completada una evaluación incompatible con los datos.

Si la transformación desde el CEE no resulta suficientemente fiable para todos los edificios, la solución aceptable es mostrar las trayectorias CRREM oficiales y habilitar la evaluación únicamente para los edificios con entradas adecuadas, indicando los motivos por los que otros registros quedan excluidos.

No es necesario forzar una evaluación CRREM para toda la base de datos.

# 27. PRINCIPIO CENTRAL DEL TFM

El proyecto no pretende demostrar simplemente que es posible ordenar edificios en una tabla.

Su interés académico se encuentra en analizar cómo cambia la prioridad de rehabilitación dependiendo de la dimensión ambiental o social considerada, de la unidad de comparación utilizada y de la urgencia temporal de descarbonización.

Debe distinguir tres preguntas:

1\. ¿Qué edificios presentan peor desempeño energético por unidad de superficie?

2\. ¿Qué edificios representan un mayor volumen anual de energía o emisiones calculadas?

3\. ¿Qué edificios presentan mayor urgencia de descarbonización respecto a las trayectorias CRREM?

A estas preguntas se incorpora una cuarta consideración:

4\. ¿Cómo modifica el contexto de vulnerabilidad socioeconómica territorial la prioridad de rehabilitación?

La herramienta debe permitir estudiar estas cuestiones por separado y conjuntamente, evitando confundirlas.

El resultado final debe ser una metodología de apoyo a la decisión, transparente, reproducible y defendible académicamente, materializada en una herramienta accesible e interpretable.

FIN DEL DOCUMENTO DE CONTINUIDAD — 24 DE OCTUBRE DE 2026.