"""Presentación compartida. Sin operaciones sobre indicadores o datos de análisis."""
from pathlib import Path
from html import escape
import streamlit as st

MODULOS = {
    'Ranking exploratorio': ('Prioridades de rehabilitación', 'Compara criterios energéticos, emisiones calculadas y contexto social en un mismo conjunto.'),
    'Diagnóstico energético CEE / pre-CRREM': ('Diagnóstico energético', 'Revisa la coherencia de los certificados y los datos disponibles antes de interpretar los resultados.'),
    'Alineamiento CRREM': ('Trayectorias de descarbonización', 'Explora energía y carbono con las trayectorias CRREM de España y consulta sus supuestos.'),
    'Entorno social · INE': ('Entorno social', 'Consulta la renta territorial y la calidad de su enlace con cada certificado.'),
    'Resolver incidencias': ('Revisión de incidencias', 'Comprueba la información en fuentes oficiales y conserva un registro de tus decisiones.'),
}

ICONO = '''<svg viewBox="0 0 40 40" fill="none" aria-hidden="true"><path d="M9 31V15l11-7 11 7v16M6 32h28M16 32V22h8v10" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/><path d="M16 16h1m6 0h1" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"/></svg>'''

def iniciar(marca_lateral=True):
    st.markdown('<style>'+Path(__file__).with_name('estilo.css').read_text(encoding='utf-8')+'</style>',unsafe_allow_html=True)
    if marca_lateral:
        st.sidebar.markdown(f'<div class="marca"><div class="marca-icono">{ICONO}</div><div><strong>Rehabilitación</strong><span>ANÁLISIS SOSTENIBLE</span></div></div>',unsafe_allow_html=True)

def cabecera(modulo):
    title,description=MODULOS[modulo]
    st.markdown(f'''<div class="cabecera-app"><div class="sobre-titulo">HERRAMIENTA DE APOYO A LA DECISIÓN</div>
<h1>{title}</h1><p>{description}</p>
<div class="disciplinas"><span>Energía</span><span>Descarbonización</span><span>Entorno social</span></div></div>
<div class="alcance-aviso"><strong>CEE calculado · análisis exploratorio.</strong> Los indicadores no son consumos medidos. Los escenarios CEE-CRREM no son evaluaciones operacionales validadas.</div>''',unsafe_allow_html=True)

def conjunto(nombre,total,huella,piloto=False):
    subtitle='Muestra de 15 certificados reales · selección no representativa' if piloto else 'Archivo importado · conjunto de trabajo activo'
    st.markdown(f'''<div class="conjunto"><div><span class="etiqueta-dato">{subtitle}</span><strong>{escape(nombre)}</strong></div>
<div class="conjunto-cifra">{total:,}<span>certificados</span></div></div>'''.replace(f'{total:,}',f'{total:,}'.replace(',','.')),unsafe_allow_html=True)
    with st.expander('Procedencia del conjunto y alcance de los datos'):
        st.caption('SHA-256 del archivo base: '+huella)
        st.write('Los CEE contienen valores calculados bajo condiciones normalizadas. Cada fila puede corresponder a un edificio, una vivienda o una parte: la referencia catastral no acredita por sí sola un edificio físico único.')
        if piloto:st.caption('El piloto utiliza bloques completos existentes de Madrid con certificado fechado en 2025. Es una selección de prueba, no una muestra representativa del parque.')

def grafica(chart):
    return chart.configure_view(stroke=None).configure_axis(
        labelFont='Segoe UI',titleFont='Segoe UI',labelFontSize=11,titleFontSize=12,
        labelColor='#61746A',titleColor='#344D40',gridColor='#E7EDE8',domain=False,tickColor='#E1E8E2',
        titlePadding=16,labelPadding=8
    ).configure_legend(labelFont='Segoe UI',titleFont='Segoe UI',labelColor='#344D40',titleColor='#344D40',
                       labelFontSize=11,titleFontSize=12,padding=12).configure(background='transparent')

CONTROLES={
    'alerta_epnren':'EPNR ausente o no válida','alerta_emisiones':'Emisiones ausentes o no válidas',
    'alerta_area':'Superficie ausente o no válida','alerta_tipo':'Tipo de inmueble sin identificar',
    'alerta_referencia_ausente':'Sin referencia catastral','alerta_refcat_multiple':'Varias referencias en un certificado',
    'alerta_refcat_repetida':'Referencia presente en varios registros','alerta_renta':'Sin renta territorial utilizable',
}

def controles_legibles(tabla):
    result=tabla.copy()
    result['control']=result['control'].map(lambda x:CONTROLES.get(x,x))
    return result.rename(columns={'control':'Comprobación','registros_afectados':'Registros afectados'})
