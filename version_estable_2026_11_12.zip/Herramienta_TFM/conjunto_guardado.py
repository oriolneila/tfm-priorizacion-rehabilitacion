"""Copia local del último archivo importado, independiente de Streamlit."""
from pathlib import Path
import hashlib
import sqlite3

DB=Path(__file__).parent/'datos_usuario/conjunto_activo.sqlite3'


def guardar(nombre,contenido):
    if Path(nombre).suffix.lower() not in ('.csv','.zip') or not contenido:
        raise ValueError('El conjunto debe ser un CSV o ZIP con contenido.')
    DB.parent.mkdir(parents=True,exist_ok=True)
    with sqlite3.connect(DB) as db:
        db.execute('CREATE TABLE IF NOT EXISTS activo (id INTEGER PRIMARY KEY CHECK(id=1), nombre TEXT, contenido BLOB, sha256 TEXT)')
        db.execute('INSERT OR REPLACE INTO activo VALUES (1,?,?,?)',
                   (nombre,contenido,hashlib.sha256(contenido).hexdigest()))


def recuperar():
    if not DB.exists():return None
    with sqlite3.connect(DB) as db:
        row=db.execute('SELECT nombre,contenido,sha256 FROM activo WHERE id=1').fetchone()
    if row is None:return None
    nombre,contenido,huella=row
    if hashlib.sha256(contenido).hexdigest()!=huella:
        raise ValueError('La copia del archivo guardado no coincide con su huella.')
    return nombre,contenido


def retirar():
    if DB.exists():
        with sqlite3.connect(DB) as db:db.execute('DELETE FROM activo WHERE id=1')
